import numpy as np
from scipy.optimize import minimize
from scipy.sparse import csr_matrix, hstack
from scipy.special import logsumexp

import legacy
import wb_ordinal_given
import gfic_legacy as gfic


PAIRS = (
    ("group", "user.employmentStatus"),
    ("user.country", "user.age"),
    ("user.country", "user.educationLevel"),
    ("user.hadJob", "user.employmentStatus"),
)
L2 = 1e-3
EPSILON = 1e-2
MAX_ITER = 200
PRIOR = 0.5


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


def _design(data):
    columns, offset = [], 0
    for name in data.given:
        columns.append(data.features[name] + offset)
        offset += data.cards[name]
    used = []
    for left, right in PAIRS:
        if left not in data.given or right not in data.given:
            continue
        columns.append(data.features[left] * data.cards[right]
                       + data.features[right] + offset)
        offset += data.cards[left] * data.cards[right]
        used.append((left, right))
    columns.append(np.full(len(data.frame), offset, dtype=np.int64))
    indices = np.column_stack(columns)
    indptr = np.arange(0, indices.size + 1, len(columns), dtype=np.int64)
    matrix = csr_matrix((np.ones(indices.size), indices.ravel(), indptr),
                        shape=(len(data.frame), offset + 1))
    numeric = wb_ordinal_given.for_data(data)
    if numeric is not None:
        matrix = hstack((matrix[:, :-1], csr_matrix(numeric), matrix[:, -1:]), format="csr")
    return matrix, used


def _fit_item(x, xq, y, width, budget):
    counts = np.bincount(y, minlength=width).astype(float)
    prior = (counts + PRIOR) / (len(y) + PRIOR * width)
    if len(y) == 0 or width == 1 or np.count_nonzero(counts) < 2:
        return np.tile(prior, (xq.shape[0], 1)), {
            "status": "marginal_insufficient_classes", "iterations": 0,
            "train_rows": int(len(y)), "classes_seen": int(np.count_nonzero(counts)),
        }
    n, features = x.shape
    initial = np.zeros((features, width), dtype=np.float64)
    initial[-1] = np.log(prior)
    initial[-1] -= initial[-1].mean()
    rows = np.arange(n)
    transpose = x.T.tocsr()

    def objective(flat):
        _checkpoint(budget)
        weights = flat.reshape(features, width)
        logits = x @ weights
        normalizer = logsumexp(logits, axis=1)
        value = float(np.mean(normalizer - logits[rows, y]))
        value += 0.5 * L2 * float(np.sum(weights[:-1] ** 2))
        residual = np.exp(logits - normalizer[:, None])
        residual[rows, y] -= 1.0
        gradient = np.asarray(transpose @ residual) / n
        gradient[:-1] += L2 * weights[:-1]
        return value, gradient.ravel()

    result = minimize(objective, initial.ravel(), jac=True, method="L-BFGS-B",
                      callback=lambda _: _checkpoint(budget),
                      options={"maxiter": MAX_ITER, "ftol": 1e-9, "gtol": 1e-6,
                               "maxls": 30})
    _checkpoint(budget)
    if not np.isfinite(result.x).all() or not np.isfinite(result.fun):
        raise FloatingPointError("Nonfinite WB interaction softmax fit")
    logits = xq @ result.x.reshape(features, width)
    probability = np.exp(logits - logsumexp(logits, axis=1)[:, None])
    probability = (1.0 - EPSILON) * probability + EPSILON * prior[None, :]
    return legacy.normalize(probability), {
        "status": "converged" if result.success else "finite_not_converged",
        "optimizer_status": int(result.status), "iterations": int(result.nit),
        "train_rows": int(n), "classes_seen": int(np.count_nonzero(counts)),
    }


def candidate(data, train, query, budget=None):
    _checkpoint(budget)
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    design, used = _design(data)
    query_design = design[query]
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True,
                                                 item_calibration=True))
    targets, cards = gfic.content_targets(data, laws, train)
    values, details = {}, {}
    for column, item in enumerate(data.targets):
        _checkpoint(budget)
        labels = targets[train, column]
        known = labels >= 0
        p, record = _fit_item(design[train[known]], query_design, labels[known],
                              cards[column], budget)
        if item in laws:
            p = gfic.compose_gate(p, laws[item], query)
        values[item], details[item] = p, record
    _checkpoint(budget)
    return legacy.Candidate("WB_INTERACTIONS", values), {
        "pairs": [list(pair) for pair in used],
        "pairs_missing": [list(pair) for pair in PAIRS if pair not in used],
        "given": list(data.given), "design_columns": int(design.shape[1]),
        "l2_mean_loss": L2, "l2_sum_loss": "n * 0.001",
        "epsilon_marginal": EPSILON, "prior_per_class": PRIOR,
        "max_iter": MAX_ITER, "gate_items": list(laws), "items": details,
    }
