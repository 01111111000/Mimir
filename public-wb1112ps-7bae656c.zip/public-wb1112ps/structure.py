import numpy as np


def _codes(frame, schema, name, options):
    mapping = {value: i for i, value in enumerate(options)}
    return frame[name].map(mapping).fillna(-1).to_numpy(dtype=np.int64)


def _options(schema, name):
    record = schema["items"][name]
    return list(record["values"]) + ([schema.get("gated_value", "NA_GATED")]
                                      if record.get("gate") else [])


def _order(schema, targets):
    pending, order = list(targets), []
    while pending:
        ready = [n for n in pending if not schema["items"][n].get("gate")
                 or schema["items"][n]["gate"]["parent"] not in pending]
        if not ready:
            raise ValueError("Cyclic gate schema")
        order.extend(ready)
        pending = [n for n in pending if n not in ready]
    return order


def propagate(frame, schema, train, query, base, round_name=None, strength=20.0):
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    if np.intersect1d(train, query).size:
        raise ValueError("TRAIN and QUERY must be disjoint")
    if strength <= 0:
        raise ValueError("Smoothing strength must be positive")
    items = schema["items"]
    targets = [n for n, r in items.items() if r["class"] == "PREDICT"]
    result = {name: np.asarray(base[name], dtype=float).copy() for name in targets}
    if round_name is not None and round_name in frame.columns:
        rounds = frame[round_name].astype(object).where(frame[round_name].notna(), None).to_numpy()
        round_train, round_query = rounds[train], rounds[query]
        levels = [v for v in dict.fromkeys(round_train.tolist()) if v is not None]
    else:
        round_train = round_query = None
        levels = []
    details = {"propagated_items": 0, "round": round_name if levels else None}
    for name in _order(schema, targets):
        gate = items[name].get("gate")
        if not gate or gate["parent"] not in items:
            continue
        parent = gate["parent"]
        if items[parent]["class"] not in ("GIVEN", "PREDICT"):
            continue
        options = _options(schema, name)
        width = len(options)
        parent_options = _options(schema, parent)
        states = len(parent_options)
        y = _codes(frame, schema, name, options)[train]
        a = _codes(frame, schema, parent, parent_options)[train]
        known = (y >= 0) & (a >= 0)
        sentinel = (y == width - 1).astype(float)
        rate = (sentinel[known].sum() + 0.5) / (known.sum() + 1.0)
        counts = np.bincount(a[known], minlength=states).astype(float)
        hits = np.bincount(a[known], weights=sentinel[known], minlength=states)
        table = (hits + strength * rate) / (counts + strength)
        tables = np.tile(table, (len(query), 1))
        for level in levels:
            selected = known & (round_train == level)
            level_counts = np.bincount(a[selected], minlength=states).astype(float)
            level_hits = np.bincount(a[selected], weights=sentinel[selected], minlength=states)
            tables[round_query == level] = (level_hits + strength * table) / (level_counts + strength)
        if items[parent]["class"] == "GIVEN":
            observed = _codes(frame, schema, parent, parent_options)[query]
            share = counts / counts.sum() if counts.sum() > 0 else np.full(states, 1.0 / states)
            distribution = np.tile(share, (len(query), 1))
            seen = observed >= 0
            distribution[seen] = np.eye(states)[observed[seen]]
        else:
            distribution = result[parent]
        mass = np.clip((distribution * tables).sum(axis=1), 1e-6, 1 - 1e-6)
        ordinary = result[name][:, :width - 1]
        total = ordinary.sum(axis=1, keepdims=True)
        ordinary = np.divide(ordinary, total, out=np.full_like(ordinary, 1.0 / (width - 1)),
                             where=total > 0)
        result[name] = np.column_stack(((1 - mass)[:, None] * ordinary, mass))
        details["propagated_items"] += 1
    return result, details
