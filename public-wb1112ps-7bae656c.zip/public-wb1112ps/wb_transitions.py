import numpy as np
from scipy.optimize import minimize_scalar

import legacy
import gfic_legacy as gfic


NAME = "WB_TRANSITIONS"
PRIOR_PER_CLASS = 0.5
MIN_CONCENTRATION = 0.5
MAX_CONCENTRATION = 32768.0
TRANSITIONS = (
    ("user.wageOfSimilarEmployees", "user.wageOfSimilarEmployeesAfter"),
    ("user.lowestAcceptablePay", "user.lowestAcceptablePayAfter"),
    ("user.wageOfSimilarEmployees", "tr_similar_wage_after"),
    ("user.lowestAcceptablePay", "tr_low_pay_after"),
)
PROFILE_ORDERS = (
    ("group", "user.country", "user.employmentStatus",
     "user.educationLevel", "user.hadJob", "user.age", "user.gender"),
    ("user.employmentStatus", "user.educationLevel", "group",
     "user.country", "user.age", "user.hadJob", "user.gender"),
)


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


def _concentration(count, total, parent, informative, budget):
    active = informative & (total > 0)
    if not np.any(active):
        return None
    count, total, parent = count[active], total[active], parent[active]

    def objective(log_strength):
        _checkpoint(budget)
        strength = np.exp(log_strength)
        return float(np.mean(np.log(total + strength)
                             - np.log(count + strength * parent)))

    lower, upper = np.log(MIN_CONCENTRATION), np.log(MAX_CONCENTRATION)
    result = minimize_scalar(objective, bounds=(lower, upper), method="bounded",
                             options={"maxiter": 36, "xatol": 1e-4})
    candidates = (lower, upper, float(result.x))
    selected = min(candidates, key=objective)
    if float(-np.log(parent).mean()) <= objective(selected):
        return None
    return float(np.exp(selected))


def _hierarchy(train_x, query_x, labels, width, budget):
    n, nq = len(labels), len(query_x)
    counts = np.bincount(labels, minlength=width).astype(np.float64)
    prior = (counts + PRIOR_PER_CLASS) / (n + PRIOR_PER_CLASS * width)
    probability = np.broadcast_to(prior, (nq, width)).copy()
    if n < 2:
        return probability, []
    loo = (counts[labels] - 1 + PRIOR_PER_CLASS) / (n - 1 + PRIOR_PER_CLASS * width)
    parent_train_total = np.full(n, n, dtype=np.int64)
    parent_query_total = np.full(nq, n, dtype=np.int64)
    details = []
    for depth in range(1, train_x.shape[1] + 1):
        _checkpoint(budget)
        joined = np.concatenate((train_x[:, :depth], query_x[:, :depth]), axis=0)
        contexts, inverse = np.unique(joined, axis=0, return_inverse=True)
        train_code, query_code = inverse[:n], inverse[n:]
        table = np.bincount(train_code * width + labels,
                            minlength=len(contexts) * width).reshape(-1, width)
        totals = table.sum(axis=1)
        own_total, query_total = totals[train_code], totals[query_code]
        train_refined = own_total < parent_train_total
        query_refined = (query_total > 0) & (query_total < parent_query_total)
        removed_count = table[train_code, labels] - 1
        removed_total = own_total - 1
        strength = _concentration(removed_count, removed_total, loo,
                                  train_refined, budget)
        if strength is not None:
            update = (removed_count + strength * loo) / (removed_total + strength)
            loo = np.where(train_refined, update, loo)
            predictive = ((table[query_code] + strength * probability)
                          / (query_total[:, None] + strength))
            probability = np.where(query_refined[:, None], predictive, probability)
        details.append({"depth": depth, "concentration": strength,
                        "contexts_observed": int(np.count_nonzero(totals)),
                        "query_refined": int(query_refined.sum()),
                        "status": "parent_only" if strength is None else "shrunk_transition"})
        parent_train_total, parent_query_total = own_total, query_total
    return legacy.normalize(probability), details


def _orders(data, source):
    other = ("user.lowestAcceptablePay" if source == "user.wageOfSimilarEmployees"
             else "user.wageOfSimilarEmployees")
    allowed = set(data.given)
    result = []
    for profile in PROFILE_ORDERS:
        order = [source]
        proposed = profile[:2] + (other,) + profile[2:] + tuple(data.given)
        order.extend(name for name in proposed if name in allowed and name not in order)
        if order not in result:
            result.append(order)
    return result


def candidate(data, train, query, budget=None):
    _checkpoint(budget)
    train, query = np.asarray(train, dtype=np.int64), np.asarray(query, dtype=np.int64)
    if train.ndim != 1 or query.ndim != 1:
        raise ValueError("WB transitions require one-dimensional row indices")
    if np.intersect1d(train, query).size or len(np.unique(train)) != len(train):
        raise ValueError("WB transition TRAIN must be unique and disjoint from QUERY")
    nrows = len(data.frame)
    if (np.any(train < 0) or np.any(train >= nrows)
            or np.any(query < 0) or np.any(query >= nrows)):
        raise IndexError("WB transition row indices outside frame")
    probabilities = {item: None for item in data.targets}
    details = {"name": NAME, "items": {}, "prior_per_class": PRIOR_PER_CLASS,
               "concentration_range": [MIN_CONCENTRATION, MAX_CONCENTRATION],
               "selection": "TRAIN-only leave-one-out log loss; not validation performance"}
    usable = [(source, item) for source, item in TRANSITIONS
              if source in data.given and item in data.targets]
    if not usable:
        return legacy.Candidate(NAME, probabilities), details
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
    for source, item in usable:
        _checkpoint(budget)
        width = len(data.options[item])
        labels = np.asarray(data.codes[item][train], dtype=np.int64)
        valid = (labels >= 0) & (labels < width)
        law = laws.get(item)
        if law is not None:
            width = law["sentinel"]
            valid &= law["open"][train] & (labels != law["sentinel"])
        selected, labels = train[valid], labels[valid]
        orders, fitted, records = _orders(data, source), [], []
        for order in orders:
            _checkpoint(budget)
            x = np.column_stack([data.features[name] for name in order])
            p, levels = _hierarchy(x[selected], x[query], labels, width, budget)
            fitted.append(p)
            records.append({"given_order": order, "levels": levels})
        p = legacy.normalize(np.mean(fitted, axis=0))
        if law is not None:
            p = gfic.compose_gate(p, law, query)
        if (p.shape != (len(query), len(data.options[item]))
                or not np.isfinite(p).all() or np.any(p < 0)
                or not np.allclose(p.sum(axis=1), 1.0, atol=1e-12, rtol=0)):
            raise FloatingPointError("Invalid WB transition probabilities")
        probabilities[item] = p
        details["items"][item] = {
            "source": source, "source_values": list(data.options[source]),
            "target_values": list(data.options[item]),
            "support_mapping": "independent categorical codes; no imposed diagonal",
            "train_rows": int(len(selected)), "gate_composed": law is not None,
            "chains": records,
        }
    _checkpoint(budget)
    return legacy.Candidate(NAME, probabilities), details
