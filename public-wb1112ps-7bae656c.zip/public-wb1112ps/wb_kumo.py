from contextlib import ExitStack
import hashlib
import io
import os
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd

import legacy
import gfic_legacy as gfic
from budget import CandidateBudgetExceeded

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

CHECKPOINT_PATH = Path(__file__).resolve().parent / "models" / "kumo-tabular-large-classifier.pt"
CHECKPOINT_SHA256 = "cc21484316949641cc3d65a7bb6c36cdea854cc569435755ff23b850018ec613"
CHECKPOINT_BYTES = 854850034
CHECKPOINT_REVISION = "3c3e10bbdb590ace29e7026847f92db3c603096d"
PACKAGE_VERSION = "0.2.1"
MAX_CLASSES = 10
SMOOTHING = 0.001
MARGINAL_ALPHA = 0.5
SEED = 42
NAME = "Kumo_WB"
_DEVICE = "cpu"
_DEVICE_STATUS = "CPU default"


def _cuda_device(torch, model):
    try:
        import config as _route_config
        policy = str(getattr(_route_config, "TABICL_DEVICE", "auto"))
    except Exception:
        policy = "cpu"
    if policy != "auto":
        raise RuntimeError("CPU fixed by configuration")
    index = torch.cuda.current_device()
    device = "cuda:%d" % index
    probe = torch.ones((4, 4), device=device)
    result = probe @ probe
    torch.cuda.synchronize(index)
    if not bool(torch.isfinite(result).all()):
        raise RuntimeError("Nonfinite CUDA probe")
    model.to(device)
    torch.cuda.synchronize(index)
    del probe, result
    return device


def _preload():
    import torch
    from importlib.metadata import version
    if version("structured-data-models") != PACKAGE_VERSION:
        raise RuntimeError("structured-data-models %s is required" % PACKAGE_VERSION)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable")
    import sdm
    from sdm.models import KumoTabular
    with open(CHECKPOINT_PATH, "rb") as stream:
        payload = stream.read(CHECKPOINT_BYTES + 1)
    if len(payload) != CHECKPOINT_BYTES or hashlib.sha256(payload).hexdigest() != CHECKPOINT_SHA256:
        raise ValueError("Kumo checkpoint integrity mismatch")
    state = torch.load(io.BytesIO(payload), map_location="cpu", weights_only=True)
    del payload
    with torch.random.fork_rng(devices=[]):
        model = KumoTabular(task="classification", size="large", pretrained=False, device="cpu")
        model.models["classification"].load_state_dict(state, strict=True)
    del state
    if model.ecoc.max_classes != MAX_CLASSES:
        raise ValueError("Unexpected Kumo class limit")
    model.eval()
    try:
        device = _cuda_device(torch, model)
    except Exception:
        del model
        raise
    global _DEVICE, _DEVICE_STATUS
    _DEVICE, _DEVICE_STATUS = device, "CUDA allocation, GEMM and checkpoint transfer passed"
    return torch, sdm, model


_IMPORT_STARTED = perf_counter()
_TORCH, _SDM, _MODEL = None, None, None
try:
    _TORCH, _SDM, _MODEL = _preload()
    AVAILABLE, STATUS = True, "ready: verified module-level checkpoint on CUDA"
except Exception as error:
    AVAILABLE, STATUS = False, "%s: %s" % (type(error).__name__, error)
IMPORT_SECONDS = perf_counter() - _IMPORT_STARTED


def availability():
    return {"available": AVAILABLE, "status": STATUS,
            "checkpoint_sha256": CHECKPOINT_SHA256,
            "checkpoint_revision": CHECKPOINT_REVISION,
            "import_seconds": IMPORT_SECONDS, "device": _DEVICE,
            "device_status": _DEVICE_STATUS,
            "package": "structured-data-models==" + PACKAGE_VERSION,
            "native_max_classes": MAX_CLASSES}


def _categorical_features(frame, schema):
    result = {}
    for name, record in schema["items"].items():
        if record["class"] == "GIVEN":
            result[name] = pd.Categorical(frame[name], categories=legacy.options_for(schema, name))
    return pd.DataFrame(result, index=frame.index)


def _predict_item(features, labels, width, train, query, check, n_estimators=1):
    train = np.asarray(train, dtype=int)
    query = np.asarray(query, dtype=int)
    fit_rows = train[labels[train] >= 0]
    y = labels[fit_rows]
    counts = np.bincount(y, minlength=width).astype(np.float64)
    marginal = (counts + MARGINAL_ALPHA) / (len(y) + MARGINAL_ALPHA * width)
    check()
    if len(y) == 0:
        return np.tile(marginal, (len(query), 1))
    if np.unique(y).size == 1:
        result = np.zeros((len(query), width), dtype=np.float64)
        result[:, y[0]] = 1.0
    else:
        stypes = {name: "categorical" for name in features.columns}
        x_context = _SDM.TableTensor.from_pandas(features.iloc[fit_rows].reset_index(drop=True), stypes, device=_DEVICE)
        y_context = _SDM.TableTensor.from_pandas(pd.DataFrame({"y": y.astype(np.int64)}), {"y": "categorical"},
                                                 device=_DEVICE)
        x_query = _SDM.TableTensor.from_pandas(features.iloc[query].reset_index(drop=True), stypes, device=_DEVICE)
        check()
        generator = _TORCH.Generator(device=_DEVICE).manual_seed(SEED)
        out = _MODEL(x_context=x_context, y_context=y_context, x_query=x_query,
                     num_estimators=n_estimators, generator=generator)
        names = list(out.columns[_SDM.Stype.numerical])
        predicted = out.numerical.detach().to("cpu", _TORCH.float64).numpy()
        check()
        classes = np.array([int(float(name)) for name in names], dtype=int)
        if (np.any(classes < 0) or np.any(classes >= width) or len(set(classes.tolist())) != len(classes)
                or predicted.shape != (len(query), len(classes))
                or not np.isfinite(predicted).all() or np.any(predicted < 0)
                or np.any(predicted.sum(1) <= 0)):
            raise ValueError("Invalid Kumo output")
        result = np.zeros((len(query), width), dtype=np.float64)
        result[:, classes] = predicted / predicted.sum(1, keepdims=True)
    return (1.0 - SMOOTHING) * result + SMOOTHING * marginal[None, :]


def fit_plans(frame, schema, plans, budget=None, cap_seconds=None, config=None, threads=8,
              selected_items=(), n_estimators=1, many_class=False):
    started = perf_counter()
    try:
        return _fit_plans(frame, schema, plans, budget=budget, cap_seconds=cap_seconds,
                          config=config, threads=threads, selected_items=selected_items,
                          n_estimators=n_estimators, many_class=many_class)
    except Exception as error:
        return [{} for _ in plans], {
            **availability(), "status": "failed_atomically", "covered_items": [],
            "items": [], "discarded_items": [], "error_type": type(error).__name__,
            "error": str(error), "elapsed_seconds": perf_counter() - started,
        }


def _fit_plans(frame, schema, plans, budget=None, cap_seconds=None, config=None, threads=8,
               selected_items=(), n_estimators=1, many_class=False):
    if not isinstance(n_estimators, (int, np.integer)) or n_estimators < 1:
        raise ValueError("n_estimators must be a positive integer")
    n_estimators = int(n_estimators)
    started = perf_counter()
    detail = {**availability(), "status": "empty", "covered_items": [], "items": [], "excluded_items": [],
              "n_estimators": n_estimators, "many_class": bool(many_class)}
    if not AVAILABLE or not _DEVICE.startswith("cuda"):
        detail.update(status="unavailable", error=STATUS, elapsed_seconds=perf_counter() - started)
        return [{} for _ in plans], detail
    config = config or legacy.Config()
    full_data = legacy.Data(frame, schema, config)
    features = _categorical_features(frame, schema)
    contexts = []
    for plan in plans:
        train = np.asarray(plan["train"], dtype=int)
        query = np.asarray(plan["query"], dtype=int)
        if np.intersect1d(train, query).size:
            raise ValueError("Kumo train/query rows overlap")
        outside = np.setdiff1d(np.arange(len(frame)), train)
        masked = legacy.mask_respondents(frame, schema, outside)
        data = legacy.Data(masked, schema, config)
        laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
        targets, cards = gfic.content_targets(data, laws, train)
        contexts.append((data, laws, targets, cards, train, query))
    probabilities = [{item: None for item in full_data.targets} for _ in plans]
    deadline = float("inf") if cap_seconds is None else started + max(0.0, float(cap_seconds))

    def check():
        if perf_counter() >= deadline:
            raise CandidateBudgetExceeded("Kumo allowance reached")
        if budget is not None:
            budget.checkpoint()

    unknown = set(selected_items or ()) - set(full_data.targets)
    if unknown:
        raise ValueError("Unknown selected Kumo items: " + repr(sorted(unknown)))
    detail["selected_items"] = list(selected_items or ())
    cleanup = ExitStack()
    try:
        check()
        old_threads = _TORCH.get_num_threads()
        cleanup.callback(_TORCH.set_num_threads, old_threads)
        _TORCH.set_num_threads(max(1, int(threads)))
        cleanup.enter_context(_TORCH.random.fork_rng(devices=[_TORCH.cuda.current_device()]))
        _TORCH.random.default_generator.manual_seed(SEED)
        _TORCH.cuda.manual_seed(SEED)
        old_deterministic = _TORCH.are_deterministic_algorithms_enabled()
        old_warn_only = _TORCH.is_deterministic_algorithms_warn_only_enabled()
        cleanup.callback(_TORCH.use_deterministic_algorithms, old_deterministic, warn_only=old_warn_only)
        _TORCH.use_deterministic_algorithms(True)
        for module in _MODEL.modules():
            handle = module.register_forward_pre_hook(lambda _module, _inputs: check())
            cleanup.callback(handle.remove)
        for item in selected_items or ():
            column = full_data.targets.index(item)
            widths = [context[3][column] for context in contexts]
            if any(width < 1 for width in widths):
                detail["excluded_items"].append({"item": item, "reason": "empty_support", "width": max(widths)})
                continue
            if max(widths) > MAX_CLASSES and not many_class:
                detail["excluded_items"].append({"item": item, "reason": "many_class_off", "width": max(widths)})
                continue
            check()
            item_started, pending, folds = perf_counter(), [], []
            for plan, (data, laws, targets, cards, train, query) in zip(plans, contexts):
                fit_started = perf_counter()
                p = _predict_item(features, targets[:, column], cards[column], train, query, check,
                                  n_estimators=n_estimators)
                if item in laws:
                    p = gfic.compose_gate(p, laws[item], query)
                if (p.shape != (len(query), full_data.ycards[column]) or not np.isfinite(p).all()
                        or np.any(p < 0) or not np.allclose(p.sum(1), 1, atol=1e-9, rtol=0)):
                    raise ValueError("Invalid composed Kumo output")
                pending.append(p)
                folds.append({"kind": plan["kind"], "seconds": perf_counter() - fit_started,
                              "train_rows": int(np.sum(targets[train, column] >= 0)),
                              "query_rows": len(query)})
            check()
            for bank, p in zip(probabilities, pending):
                bank[item] = p
            detail["covered_items"].append(item)
            detail["items"].append({"item": item, "seconds": perf_counter() - item_started, "folds": folds,
                                    "many_class": max(widths) > MAX_CLASSES})
        detail["status"] = "ok"
    except CandidateBudgetExceeded:
        detail["status"] = "budget"
    except Exception as error:
        detail.update(status="failed_atomically", error_type=type(error).__name__, error=str(error),
                      discarded_items=list(detail["covered_items"]))
        detail["covered_items"] = []
    finally:
        try:
            cleanup.close()
        except Exception as error:
            detail.update(status="failed_atomically", cleanup_error=type(error).__name__,
                          cleanup_message=str(error),
                          discarded_items=list(detail["covered_items"]) or detail.get("discarded_items", []))
            detail["covered_items"] = []
        detail["elapsed_seconds"] = perf_counter() - started
    if not detail["covered_items"]:
        return [{} for _ in plans], detail
    return [{NAME: legacy.Candidate(NAME, values)} for values in probabilities], detail
