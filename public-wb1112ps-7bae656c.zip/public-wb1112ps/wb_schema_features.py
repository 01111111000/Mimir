from __future__ import annotations

import numpy as np
import pandas as pd


AGE_ORDER = ("15-19", "20-24", "25-29", "30-34", "35-44", "45+")
PAY_ORDER = ("0", "1-1999", "2000-2999", "3000-3999", "4000-4999",
             "5000-6999", "7000-9999", "10000-14999", "15000-24999", "25000+")
ORDERED_GIVEN = {
    "user.age": AGE_ORDER,
    "user.wageOfSimilarEmployees": PAY_ORDER,
    "user.lowestAcceptablePay": PAY_ORDER,
}
NONRESPONSE = "Not answered"


def ordered_given_features(frame: pd.DataFrame, schema: dict) -> pd.DataFrame:
    output = {}
    for name, record in schema["items"].items():
        if record["class"] != "GIVEN":
            continue
        values = list(record["values"])
        if name not in ORDERED_GIVEN:
            output[name] = pd.Categorical(frame[name], categories=values)
            continue
        ordered = ORDERED_GIVEN[name]
        allowed = set(values)
        unsupported = allowed.difference(ordered).difference({NONRESPONSE})
        if unsupported:
            raise ValueError(f"Unknown ordered schema categories for {name}: {sorted(unsupported)!r}")
        raw = frame[name].astype(object)
        mapping = {value: float(rank) for rank, value in enumerate(ordered) if value in allowed}
        rank = raw.map(mapping).astype(np.float64)
        not_answered = raw.eq(NONRESPONSE).fillna(False) & (NONRESPONSE in allowed)
        missing = rank.isna() & ~not_answered
        output[name] = rank
        output[name + "__not_answered"] = not_answered.astype(np.float64)
        output[name + "__missing"] = missing.astype(np.float64)
    return pd.DataFrame(output, index=frame.index)
