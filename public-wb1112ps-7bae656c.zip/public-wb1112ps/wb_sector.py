from __future__ import annotations

import re

import numpy as np
from scipy.optimize import minimize

import legacy
import gfic_legacy as gfic

NAME = "WB_SECTOR"
ANCHOR = "user.targetSector"
MIN_SHARED_LABELS = 15
DIM = 4
RIDGE_EMBED = 10.0
RIDGE_SHARED_MAP = 20.0
RIDGE_ITEM_MAP = 50.0
RIDGE_INTERCEPT = 1.0
INIT_SCALE = 0.01
SEED = 1019
MAX_ITER = 300
EPS = 1e-12


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


def _key(label):
    text = re.sub(r"[^a-z0-9]+", "", str(label).lower())
    return text[:-1] if text.endswith("sports") else text


def _one_hot(data, rows):
    blocks = []
    for name in data.given:
        card = len(data.options[name]) + 1
        values = np.asarray(data.codes[name][rows], dtype=np.int64)
        values = np.where((values >= 0) & (values < card - 1), values, card - 1)
        block = np.zeros((len(rows), card))
        block[np.arange(len(rows)), values] = 1.0
        blocks.append(block)
    return np.concatenate(blocks, axis=1) if blocks else np.zeros((len(rows), 0))


def sector_items(data):
    if ANCHOR not in data.targets:
        return [], []
    anchor = {_key(v) for v in data.options[ANCHOR]}
    items = []
    for item in data.targets:
        gate = data.schema["items"][item].get("gate")
        if gate and gate["parent"] not in data.given:
            continue
        labels = {_key(v) for v in data.options[item]}
        if len(labels & anchor) >= MIN_SHARED_LABELS:
            items.append(item)
    labels = []
    for item in items:
        for value in data.options[item]:
            key = _key(value)
            if key not in labels:
                labels.append(key)
    return items, labels


def candidate(data, train, query, budget=None):
    _checkpoint(budget)
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    if np.intersect1d(train, query).size or len(np.unique(train)) != len(train):
        raise ValueError("WB sector TRAIN must be unique and disjoint from QUERY")
    probabilities = {item: None for item in data.targets}
    items, labels = sector_items(data)
    details = {"name": NAME, "items": items, "shared_labels": len(labels), "dim": DIM,
               "penalties": {"embed": RIDGE_EMBED, "shared_map": RIDGE_SHARED_MAP,
                             "item_map": RIDGE_ITEM_MAP, "intercept": RIDGE_INTERCEPT},
               "selection": "fixed constants; TRAIN labels of open rows only"}
    if not items:
        return legacy.Candidate(NAME, probabilities), details
    x_train_full, x_query_full = _one_hot(data, train), _one_hot(data, query)
    counts = x_train_full.sum(axis=0)
    columns = np.flatnonzero((counts > 0) & (counts < len(train)))
    x_train, x_query = x_train_full[:, columns], x_query_full[:, columns]
    p = x_train.shape[1]
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
    label_index = {key: i for i, key in enumerate(labels)}
    blocks = []
    for item in items:
        options = list(data.options[item])
        law = laws.get(item)
        width = law["sentinel"] if law is not None else len(options)
        content = options[:width]
        codes = np.asarray(data.codes[item][train], dtype=np.int64)
        valid = (codes >= 0) & (codes < width)
        if law is not None:
            valid &= law["open"][train]
        rows = np.flatnonzero(valid)
        if len(rows) < 2 * width:
            continue
        shares = np.bincount(codes[rows], minlength=width) + 0.5
        blocks.append({"item": item, "law": law, "width": width,
                       "map": np.array([label_index[_key(v)] for v in content], dtype=np.int64),
                       "x": x_train[rows], "y": codes[rows],
                       "a0": np.log(shares / shares.sum())})
    if not blocks:
        return legacy.Candidate(NAME, probabilities), details
    rng = np.random.default_rng(SEED)
    n_labels, n_items = len(labels), len(blocks)
    sizes = {"E": n_labels * DIM, "B0": DIM * p, "dB": n_items * DIM * p,
             "A": int(sum(b["width"] for b in blocks))}
    total_rows = float(sum(len(b["y"]) for b in blocks))

    def unpack(flat):
        offset = 0
        parts = {}
        for name in ("E", "B0", "dB", "A"):
            parts[name] = flat[offset:offset + sizes[name]]
            offset += sizes[name]
        E = parts["E"].reshape(n_labels, DIM)
        B0 = parts["B0"].reshape(DIM, p)
        dB = parts["dB"].reshape(n_items, DIM, p)
        A, a_offset = [], 0
        for block in blocks:
            A.append(parts["A"][a_offset:a_offset + block["width"]])
            a_offset += block["width"]
        return E, B0, dB, A

    def item_logits(block, index, E, B0, dB, A, x):
        z = x @ (B0 + dB[index]).T
        return A[index][None, :] + z @ E[block["map"]].T, z

    def objective(flat):
        E, B0, dB, A = unpack(flat)
        loss = 0.0
        gE, gB0, gdB = np.zeros_like(E), np.zeros_like(B0), np.zeros_like(dB)
        gA = []
        for index, block in enumerate(blocks):
            logits, z = item_logits(block, index, E, B0, dB, A, block["x"])
            logits -= logits.max(axis=1, keepdims=True)
            prob = np.exp(logits)
            prob /= prob.sum(axis=1, keepdims=True)
            rows = np.arange(len(block["y"]))
            loss -= np.log(np.maximum(prob[rows, block["y"]], EPS)).sum()
            g = prob
            g[rows, block["y"]] -= 1.0
            gA.append(g.sum(axis=0))
            np.add.at(gE, block["map"], g.T @ z)
            gz = g @ E[block["map"]]
            gb = gz.T @ block["x"]
            gB0 += gb
            gdB[index] = gb
        penalty = (RIDGE_EMBED * np.sum(E ** 2) + RIDGE_SHARED_MAP * np.sum(B0 ** 2)
                   + RIDGE_ITEM_MAP * np.sum(dB ** 2)
                   + RIDGE_INTERCEPT * sum(np.sum((a - b["a0"]) ** 2) for a, b in zip(A, blocks)))
        gE += 2 * RIDGE_EMBED * E
        gB0 += 2 * RIDGE_SHARED_MAP * B0
        gdB += 2 * RIDGE_ITEM_MAP * dB
        gA = [ga + 2 * RIDGE_INTERCEPT * (a - b["a0"]) for ga, a, b in zip(gA, A, blocks)]
        gradient = np.concatenate([gE.ravel(), gB0.ravel(), gdB.ravel()] + [ga.ravel() for ga in gA])
        return (loss + penalty) / total_rows, gradient / total_rows

    initial = np.concatenate([
        INIT_SCALE * rng.standard_normal(sizes["E"]),
        np.zeros(sizes["B0"]), np.zeros(sizes["dB"]),
        np.concatenate([b["a0"] for b in blocks])])
    _checkpoint(budget)
    result = minimize(objective, initial, method="L-BFGS-B", jac=True,
                      callback=lambda _: _checkpoint(budget),
                      options={"maxiter": MAX_ITER, "maxls": 25, "ftol": 1e-9, "gtol": 1e-6})
    _checkpoint(budget)
    if not np.isfinite(result.x).all() or not np.isfinite(result.fun):
        raise FloatingPointError("Nonfinite WB_SECTOR fit")
    E, B0, dB, A = unpack(result.x)
    details.update(converged=bool(result.success), iterations=int(result.nit),
                   evaluations=int(result.nfev), objective=float(result.fun),
                   columns=int(p), fitted_items={b["item"]: int(len(b["y"])) for b in blocks})
    for index, block in enumerate(blocks):
        logits, _ = item_logits(block, index, E, B0, dB, A, x_query)
        logits -= logits.max(axis=1, keepdims=True)
        prob = np.exp(logits)
        prob /= prob.sum(axis=1, keepdims=True)
        if block["law"] is not None:
            prob = gfic.compose_gate(prob, block["law"], query)
        if (prob.shape != (len(query), len(data.options[block["item"]])) or not np.isfinite(prob).all()
                or np.any(prob < 0) or not np.allclose(prob.sum(axis=1), 1.0, atol=1e-9, rtol=0)):
            raise FloatingPointError("Invalid WB_SECTOR probabilities")
        probabilities[block["item"]] = prob
    _checkpoint(budget)
    return legacy.Candidate(NAME, probabilities), details
