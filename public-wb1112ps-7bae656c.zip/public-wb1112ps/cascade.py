import numpy as np
import pandas as pd

ALPHA = 2.0
STRATA = 2
SENT_ALPHA = 2.0
SENT_STRATA = 1
MIN_COUNT = 8
HARD_GATES = False
EPS = 1e-6


def mutual_information(x, y, nx, ny):
    if x.size < MIN_COUNT:
        return 0.0
    joint = np.bincount(x * ny + y, minlength=nx * ny).reshape(nx, ny) / float(x.size)
    px, py = joint.sum(1, keepdims=True), joint.sum(0, keepdims=True)
    nz = joint > 0
    return float((joint[nz] * np.log(joint[nz] / (px @ py)[nz])).sum())


def backoff_table(key_fit, y_fit, key_all, size, width, prior, alpha):
    table = np.bincount(key_fit * width + y_fit, minlength=size * width).astype(float)
    counts = table.reshape(size, width)[key_all]
    return (counts + alpha * prior) / (counts.sum(axis=1, keepdims=True) + alpha)


def predict(frame, schema):
    sentinel = schema.get("gated_value", "NA_GATED")
    records = schema["items"]
    items = [n for n, r in records.items() if r["class"] in ("GIVEN", "PREDICT")]
    given = [n for n in items if records[n]["class"] == "GIVEN"]
    targets = [n for n in items if records[n]["class"] == "PREDICT"]
    gate = {n: (records[n].get("gate") or None) for n in items}
    options = {n: list(records[n]["values"]) + ([sentinel] if gate[n] else [])
               for n in items}
    n = len(frame)

    codes = {}
    for name in items:
        lookup = {v: i for i, v in enumerate(options[name])}
        codes[name] = (frame[name].map(lookup).astype(float)
                       .fillna(-1.0).astype(np.int64).to_numpy())

    card = {g: len(options[g]) + 1 for g in given}
    strat = {g: np.where(codes[g] >= 0, codes[g], card[g] - 1) for g in given}

    def depth(name):
        levels, seen = 0, set()
        while gate[name] and name not in seen and gate[name]["parent"] in gate:
            seen.add(name)
            name = gate[name]["parent"]
            levels += 1
        return levels

    order = sorted(targets, key=depth)

    def marginal(name):
        y = codes[name]
        counts = np.bincount(y[y >= 0], minlength=len(options[name])).astype(float) + 0.5
        return counts / counts.sum()

    full = {}

    def parent_distribution(parent):
        k = len(options[parent])
        if parent in full:
            dist = full[parent].copy()
        else:
            dist = np.tile(marginal(parent), (n, 1))
        pc = codes[parent]
        seen = pc >= 0
        if seen.any():
            dist[seen] = np.eye(k)[pc[seen]]
        return dist

    def ranked_strata(x_rows, y, ny, limit):
        if limit <= 0 or not x_rows.any():
            return []
        scored = []
        for g in given:
            mi = mutual_information(strat[g][x_rows], y, card[g], ny)
            if mi > 0.0:
                scored.append((mi, g))
        scored.sort(key=lambda t: -t[0])
        return [g for _, g in scored[:limit]]

    for item in order:
        y = codes[item]
        width = len(records[item]["values"])
        known = y >= 0
        asked = known & (y < width)

        ladder = ranked_strata(asked, y[asked], width, STRATA)
        running = np.full((n, width), 1.0 / width)
        key_fit = np.zeros(int(asked.sum()), dtype=np.int64)
        key_all = np.zeros(n, dtype=np.int64)
        size = 1
        for column in [None] + ladder:
            if column is not None:
                key_fit = key_fit * card[column] + strat[column][asked]
                key_all = key_all * card[column] + strat[column]
                size *= card[column]
            running = backoff_table(key_fit, y[asked], key_all, size, width, running, ALPHA)
        answer = running

        if not gate[item]:
            full[item] = answer
            continue

        z = (y == width).astype(float)
        rate = (z[known].sum() + 0.5) / (known.sum() + 1.0)
        parent = gate[item]["parent"]

        if parent in options:
            kp = len(options[parent])
            pc = codes[parent]
            fit = known & (pc >= 0)
            if HARD_GATES:
                allowed = set(gate[item].get("observed_if") or [])
                table = np.array([0.0 if v in allowed else 1.0 for v in options[parent]])
                table = np.clip(table, EPS, 1.0 - EPS)
                stratum = None
            else:
                hits = np.bincount(pc[fit], weights=z[fit], minlength=kp)
                tot = np.bincount(pc[fit], minlength=kp).astype(float)
                table = (hits + SENT_ALPHA * rate) / (tot + SENT_ALPHA)
                stratum = ranked_strata(fit, z[fit].astype(np.int64), 2, SENT_STRATA)
            dist = parent_distribution(parent)
            if stratum:
                s = stratum[0]
                key = pc[fit] * card[s] + strat[s][fit]
                hits2 = np.bincount(key, weights=z[fit], minlength=kp * card[s]).reshape(kp, card[s])
                tot2 = np.bincount(key, minlength=kp * card[s]).reshape(kp, card[s]).astype(float)
                table2 = (hits2 + SENT_ALPHA * table[:, None]) / (tot2 + SENT_ALPHA)
                p_sent = np.einsum("nk,kn->n", dist, table2[:, strat[s]])
            else:
                p_sent = dist @ table
        else:
            stratum = ranked_strata(known, z[known].astype(np.int64), 2, SENT_STRATA) \
                if not HARD_GATES else []
            if stratum:
                s = stratum[0]
                hits = np.bincount(strat[s][known], weights=z[known], minlength=card[s])
                tot = np.bincount(strat[s][known], minlength=card[s]).astype(float)
                p_sent = ((hits + SENT_ALPHA * rate) / (tot + SENT_ALPHA))[strat[s]]
            else:
                p_sent = np.full(n, rate)

        p_sent = np.clip(p_sent, EPS, 1.0 - EPS)[:, None]
        full[item] = np.concatenate([(1.0 - p_sent) * answer, p_sent], axis=1)

    grid = frame[items].to_numpy(dtype=object)
    blank = pd.isna(grid)
    out = []
    for row in range(n):
        for column in np.flatnonzero(blank[row]):
            name = items[column]
            if name in full:
                out.append(full[name][row])
            else:
                out.append(marginal(name))
    return out
