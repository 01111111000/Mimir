from time import perf_counter

import numpy as np
from scipy.optimize import minimize
from scipy.sparse import csr_matrix
from scipy.special import logsumexp

import legacy
import wb_response as response

NAME = "WB_SHARED_ARMS"
RANDOMIZED = ("yes1", "yes2", "yes3", "yes4")
CONTENT_L2 = 0.002
RANDOMIZATION_L2 = 0.01
PRIOR = 0.5
MAX_ITER = 100


def design(data, train, query):
    rows = np.r_[train, query]
    parts, penalties, offset = [], [], 0
    for name in data.given:
        raw = data.codes[name][rows]
        if name == "group":
            options = data.options[name]
            randomized = [options.index(v) for v in RANDOMIZED if v in options]
            nonrandom = options.index("Not randomised") if "Not randomised" in options else -2
            code = np.where(np.isin(raw, randomized), 1, np.where(raw == nonrandom, 0, 2))
            width, penalty = 3, RANDOMIZATION_L2
        else:
            width, penalty = len(data.options[name]) + 1, CONTENT_L2
            code = np.where(raw >= 0, raw, width - 1)
        parts.append(code + offset)
        penalties.extend([penalty] * width)
        offset += width
    columns = np.column_stack(parts)
    indptr = np.arange(0, columns.size + 1, len(parts), dtype=np.int64)
    x = csr_matrix((np.ones(columns.size), columns.ravel(), indptr), shape=(len(rows), offset))
    counts = np.asarray(x[:len(train)].sum(axis=0)).ravel()
    selected = (counts > 0) & (counts < len(train))
    return x[:len(train), selected], x[len(train):, selected], np.asarray(penalties)[selected]


def candidate(data, train, query, budget=None):
    started = perf_counter()
    train, query = np.asarray(train, int), np.asarray(query, int)
    if np.intersect1d(train, query).size or train.ndim != 1 or query.ndim != 1:
        raise ValueError("TRAIN and QUERY must be disjoint vectors")
    if not len(train) or not len(query) or "group" not in data.given:
        return legacy.Candidate(NAME, {}), {"status": "inapplicable"}
    indices = [j for j, item in enumerate(data.targets)
               if item.startswith("sc_nstd_") and not data.schema["items"][item].get("gate")]
    if not indices:
        return legacy.Candidate(NAME, {}), {"status": "no_pre_feedback_scores"}
    x, xq, penalties = design(data, train, query)
    labels = np.asarray(data.y[train][:, indices], dtype=np.int64)
    cards = np.asarray([data.ycards[j] for j in indices])
    offsets = np.r_[0, np.cumsum(cards)]
    n, features = x.shape
    width = int(offsets[-1])
    initial = np.zeros((features + 1, width))
    for h, card in enumerate(cards):
        y = labels[:, h]
        counts = np.bincount(y[y >= 0], minlength=card)
        initial[-1, offsets[h]:offsets[h + 1]] = np.log((counts + PRIOR) / (counts.sum() + card * PRIOR))
    groups = []
    for card in sorted(set(cards)):
        heads = np.flatnonzero(cards == card)
        columns = np.concatenate([np.arange(offsets[j], offsets[j + 1]) for j in heads])
        y = labels[:, heads]
        valid = y >= 0
        rr, hh = np.nonzero(valid)
        groups.append((heads, columns, int(card), valid, rr, hh, y[valid]))
    transpose, scale = x.T.tocsr(), float(max(1, n))

    def objective(flat):
        response._checkpoint(budget)
        weights = flat.reshape(features + 1, width)
        logits = x @ weights[:-1] + weights[-1]
        residual, prior_grad = np.zeros_like(logits), np.zeros(width)
        loss = 0.
        for heads, columns, card, valid, rr, hh, truth in groups:
            block = logits[:, columns].reshape(n, len(heads), card)
            norm = logsumexp(block, axis=2)
            loss += np.sum(norm[rr, hh] - block[rr, hh, truth]) / scale
            error = np.exp(block - norm[:, :, None]) * valid[:, :, None]
            error[rr, hh, truth] -= 1.
            residual[:, columns] = error.reshape(n, -1) / scale
            bias = weights[-1, columns].reshape(len(heads), card)
            bn = logsumexp(bias, axis=1)
            loss += PRIOR * np.sum(card * bn - bias.sum(axis=1)) / scale
            prior_grad[columns] = (PRIOR * (card * np.exp(bias - bn[:, None]) - 1) / scale).ravel()
        loss += .5 * np.sum(penalties[:, None] * weights[:-1] ** 2)
        gradient = np.empty_like(weights)
        gradient[:-1] = np.asarray(transpose @ residual) + penalties[:, None] * weights[:-1]
        gradient[-1] = residual.sum(axis=0) + prior_grad
        return float(loss), gradient.ravel()

    fit = minimize(objective, initial.ravel(), method="L-BFGS-B", jac=True,
                   callback=lambda _: response._checkpoint(budget),
                   options={"maxiter": MAX_ITER, "ftol": 1e-8, "gtol": 2e-5})
    if not np.isfinite(fit.x).all():
        raise FloatingPointError("Nonfinite shared-arms fit")
    weights = fit.x.reshape(features + 1, width)
    logits = xq @ weights[:-1] + weights[-1]
    values = {}
    for h, j in enumerate(indices):
        block = logits[:, offsets[h]:offsets[h + 1]]
        values[data.targets[j]] = np.exp(block - logsumexp(block, axis=1)[:, None])
    return legacy.Candidate(NAME, values), {
        "status": "fitted", "model": "multinomial_exact_arm_ties",
        "targets": [data.targets[j] for j in indices], "given": list(data.given),
        "shared_randomized_arms": list(RANDOMIZED),
        "distinct_group_states": ["randomized", "not_randomized", "unknown"],
        "l2_other": CONTENT_L2, "l2_randomization": RANDOMIZATION_L2,
        "constraint": "identical logits for all four arms with other GIVEN fixed",
        "chronology_status": "assessment-before-feedback sourced; sc_* mapping semantic inference",
        "iterations": int(fit.nit), "converged": bool(fit.success),
        "seconds": perf_counter() - started,
    }
