from __future__ import annotations

import numpy as np
from scipy.optimize import minimize

import legacy
import gfic_legacy as gfic

NAME = "WB_ORDINAL_SC"
PREFIX = "sc_nstd_"
MIN_LEVELS = 3
RANK = 3
RIDGE_SHARED = 1.0
RIDGE_ITEM = 20.0
RIDGE_THRESHOLD = 1.0
RIDGE_NA = 20.0
DIFF_PENALTY = 10.0
ORDERED_GIVEN = ("user.age", "user.wageOfSimilarEmployees", "user.lowestAcceptablePay")
NON_LEVELS = {"Not answered"}
INIT_SCALE = 0.01
SEED = 1019
MAX_ITER = 300
EPS = 1e-12


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


def _sigmoid(v):
    return 0.5 * (1.0 + np.tanh(0.5 * v))


def _one_hot(data, rows):
    blocks, spans = [], {}
    offset = 0
    for name in data.given:
        card = len(data.options[name]) + 1
        values = np.asarray(data.codes[name][rows], dtype=np.int64)
        values = np.where((values >= 0) & (values < card - 1), values, card - 1)
        block = np.zeros((len(rows), card))
        block[np.arange(len(rows)), values] = 1.0
        blocks.append(block)
        spans[name] = (offset, card)
        offset += card
    return (np.concatenate(blocks, axis=1) if blocks else np.zeros((len(rows), 0))), spans


def ordered_items(data):
    items = []
    for item in data.targets:
        if not item.startswith(PREFIX):
            continue
        gate = data.schema["items"][item].get("gate")
        if gate and gate["parent"] not in data.given:
            continue
        options = list(data.options[item])
        if gate:
            options = options[:-1]
        levels = [i for i, v in enumerate(options) if v not in NON_LEVELS]
        if len(levels) >= MIN_LEVELS:
            items.append(item)
    return items


def _block(item, options):
    content = [v for v in options if v not in NON_LEVELS]
    return "scale" if content and content[0].startswith("<2.5") else "task"


def _difference_pairs(data, spans, columns):
    position = {c: i for i, c in enumerate(columns)}
    pairs = []
    for name in ORDERED_GIVEN:
        if name not in spans:
            continue
        offset, card = spans[name]
        levels = [i for i, v in enumerate(data.options[name]) if v not in NON_LEVELS]
        for a, b in zip(levels[:-1], levels[1:]):
            if offset + a in position and offset + b in position:
                pairs.append((position[offset + a], position[offset + b]))
    return np.array(pairs, dtype=np.int64).reshape(-1, 2)


def candidate(data, train, query, budget=None):
    _checkpoint(budget)
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    if np.intersect1d(train, query).size or len(np.unique(train)) != len(train):
        raise ValueError("WB ordinal TRAIN must be unique and disjoint from QUERY")
    probabilities = {item: None for item in data.targets}
    items = ordered_items(data)
    details = {"name": NAME, "items": items, "rank": RANK,
               "penalties": {"shared": RIDGE_SHARED, "item": RIDGE_ITEM, "threshold": RIDGE_THRESHOLD,
                             "na": RIDGE_NA, "difference": DIFF_PENALTY},
               "selection": "fixed constants; TRAIN labels only"}
    if not items:
        return legacy.Candidate(NAME, probabilities), details
    x_train_full, spans = _one_hot(data, train)
    x_query_full, _ = _one_hot(data, query)
    counts = x_train_full.sum(axis=0)
    columns = np.flatnonzero((counts > 0) & (counts < len(train)))
    x_train, x_query = x_train_full[:, columns], x_query_full[:, columns]
    p = x_train.shape[1]
    pairs = _difference_pairs(data, spans, columns)
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
    block_names = sorted({_block(item, data.options[item]) for item in items})
    block_index = {name: i for i, name in enumerate(block_names)}
    specs = []
    for item in items:
        options = list(data.options[item])
        law = laws.get(item)
        width = law["sentinel"] if law is not None else len(options)
        content_options = options[:width]
        level_codes = np.array([i for i, v in enumerate(content_options) if v not in NON_LEVELS], dtype=np.int64)
        na_codes = np.array([i for i, v in enumerate(content_options) if v in NON_LEVELS], dtype=np.int64)
        codes = np.asarray(data.codes[item][train], dtype=np.int64)
        valid = (codes >= 0) & (codes < width)
        if law is not None:
            valid &= law["open"][train]
        rows = np.flatnonzero(valid)
        if len(rows) < 30:
            continue
        y = codes[rows]
        is_na = np.isin(y, na_codes)
        level_of = np.full(width, -1, dtype=np.int64)
        level_of[level_codes] = np.arange(len(level_codes))
        level = level_of[y]
        answered = ~is_na
        shares = np.bincount(level[answered], minlength=len(level_codes)) + 0.5
        cumulative = np.cumsum(shares)[:-1] / shares.sum()
        theta0 = np.log(cumulative / (1.0 - cumulative))
        gamma0 = np.log(np.maximum(np.diff(theta0), 1e-3))
        na_rate = (is_na.sum() + 0.5) / (len(y) + 1.0)
        specs.append({"item": item, "law": law, "width": width, "levels": level_codes, "na_codes": na_codes,
                      "block": block_index[_block(item, options)], "x": x_train[rows],
                      "level": level, "is_na": is_na, "answered": answered,
                      "theta0": theta0[0], "gamma0": gamma0, "a0": float(np.log(na_rate / (1 - na_rate))),
                      "K": len(level_codes)})
    if not specs:
        return legacy.Candidate(NAME, probabilities), details
    rng = np.random.default_rng(SEED)
    n_items, n_blocks = len(specs), len(block_names)
    sizes = [("L", p * RANK), ("V", n_items * RANK), ("D", n_items * p), ("T", n_items),
             ("G", int(sum(s["K"] - 2 for s in specs))), ("A", n_items), ("C", n_blocks * p)]
    total_rows = float(sum(len(s["level"]) for s in specs))

    def unpack(flat):
        parts, offset = {}, 0
        for name, size in sizes:
            parts[name] = flat[offset:offset + size]
            offset += size
        L = parts["L"].reshape(p, RANK)
        V = parts["V"].reshape(n_items, RANK)
        D = parts["D"].reshape(n_items, p)
        G, g_offset = [], 0
        for s in specs:
            G.append(parts["G"][g_offset:g_offset + s["K"] - 2])
            g_offset += s["K"] - 2
        C = parts["C"].reshape(n_blocks, p)
        return L, V, D, parts["T"], G, parts["A"], C

    def thresholds(theta1, gamma):
        return np.concatenate(([theta1], theta1 + np.cumsum(np.exp(gamma))))

    def content_probabilities(eta, theta):
        F = _sigmoid(theta[None, :] - eta[:, None])
        F_full = np.concatenate((np.zeros((len(eta), 1)), F, np.ones((len(eta), 1))), axis=1)
        return np.diff(F_full, axis=1), F

    def objective(flat):
        L, V, D, T, G, A, C = unpack(flat)
        loss = 0.0
        gL, gV, gD, gT, gA, gC = np.zeros_like(L), np.zeros_like(V), np.zeros_like(D), np.zeros_like(T), np.zeros_like(A), np.zeros_like(C)
        gG = []
        for j, s in enumerate(specs):
            x = s["x"]
            logit_na = A[j] + x @ C[s["block"]]
            pi = _sigmoid(logit_na)
            loss -= np.sum(np.where(s["is_na"], np.log(np.maximum(pi, EPS)), np.log(np.maximum(1 - pi, EPS))))
            d_na = pi - s["is_na"]
            gA[j] = d_na.sum()
            gC[s["block"]] += x.T @ d_na
            xa = x[s["answered"]]
            lev = s["level"][s["answered"]]
            beta = L @ V[j] + D[j]
            eta = xa @ beta
            theta = thresholds(T[j], G[j])
            prob, F = content_probabilities(eta, theta)
            f = F * (1 - F)
            f_full = np.concatenate((np.zeros((len(eta), 1)), f, np.zeros((len(eta), 1))), axis=1)
            rows = np.arange(len(lev))
            p_obs = np.maximum(prob[rows, lev], EPS)
            loss -= np.log(p_obs).sum()
            d_eta = (f_full[rows, lev + 1] - f_full[rows, lev]) / p_obs
            d_theta = np.zeros(s["K"] - 1)
            upper = lev + 1 <= s["K"] - 1
            np.add.at(d_theta, lev[upper], -(f_full[rows, lev + 1] / p_obs)[upper])
            lower = lev >= 1
            np.add.at(d_theta, lev[lower] - 1, (f_full[rows, lev] / p_obs)[lower])
            gT[j] = d_theta.sum()
            gG.append(np.exp(G[j]) * np.cumsum(d_theta[::-1])[::-1][1:])
            d_beta = xa.T @ d_eta
            gL += np.outer(d_beta, V[j])
            gV[j] = L.T @ d_beta
            gD[j] = d_beta
        penalty = (RIDGE_SHARED * (np.sum(L ** 2) + np.sum(V ** 2)) + RIDGE_ITEM * np.sum(D ** 2)
                   + RIDGE_THRESHOLD * (np.sum((T - np.array([s["theta0"] for s in specs])) ** 2)
                                        + sum(np.sum((g - s["gamma0"]) ** 2) for g, s in zip(G, specs)))
                   + RIDGE_NA * np.sum(C ** 2))
        gL += 2 * RIDGE_SHARED * L
        gV += 2 * RIDGE_SHARED * V
        gD += 2 * RIDGE_ITEM * D
        gT += 2 * RIDGE_THRESHOLD * (T - np.array([s["theta0"] for s in specs]))
        gG = [g_grad + 2 * RIDGE_THRESHOLD * (g - s["gamma0"]) for g_grad, g, s in zip(gG, G, specs)]
        gC += 2 * RIDGE_NA * C
        if len(pairs):
            dL = L[pairs[:, 1]] - L[pairs[:, 0]]
            dD = D[:, pairs[:, 1]] - D[:, pairs[:, 0]]
            penalty += DIFF_PENALTY * (np.sum(dL ** 2) + np.sum(dD ** 2))
            np.add.at(gL, pairs[:, 1], 2 * DIFF_PENALTY * dL)
            np.add.at(gL, pairs[:, 0], -2 * DIFF_PENALTY * dL)
            np.add.at(gD.T, pairs[:, 1], 2 * DIFF_PENALTY * dD.T)
            np.add.at(gD.T, pairs[:, 0], -2 * DIFF_PENALTY * dD.T)
        gradient = np.concatenate([gL.ravel(), gV.ravel(), gD.ravel(), gT.ravel(),
                                   np.concatenate(gG) if gG else np.zeros(0), gA.ravel(), gC.ravel()])
        return (loss + penalty) / total_rows, gradient / total_rows

    initial = np.concatenate([
        INIT_SCALE * rng.standard_normal(p * RANK), INIT_SCALE * rng.standard_normal(n_items * RANK),
        np.zeros(n_items * p), np.array([s["theta0"] for s in specs]),
        np.concatenate([s["gamma0"] for s in specs]) if specs else np.zeros(0),
        np.array([s["a0"] for s in specs]), np.zeros(n_blocks * p)])
    _checkpoint(budget)
    result = minimize(objective, initial, method="L-BFGS-B", jac=True,
                      callback=lambda _: _checkpoint(budget),
                      options={"maxiter": MAX_ITER, "maxls": 25, "ftol": 1e-9, "gtol": 1e-6})
    _checkpoint(budget)
    if not np.isfinite(result.x).all() or not np.isfinite(result.fun):
        raise FloatingPointError("Nonfinite WB_ORDINAL_SC fit")
    L, V, D, T, G, A, C = unpack(result.x)
    details.update(converged=bool(result.success), iterations=int(result.nit), evaluations=int(result.nfev),
                   objective=float(result.fun), columns=int(p), blocks=block_names,
                   difference_pairs=int(len(pairs)), fitted_items={s["item"]: int(len(s["level"])) for s in specs})
    for j, s in enumerate(specs):
        eta = x_query @ (L @ V[j] + D[j])
        prob_content, _ = content_probabilities(eta, thresholds(T[j], G[j]))
        pi = _sigmoid(A[j] + x_query @ C[s["block"]])
        full = np.zeros((len(query), s["width"]))
        full[:, s["levels"]] = prob_content * (1 - pi)[:, None]
        if len(s["na_codes"]):
            full[:, s["na_codes"]] = (pi / len(s["na_codes"]))[:, None]
        else:
            full /= full.sum(axis=1, keepdims=True)
        if s["law"] is not None:
            full = gfic.compose_gate(full, s["law"], query)
        if (full.shape != (len(query), len(data.options[s["item"]])) or not np.isfinite(full).all()
                or np.any(full < 0) or not np.allclose(full.sum(axis=1), 1.0, atol=1e-9, rtol=0)):
            raise FloatingPointError("Invalid WB_ORDINAL_SC probabilities")
        probabilities[s["item"]] = full
    _checkpoint(budget)
    return legacy.Candidate(NAME, probabilities), details
