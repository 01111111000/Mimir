from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize


@dataclass(frozen=True)
class PoolState:
    weights: np.ndarray
    prior_weights: np.ndarray
    gate_index: int | None
    na_index: int | None
    temperature: float = 1.0
    marginal_blend: float = 0.0
    output_floor: float = 1e-9
    diagnostics: dict | None = None


def _probabilities(value):
    p = np.asarray(value, dtype=float)
    if p.ndim != 3 or min(p.shape[0], p.shape[2]) < 1:
        raise ValueError("Expected member x respondent x option probabilities")
    total = p.sum(axis=2, keepdims=True)
    if not np.isfinite(p).all() or (p < 0).any() or (total <= 0).any():
        raise ValueError("Probabilities must be finite, nonnegative, and nonempty")
    return p / total


def _indices(width, gate_index, na_index):
    special = [i for i in (gate_index, na_index) if i is not None]
    if any(not isinstance(i, (int, np.integer)) or i < 0 or i >= width for i in special):
        raise ValueError("Response-state index outside the option support")
    if len(special) != len(set(special)):
        raise ValueError("Gate and Not answered must be different options")
    content = np.array([i for i in range(width) if i not in special], dtype=int)
    if not len(content):
        raise ValueError("At least one substantive option is required")
    return content


def _prior(value, members):
    prior = np.asarray(value, dtype=float)
    if prior.shape != (members,) or not np.isfinite(prior).all() or (prior < 0).any() or prior.sum() <= 0:
        raise ValueError("Invalid prior member weights")
    return prior / prior.sum()


def _marginal(value, shape, blend):
    if value is None:
        if blend:
            raise ValueError("Fixed marginal calibration requires marginal_probs")
        return np.full(shape, 1.0 / shape[1])
    p = np.asarray(value, dtype=float)
    if p.shape != shape or not np.isfinite(p).all() or (p < 0).any() or (p.sum(1) <= 0).any():
        raise ValueError("Invalid marginal probabilities")
    return p / p.sum(1, keepdims=True)


def _pool(p, weights, prior, gate_index, na_index):
    members, rows, width = p.shape
    content = _indices(width, gate_index, na_index)
    gate = p[:, :, gate_index] if gate_index is not None else np.zeros((members, rows))
    na = p[:, :, na_index] if na_index is not None else np.zeros((members, rows))
    substantive = p[:, :, content]
    substantive_mass = substantive.sum(2)
    ungated = 1.0 - gate
    g = weights[0] @ gate if gate_index is not None else np.zeros(rows)
    na_denominator = weights[1] @ ungated
    na_numerator = weights[1] @ na
    reference_na_denominator = prior @ ungated
    reference_na = np.divide(prior @ na, reference_na_denominator,
                             out=np.zeros(rows), where=reference_na_denominator > 0)
    n = np.divide(na_numerator, na_denominator, out=reference_na.copy(), where=na_denominator > 0)
    if na_index is None:
        n[:] = 0.0
    content_denominator = weights[2] @ substantive_mass
    content_numerator = np.einsum('m,mnk->nk', weights[2], substantive)
    reference_content_denominator = prior @ substantive_mass
    reference_content = np.divide(np.einsum('m,mnk->nk', prior, substantive),
                                  reference_content_denominator[:, None],
                                  out=np.full((rows, len(content)), 1.0 / len(content)),
                                  where=reference_content_denominator[:, None] > 0)
    c = np.divide(content_numerator, content_denominator[:, None],
                  out=reference_content.copy(), where=content_denominator[:, None] > 0)
    result = np.zeros((rows, width))
    if gate_index is not None:
        result[:, gate_index] = g
    if na_index is not None:
        result[:, na_index] = (1.0 - g) * n
    result[:, content] = ((1.0 - g) * (1.0 - n))[:, None] * c
    cache = (content, gate, na, substantive, substantive_mass, ungated,
             g, n, c, na_denominator, content_denominator)
    return result, cache


def _pool_vjp(gradient, cache, gate_index, na_index):
    (content, gate, na, substantive, substantive_mass, ungated,
     g, n, c, na_denominator, content_denominator) = cache
    gradient_content = gradient[:, content]
    content_dot = np.sum(gradient_content * c, axis=1)
    result = np.zeros((3, gate.shape[0]))
    if gate_index is not None:
        gradient_g = gradient[:, gate_index] - (1.0 - n) * content_dot
        if na_index is not None:
            gradient_g -= n * gradient[:, na_index]
        result[0] = gate @ gradient_g
    if na_index is not None:
        gradient_n = (1.0 - g) * (gradient[:, na_index] - content_dot)
        derivative_n = np.divide(na - n[None, :] * ungated, na_denominator[None, :],
                                 out=np.zeros_like(na), where=na_denominator[None, :] > 0)
        result[1] = derivative_n @ gradient_n
    gradient_c = ((1.0 - g) * (1.0 - n))[:, None] * gradient_content
    derivative_dot = (np.einsum('mnk,nk->mn', substantive, gradient_c)
                      - substantive_mass * np.sum(c * gradient_c, axis=1)[None, :])
    derivative_dot = np.divide(derivative_dot, content_denominator[None, :],
                               out=np.zeros_like(derivative_dot), where=content_denominator[None, :] > 0)
    result[2] = derivative_dot.sum(1)
    return result


def _post_transform(p, marginal, temperature, blend, output_floor):
    tiny = np.finfo(float).tiny
    logits = np.log(np.maximum(p, tiny)) / temperature
    powered = np.exp(logits - logits.max(1, keepdims=True))
    powered /= powered.sum(1, keepdims=True)
    raw = (1.0 - blend) * powered + blend * marginal
    clipped = np.maximum(raw, output_floor)
    total = clipped.sum(1, keepdims=True)
    out = clipped / total
    return out, (p, powered, raw, total, out)


def _post_vjp(gradient, cache, temperature, blend, output_floor):
    p, powered, raw, total, out = cache
    gradient = (gradient - np.sum(gradient * out, axis=1, keepdims=True)) / total
    gradient *= raw > output_floor
    gradient *= 1.0 - blend
    gradient = powered * (gradient - np.sum(gradient * powered, axis=1, keepdims=True)) / temperature
    return np.divide(gradient, p, out=np.zeros_like(gradient), where=p > np.finfo(float).tiny)


def _objective(flat, p, labels, prior, gate_index, na_index, marginal,
               temperature, blend, output_floor, metric_floor, strength):
    weights = flat.reshape(3, len(prior))
    pooled, pool_cache = _pool(p, weights, prior, gate_index, na_index)
    out, post_cache = _post_transform(pooled, marginal, temperature, blend, output_floor)
    rows = np.arange(len(labels))
    multiplier = 1.0 - p.shape[2] * metric_floor
    scored = metric_floor + multiplier * out[rows, labels]
    gradient = np.zeros_like(out)
    gradient[rows, labels] = -multiplier / np.maximum(scored, np.finfo(float).tiny)
    gradient_weights = _pool_vjp(_post_vjp(gradient, post_cache, temperature, blend, output_floor),
                                 pool_cache, gate_index, na_index)
    active = np.array([gate_index is not None, na_index is not None, True])
    safe = np.maximum(weights, 1e-12)
    penalty = -strength * np.sum(prior[None, :] * np.log(safe) * active[:, None])
    gradient_weights -= strength * prior[None, :] / safe * active[:, None]
    loss = -np.log(np.maximum(scored, np.finfo(float).tiny)).sum() + penalty
    scale = max(1.0, len(labels) + strength * active.sum())
    return float(loss / scale), gradient_weights.ravel() / scale


def fit_item(probabilities, labels, prior_weights, *, gate_index=None, na_index=None,
             metric_floor=1e-3, strength=200.0, temperature=1.0, marginal_blend=0.0,
             marginal_probs=None, output_floor=1e-9, max_iter=80, budget=None, solver='slsqp'):
    p = _probabilities(probabilities)
    members, rows, width = p.shape
    _indices(width, gate_index, na_index)
    prior = _prior(prior_weights, members)
    if not np.isfinite([metric_floor, strength, temperature, marginal_blend, output_floor]).all():
        raise ValueError("Nonfinite hyperparameter")
    if not 0 <= metric_floor < 1 / width or strength < 0 or temperature <= 0 or not 0 <= marginal_blend <= 1 or output_floor < 0:
        raise ValueError("Invalid floor, penalty, temperature, or marginal blend")
    labels = np.asarray(labels)
    if labels.shape != (rows,) or not np.isfinite(labels).all() or not np.array_equal(labels, labels.astype(int)):
        raise ValueError("Labels must be finite integer option indices")
    labels = labels.astype(int)
    if ((labels < -1) | (labels >= width)).any():
        raise ValueError("Label outside option support")
    marginal = _marginal(marginal_probs, (rows, width), marginal_blend)
    valid = labels >= 0
    p, labels, marginal = p[:, valid], labels[valid], marginal[valid]
    initial = np.tile(prior, (3, 1))
    diagnostics = {'training_rows': int(valid.sum()), 'total_rows': rows,
                   'optimizer_success': None, 'accepted_train_objective': False,
                   'claim': 'TRAIN optimization only; no measured generalization gain'}
    if not len(labels) or members == 1:
        diagnostics['status'] = 'identity_empty_labels' if not len(labels) else 'identity_single_member'
        return PoolState(initial, prior, gate_index, na_index, temperature, marginal_blend, output_floor, diagnostics)

    def check():
        if budget is not None:
            budget.checkpoint()

    def objective(flat):
        check()
        return _objective(flat, p, labels, prior, gate_index, na_index, marginal,
                          temperature, marginal_blend, output_floor, metric_floor, strength)

    active = [gate_index is not None, na_index is not None, True]
    if solver == 'softmax':
        return _fit_softmax(objective, initial, prior, active, gate_index, na_index, temperature,
                            marginal_blend, output_floor, diagnostics, check)
    if solver != 'slsqp':
        raise ValueError('Unknown factorized pool solver: %r' % (solver,))
    bounds = [(0.0, 1.0) if active[stage] else (float(prior[m]), float(prior[m]))
              for stage in range(3) for m in range(members)]
    constraint_matrix = np.kron(np.eye(3), np.ones((1, members)))[np.asarray(active)]
    constraints = {'type': 'eq', 'fun': lambda w: constraint_matrix @ w - 1.0,
                   'jac': lambda w: constraint_matrix}
    baseline, _ = objective(initial.ravel())
    fitted = minimize(objective, initial.ravel(), method='SLSQP', jac=True, bounds=bounds,
                      constraints=constraints, callback=lambda _: check(),
                      options={'maxiter': int(max_iter), 'ftol': 1e-10})
    check()
    chosen = initial
    diagnostics.update(optimizer_success=bool(fitted.success), optimizer_status=int(fitted.status),
                       optimizer_message=str(fitted.message), iterations=int(fitted.nit),
                       baseline_penalized_objective=baseline)
    if np.isfinite(fitted.x).all():
        candidate = np.maximum(fitted.x.reshape(3, members), 0.0)
        if (candidate.sum(1) > 0).all():
            candidate /= candidate.sum(1, keepdims=True)
            for stage in range(3):
                if not active[stage]:
                    candidate[stage] = prior
            value, _ = objective(candidate.ravel())
            diagnostics['candidate_penalized_objective'] = value
            if np.isfinite(value) and value <= baseline + 1e-12:
                chosen = candidate
                diagnostics['accepted_train_objective'] = True
    diagnostics['status'] = 'fitted' if diagnostics['accepted_train_objective'] else 'identity_optimizer_rejected'
    return PoolState(chosen, prior, gate_index, na_index, temperature, marginal_blend, output_floor, diagnostics)


SOFTMAX_MAX_ITER = 1000
SOFTMAX_START_MIX = 1e-2


def _fit_softmax(objective, initial, prior, active, gate_index, na_index, temperature,
                 marginal_blend, output_floor, diagnostics, check):
    members = len(prior)
    stages = [stage for stage in range(3) if active[stage]]

    def unpack(theta):
        weights = np.tile(prior, (3, 1))
        for k, stage in enumerate(stages):
            t = theta[k * members:(k + 1) * members]
            z = np.exp(t - t.max())
            weights[stage] = z / z.sum()
        return weights

    def function(theta):
        weights = unpack(theta)
        value, gradient = objective(weights.ravel())
        gradient = gradient.reshape(3, members)
        out = np.empty(len(stages) * members)
        for k, stage in enumerate(stages):
            w, g = weights[stage], gradient[stage]
            out[k * members:(k + 1) * members] = w * (g - w @ g)
        return value, out

    baseline, _ = objective(initial.ravel())
    start = np.tile(np.log((1.0 - SOFTMAX_START_MIX) * prior + SOFTMAX_START_MIX / members), len(stages))
    fitted = minimize(function, start, method='L-BFGS-B', jac=True, callback=lambda _: check(),
                      options={'maxiter': SOFTMAX_MAX_ITER, 'ftol': 1e-12, 'gtol': 1e-9, 'maxls': 50})
    check()
    chosen = initial
    diagnostics.update(solver='softmax_lbfgs', optimizer_success=bool(fitted.success),
                       optimizer_status=int(fitted.status), optimizer_message=str(fitted.message),
                       iterations=int(fitted.nit), baseline_penalized_objective=baseline)
    if np.isfinite(fitted.x).all():
        candidate = unpack(fitted.x)
        value, _ = objective(candidate.ravel())
        diagnostics['candidate_penalized_objective'] = value
        if np.isfinite(value) and value <= baseline + 1e-12:
            chosen = candidate
            diagnostics['accepted_train_objective'] = True
    diagnostics['status'] = 'fitted' if diagnostics['accepted_train_objective'] else 'identity_optimizer_rejected'
    return PoolState(chosen, prior, gate_index, na_index, temperature, marginal_blend, output_floor, diagnostics)


def predict_item(probabilities, state, *, marginal_probs=None):
    p = _probabilities(probabilities)
    prior = _prior(state.prior_weights, p.shape[0])
    weights = np.asarray(state.weights, dtype=float)
    if weights.shape != (3, len(prior)) or not np.isfinite(weights).all() or (weights < 0).any() or (weights.sum(1) <= 0).any():
        raise ValueError("Invalid fitted response-state weights")
    weights = weights / weights.sum(1, keepdims=True)
    marginal = _marginal(marginal_probs, (p.shape[1], p.shape[2]), state.marginal_blend)
    pooled, _ = _pool(p, weights, prior, state.gate_index, state.na_index)
    result, _ = _post_transform(pooled, marginal, state.temperature, state.marginal_blend, state.output_floor)
    return result
