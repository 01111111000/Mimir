import numpy as np
from scipy import sparse
from scipy.special import softmax, logsumexp
from scipy.optimize import minimize

from kdb import mi, cmi, conditional_counts


def _packed_pair(train, query=None):
    train = np.asarray(train)
    query = None if query is None else np.asarray(query)
    if train.ndim != 2 or not train.shape[0] or not train.shape[1]:
        return None
    if train.dtype.kind not in "iu" or (query is not None and query.dtype.kind not in "iu"):
        return None
    if query is not None and (query.ndim != 2 or query.shape[1] != train.shape[1]):
        return None
    lows, widths, product = [], [], 1
    for j in range(train.shape[1]):
        low, high = int(train[:, j].min()), int(train[:, j].max())
        if query is not None and len(query):
            low = min(low, int(query[:, j].min()))
            high = max(high, int(query[:, j].max()))
        width = high - low + 1
        product *= width
        if product > np.iinfo(np.int64).max or low < np.iinfo(np.int64).min or high > np.iinfo(np.int64).max:
            return None
        lows.append(low)
        widths.append(width)
    def encode(values):
        result = np.zeros(len(values), dtype=np.int64)
        for j, (low, width) in enumerate(zip(lows, widths)):
            result = result * width + (values[:, j].astype(np.int64, copy=False) - low)
        return result
    return encode(train), None if query is None else encode(query)


def unique_rows(values):
    values = np.asarray(values)
    packed = _packed_pair(values)
    if packed is None:
        return np.unique(values, axis=0, return_inverse=True)
    _, first, inverse = np.unique(packed[0], return_index=True, return_inverse=True)
    return values[first], inverse


def prefix_design(train, query):
    nr, nq = len(train), len(query)
    rr = [np.arange(nr)]
    cc = [np.zeros(nr, dtype=int)]
    rq = [np.arange(nq)]
    cq = [np.zeros(nq, dtype=int)]
    offset = 1
    for d in range(1, train.shape[1] + 1):
        packed = _packed_pair(train[:, :d], query[:, :d])
        if packed is None:
            vocab = {key: i for i, key in enumerate(sorted(set(map(tuple, train[:, :d]))))}
            codes = np.fromiter((vocab[tuple(row)] for row in train[:, :d]), dtype=int, count=nr)
            qcodes = np.fromiter((vocab.get(tuple(row), -1) for row in query[:, :d]), dtype=int, count=nq)
            count = len(vocab)
        else:
            train_keys, query_keys = packed
            vocab, codes = np.unique(train_keys, return_inverse=True)
            qcodes = np.searchsorted(vocab, query_keys)
            in_range = qcodes < len(vocab)
            valid = np.zeros(nq, dtype=bool)
            valid[in_range] = vocab[qcodes[in_range]] == query_keys[in_range]
            qcodes = np.where(valid, qcodes, -1)
            count = len(vocab)
        rr.append(np.arange(nr))
        cc.append(offset + codes)
        valid = qcodes >= 0
        rq.append(np.flatnonzero(valid))
        cq.append(offset + qcodes[valid])
        offset += count
    def build(rows, columns, n):
        rows, columns = np.concatenate(rows), np.concatenate(columns)
        return sparse.csr_matrix((np.ones(len(rows)), (rows, columns)), shape=(n, offset))
    return build(rr, cc, nr), build(rq, cq, nq)


def conditional_hls(context,y,qcontext,width,l2=1.,max_iter=60):
    qcontext,qinv=unique_rows(qcontext)
    contexts,inv=unique_rows(context)
    counts=np.bincount(inv*width+y,minlength=len(contexts)*width).reshape(len(contexts),width).astype(float)
    design,qdesign=prefix_design(contexts,qcontext)
    totals=counts.sum(1);n=totals.sum();npar=design.shape[1]
    initial=np.zeros((npar,width));initial[0]=np.log((counts.sum(0)+.5)/(n+.5*width))
    def obj(flat):
        b=flat.reshape(npar,width);z=design@b;p=softmax(z,axis=1)
        loss=np.sum(totals*logsumexp(z,axis=1))-np.sum(counts*z)+.5*l2*np.sum(b*b)
        grad=design.T@(totals[:,None]*p-counts)+l2*b
        return float(loss/n),np.asarray(grad/n).ravel()
    fit=minimize(obj,initial.ravel(),jac=True,method='L-BFGS-B',options={'maxiter':max_iter,'ftol':1e-8,'gtol':1e-6})
    params=fit.x if np.isfinite(fit.fun) and fit.fun<=obj(initial.ravel())[0] else initial.ravel()
    return softmax(qdesign@params.reshape(npar,width),axis=1)[qinv],{'iterations':int(fit.nit),'converged':bool(fit.success),'parameters':int(len(params))}


def predict_kdb(x,cards,y,width,train,query,k=1,smoothing='hls',parent_main=False,max_iter=60):
    x=np.asarray(x,dtype=np.int64);y=np.asarray(y,dtype=np.int64);cards=np.asarray(cards,dtype=np.int64)
    train=np.asarray(train);query=np.asarray(query)
    train=train[(y[train]>=0)&(y[train]<width)]
    if not len(train):return np.ones((len(query),width))/width,{'empty_train':True}
    a=x[train];b=x[query];target=y[train];d=a.shape[1]
    prior=(np.bincount(target,minlength=width)+.5)/(len(target)+.5*width)
    order=sorted(range(d),key=lambda j:-mi(a[:,j],target,cards[j],width))
    cm=np.zeros((d,d))
    for i in range(d):
        for j in range(i):cm[i,j]=cm[j,i]=cmi(a[:,i],a[:,j],target,cards[i],cards[j],width)
    logp=np.tile(np.log(prior),(len(query),1));details=[]
    qclasses=np.tile(np.arange(width),len(query))
    for pos,j in enumerate(order):
        parents=sorted(order[:pos],key=lambda h:-cm[j,h])[:k]
        context=np.column_stack(([a[:,h] for h in parents]+[target]) if parent_main else ([target]+[a[:,h] for h in parents]))
        qcontext=np.column_stack(([np.repeat(b[:,h],width) for h in parents]+[qclasses]) if parent_main else ([qclasses]+[np.repeat(b[:,h],width) for h in parents]))
        fn=conditional_hls if smoothing=='hls' else conditional_counts
        probs,detail=(fn(context,a[:,j],qcontext,int(cards[j]),max_iter=max_iter) if smoothing=='hls'
                      else fn(context,a[:,j],qcontext,int(cards[j])))
        selected=probs[np.arange(len(qclasses)),np.repeat(b[:,j],width)].reshape(len(query),width)
        logp+=np.log(np.maximum(selected,1e-300));details.append(detail)
    return softmax(logp,axis=1),{'order':order,'fits':details}
