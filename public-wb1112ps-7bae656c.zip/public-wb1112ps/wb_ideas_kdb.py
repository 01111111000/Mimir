from time import perf_counter

import numpy as np
from scipy.optimize import minimize_scalar
from threadpoolctl import threadpool_limits

import legacy
import gfic_legacy as gfic
import kdb_runtime


def candidate(data, train, query, budget=None, *, parent_main=True):
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    gate_config = gfic.Config(gate_factor=True, item_calibration=True)
    laws = gfic.gate_laws(data, train, gate_config)
    labels, cards = gfic.content_targets(data, laws, train)
    values, details = {}, {}
    for column, item in enumerate(data.targets):
        if budget is not None:
            budget.checkpoint()
        started = perf_counter()
        with threadpool_limits(limits=1, user_api="blas"):
            p, detail = kdb_runtime.predict_kdb(
                data.x, data.xcards, labels[:, column], cards[column],
                train, query, k=2, smoothing="hls", parent_main=bool(parent_main))
        if item in laws:
            p = gfic.compose_gate(p, laws[item], query)
        values[item] = p
        details[item] = {"seconds": perf_counter() - started, **detail}
    return legacy.Candidate("KDB2", values), {
        "k": 2, "ridge": 1.0, "max_iter": 60, "prior": 0.5,
        "parent_main": bool(parent_main),
        "blas_threads": 1, "gate_items": list(laws), "items": details,
        "temperature": "raw; use the same downstream route as KDB_HLS1",
    }


def temper_plans(plans, outer, final, complete, data, config,
                 budget=None, member="KDB2"):
    import nonerpis
    complete = np.asarray(complete, dtype=np.int64)
    oof = nonerpis._collect(plans, outer, complete, data.schema)[member]
    details, pending = [], []
    for index, plan in enumerate(plans):
        keep = np.isin(complete, plan["train"])
        pair = {}
        for item in data.targets:
            if budget is not None:
                budget.checkpoint()
            p = oof.probabilities[item][keep]
            y = data.codes[item][complete[keep]]
            valid = y >= 0
            logp = np.log(np.maximum(p[valid], 1e-300))
            y = y[valid]

            def objective(temperature):
                logits = logp / temperature
                q = np.exp(logits - logits.max(1, keepdims=True))
                q /= q.sum(1, keepdims=True)
                truth = q[np.arange(len(y)), y]
                score = config.metric_floor + (1 - p.shape[1] * config.metric_floor) * truth
                return -float(np.log(score).mean()) if len(y) else 0.0

            temperature = (float(minimize_scalar(objective, bounds=(0.4, 3.0),
                                                method="bounded").x) if len(y) else 1.0)
            temperature = (len(y) * temperature + config.weight_k) / (len(y) + config.weight_k)
            q = plan["bank"][member].probabilities[item]
            pending.append((plan, item, gfic.calibrate(q, q, temperature, 0.0)))
            pair[item] = temperature
        details.append({"plan": index, "temperatures": pair,
                        "training_rows": int(keep.sum())})
    for plan, item, value in pending:
        plan["bank"][member].probabilities[item] = value
    return details
