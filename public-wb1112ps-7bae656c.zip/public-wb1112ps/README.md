# SimulacraBench World Bank submission wb1112ps

The Mimir team's submission to SimulacraBench, the NeurIPS 2026 competition on predicting survey answers. `main.py` defines `predict(frame, schema)`, as the competition contract requires: it learns from the visible respondents of the frame it receives and returns one probability vector per hidden cell.

The World Bank instrument is answered by a stacked ensemble of count, kernel, ridge, forest, reduced-rank and neural models, TabICL v2 and, in phase 2 on a CUDA GPU, Kumo Tabular large, combined by a meta-model with a factorized probability pool. UNICEF and UNHCR use reduced count-based routes.

This code is the code of the archive `simulacrabench-wb1112ps-c2e7eee1.zip`, with comments and docstrings removed. It holds the 37 Python modules that the submission imports. The archive also held four modules that no code imports, an inactive earlier route; they are left out.

| Submitted archive | |
|---|---|
| File | `simulacrabench-wb1112ps-c2e7eee1.zip` |
| Size | 896,974,708 bytes |
| SHA-256 | `c2e7eee14d0aa81bd81e1b65803424a23572aa1466fc201fc1d9d6c0b631fbe9` |

Besides the code, the archive bundled the two model checkpoints, their licence texts and provenance files, and a short method note. They are not in this repository; `download_weights.py` fetches the checkpoints.

## Install

Python 3.13 was used. The competition runtime is 8 CPUs, 16 GB of RAM and one H100 GPU, with no network during prediction.

```bash
pip install -r requirements.txt
```

## Get the weights

```bash
python download_weights.py
```

The script downloads the two checkpoints from Hugging Face at the pinned revisions below, writes them where the code loads them, and checks the SHA-256 the code checks at import.

| Written to | Source | Revision | SHA-256 checked |
|---|---|---|---|
| `models/kumo-tabular-large-classifier.pt` | `nvidia/Kumo-Tabular`, `large/classifier.pt` | `3c3e10bbdb590ace29e7026847f92db3c603096d` (v1.0.1) | `cc21484316949641cc3d65a7bb6c36cdea854cc569435755ff23b850018ec613` |
| `models/tabicl-v2.ckpt.gz` | `jingang/TabICL`, `tabicl-classifier-v2-20260212.ckpt` | `4dcd344ece2c00be9e831fdd35bed57b5ad83e19` | `bdc7dbd5e4ff21f8f0456fcf90c6b7cdf72dbea960f2d05b19bec19f9b3d4ed0` (decompressed) |

The TabICL checkpoint is stored gzip-compressed. Kumo Tabular is used only in phase 2, and only when CUDA is available.

## Score with the official kit

From the root of this repository, after downloading the weights:

```bash
SUBMISSION=$(pwd)
```

```bash
git clone https://github.com/SituatedEvals/public ../simulacrabench-kit
```

```bash
cd ../simulacrabench-kit && git checkout aa03186f8f083c7785a1a566c802c2077925e265
```

```bash
pip install -r requirements.txt
```

```bash
python make_sandbox.py --schema data/world_bank.json --out _sandbox/world_bank
```

```bash
python score.py --submission "$SUBMISSION" --data _sandbox/world_bank --schema data/world_bank.json --phase 2
```

Replace `world_bank` with `unicef` or `unhcr` for the other two instruments, and `--phase 2` with `--phase 1` for the development phase. `score.py` installs `requirements.txt` in a fresh virtual environment, calls `predict()` with the network off, and prints `PASS` with the score. The sandbox holds synthetic data of the real shape: its scores are not leaderboard scores.

## Licence

Apache License 2.0, see `LICENSE`. Third-party components keep their own licences, listed in `NOTICE`.
