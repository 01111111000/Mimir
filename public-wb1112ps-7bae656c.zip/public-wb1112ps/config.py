from dataclasses import dataclass
import os

CGROUP_V1_DIRECTORIES = ('/sys/fs/cgroup/cpu', '/sys/fs/cgroup/cpu,cpuacct')
CGROUP_V2_CPU_MAX = '/sys/fs/cgroup/cpu.max'


def _read(path):
    try:
        with open(path) as handle:
            return handle.read().strip()
    except (OSError, ValueError):
        return None


def cpu_limits():
    try:
        affinity = len(os.sched_getaffinity(0))
    except Exception:
        affinity = os.cpu_count() or 8
    limits = {'affinity': affinity, 'cgroup_version': None, 'quota_us': None,
              'period_us': None, 'quota_cpus': None}
    try:
        for directory in CGROUP_V1_DIRECTORIES:
            quota = _read(directory + '/cpu.cfs_quota_us')
            period = _read(directory + '/cpu.cfs_period_us')
            if quota is not None and period is not None:
                limits.update(cgroup_version=1, quota_us=int(quota), period_us=int(period))
                break
        else:
            fields = (_read(CGROUP_V2_CPU_MAX) or '').split()
            if len(fields) == 2:
                limits.update(cgroup_version=2, period_us=int(fields[1]),
                              quota_us=-1 if fields[0] == 'max' else int(fields[0]))
        quota, period = limits['quota_us'], limits['period_us']
        if quota is not None and quota > 0 and period:
            limits['quota_cpus'] = -(-quota // period)
    except Exception as error:
        limits['error'] = type(error).__name__
    cap = min(8, affinity) if limits['quota_cpus'] is None else min(8, affinity, limits['quota_cpus'])
    limits['threads'] = max(1, cap)
    return limits


CPU_LIMITS = cpu_limits()
THREADS = CPU_LIMITS['threads']

BASE_FAMILIES = ('C1', 'C2', 'C3', 'C4', 'C5', 'C7', 'C8', 'C9', 'C10')
WB_BASE_FAMILIES = tuple(n for n in BASE_FAMILIES if n not in ('C1', 'C4', 'C5', 'C8'))
TABICL_ITEMS = {
    1: (
        'user.howManyHoursSearchedPerWeek',
        'user.howLongSearchingForJob',
        'user.howLongUnemployed',
        'user.howManyApplicationsLastMonth',
        'user.expectedToFindJobInSixMonths',
    ),
    2: (
        'user.wageOfSimilarEmployeesAfter',
        'user.preferredSector',
        'sc_nstd_social',
        'sc_nstd_invest',
        'user.howManyHoursSearchedPerWeek',
        'user.willSkillsAttachHelpGetInterview',
        'user.lowestAcceptablePayAfter',
        'sc_nstd_mtpt_err_per_s',
        'user.appliedInThePastSector',
        'sc_nstd_convent',
        'user.targetSector',
        'sc_nstd_realistic',
        'user.jobStrengthsAndWeaknesses',
        'sc_nstd_corsi_1',
        'user.helpGetInterview',
        'sc_nstd_hmt_1',
        'sc_nstd_extra',
        'sc_nstd_ds_f_2',
        'user.howManyHoursToUpskillPerWeek',
        'sc_nstd_consc',
        'sc_nstd_stability',
        'sc_nstd_open',
        'sc_nstd_agree',
        'sc_nstd_cpt_corrected',
        'tr_recommend_full',
        'sc_nstd_s_manage',
        'sc_nstd_tmt_log_b',
        'sc_nstd_enterp',
        'tr_job_number',
        'sc_nstd_artistic',
        'user.helpGettingJob',
        'user.helpGetJobInDesiredSector',
        'user.howLongInCurrentPosition',
        'user.howLongSearchingForJob',
        'sc_nstd_bret_prop',
        'tr_similar_wage_after',
        'user.plannedCourses',
        'sc_nstd_tmt_log_a',
        'user.howLongUnemployed',
        'sc_nstd_tmt_err_b',
        'user.helpJobSearch',
        'tr_feel_work',
        'sc_nstd_soc_aware',
        'user.likelyToRecommend',
        'tr_low_pay_after',
        'sc_nstd_s_aware',
        'sc_nstd_ds_b_2',
        'user.howManyApplicationsLastMonth',
        'user.howManyHoursWillSearchPerWeek',
        'sc_nstd_gm',
        'tr_attach_skills_report_full',
        'user.howManyApplicationsNextMonth',
        'tr_job_full',
        'sc_nstd_tmt_err_a',
        'tr_feedback_full',
        'tr_self_efficacy',
        'tr_job_offers',
        'tr_report_help_interview_full',
        'tr_help_get_job_full',
        'tr_did_full',
        'tr_search_hours_after',
        'user.accessedLearningLinks',
        'tr_riasec_target_sector',
        'tr_feedback_increase_job',
        'user.planToIncreaseJobSearch',
        'tr_employment_status',
        'user.reportUsefullness',
        'tr_help_job_search_full',
        'sc_nstd_pp',
        'tr_upskill_hours_week',
        'user.plansToAttachSkillsReport',
        'user.expectedToFindJobInSixMonths',
        'tr_target_sector',
        'tr_applications_next_1m',
        'user.expectsToFindJobInSixMonths',
        'sc_nstd_mtpt_quit_1',
    ),
}
TABICL_ITEMS_CUDA = {1: TABICL_ITEMS[2], 2: TABICL_ITEMS[2]}
TABICL_REFINE_ITEMS = {1: (), 2: ()}
TABICL_ESTIMATORS = {1: 1, 2: 1}
KUMO_ITEMS_CUDA = {
    1: (),
    2: (
        'sc_nstd_social',
        'sc_nstd_invest',
        'user.willSkillsAttachHelpGetInterview',
        'sc_nstd_mtpt_err_per_s',
        'sc_nstd_convent',
        'sc_nstd_realistic',
        'user.jobStrengthsAndWeaknesses',
        'sc_nstd_corsi_1',
        'user.helpGetInterview',
        'sc_nstd_hmt_1',
        'sc_nstd_extra',
        'sc_nstd_consc',
        'sc_nstd_stability',
        'sc_nstd_open',
        'sc_nstd_agree',
        'sc_nstd_cpt_corrected',
        'tr_recommend_full',
        'sc_nstd_s_manage',
        'sc_nstd_tmt_log_b',
        'sc_nstd_enterp',
        'tr_job_number',
        'sc_nstd_artistic',
        'user.helpGettingJob',
        'user.helpGetJobInDesiredSector',
        'user.howLongInCurrentPosition',
        'user.howLongSearchingForJob',
        'sc_nstd_bret_prop',
        'tr_similar_wage_after',
        'sc_nstd_tmt_log_a',
        'user.howLongUnemployed',
        'sc_nstd_tmt_err_b',
        'user.helpJobSearch',
        'sc_nstd_soc_aware',
        'user.likelyToRecommend',
        'tr_low_pay_after',
        'sc_nstd_s_aware',
        'sc_nstd_gm',
        'tr_attach_skills_report_full',
        'tr_job_full',
        'sc_nstd_tmt_err_a',
        'tr_feedback_full',
        'tr_self_efficacy',
        'tr_job_offers',
        'tr_report_help_interview_full',
        'tr_help_get_job_full',
        'tr_did_full',
        'user.accessedLearningLinks',
        'tr_riasec_target_sector',
        'tr_feedback_increase_job',
        'user.planToIncreaseJobSearch',
        'tr_employment_status',
        'user.reportUsefullness',
        'tr_help_job_search_full',
        'sc_nstd_pp',
        'user.plansToAttachSkillsReport',
        'user.expectedToFindJobInSixMonths',
        'user.expectsToFindJobInSixMonths',
        'sc_nstd_mtpt_quit_1',
    ),
}
KUMO_ITEMS_CUDA_MANY = {1: (), 2: TABICL_ITEMS[2]}
WB_ITERATION_CAPS = {'C10': 300, 'KDB_HLS1': 200, 'WB_RESPONSE': 300}
WB_ITERATION_CAP_PHASES = (2,)
WB_FAMILIES = ('GFIC', 'KDB_HLS1', 'LinearFull', 'NeuralShared',
               'WB_INTERACTIONS', 'WB_RESPONSE', 'WB_TRANSITIONS',
               'BCT_OPTION3', 'WB_NEURAL_ENSEMBLE', 'WB_SECTOR', 'WB_ORDINAL_SC', 'TABICL')
TABICL_DEVICE = 'auto'
COMPOSITION = {
    1: {
        'world_bank': {'base': WB_BASE_FAMILIES, 'optional': WB_FAMILIES, 'route': 'stack', 'quota': 720.0},
        'unicef': {'base': ('C1', 'C2'), 'optional': (), 'route': 'reduced', 'quota': 10.0},
        'unhcr': {'base': ('C1', 'C2'), 'optional': (), 'route': 'reduced', 'quota': 20.0},
    },
    2: {
        'world_bank': {'base': WB_BASE_FAMILIES, 'optional': WB_FAMILIES, 'route': 'stack', 'quota': 3000.0},
        'unicef': {'base': ('C1', 'C2'), 'optional': (), 'route': 'reduced', 'quota': 10.0},
        'unhcr': {'base': ('C1', 'C2'), 'optional': (), 'route': 'reduced', 'quota': 20.0},
    },
}

@dataclass(frozen=True)
class Config:
    r1: bool = True
    r2: bool = False
    r3: bool = True
    r4: bool = False
    r5: bool = False
    r6: bool = True
    r7: bool = False
    r8: bool = True
    r9: bool = True
    e1: bool = True
    item_calibration: bool = True
    phase: int = 0
    base_families: tuple = ()
    optional_families: tuple = ()
    gfic: bool = True
    kdb: bool = True
    linear_non_erpis: bool = True
    neural_non_erpis: bool = True
    tabicl: bool = False
    wb_interactions: bool = True
    wb_h2_bct: bool = True
    wb_tabicl: bool = True
    wb_tabicl_refine: bool = False
    wb_tabicl_frozen: bool = True
    wb_torch_threads: int = 4
    wb_neural_fit_seconds: float = 90.0
    wb_response: bool = True
    wb_transitions: bool = False
    wb_kdb2: bool = False
    wb_kdb2_replace: bool = False
    wb_hgb: bool = False
    wb_hgb_items: tuple = ()
    wb_profile_na: bool = False
    wb_shared_arms: bool = False
    wb_tabm: bool = False
    wb_class_bias: bool = False
    wb_class_bias_strength: float = 50.0
    ordinal_given: bool = True
    wb_neural_seeds: int = 3
    wb_neural_ensemble: bool = True
    wb_regularized_stack: bool = True
    wb_prune_members: bool = True
    wb_blas_threads: int = 1
    wb_kdb_temper: bool = False
    c10_rank: int = 16
    wb_stack_strength: float = 200.0
    wb_tabicl_ordered: bool = False
    wb_tabicl_items: tuple | None = None
    wb_tabicl_refine_items: tuple | None = None
    wb_tabicl_estimators: int = 4
    wb_tabicl_max_items: int = 0
    wb_cpu_phase2_time_guard: bool = True
    wb_kumo: bool = True
    wb_kumo_items: tuple | None = None
    wb_kumo_estimators: int = 4
    wb_kumo_many_class: bool = True
    wb_honest_meta: bool = True
    wb_sector: bool = False
    wb_ordinal_sc: bool = True
    wb_waterfill: bool = False
    wb_factorized: bool = True
    wb_factor_strength: float = 12.5
    wb_factor_reserve_seconds: float = 300.0
    wb_factor_reserve_phase1_seconds: float = 121.0
    wb_factor_solver: str = 'softmax'
    wb_folds: int = 3
    wb_parent_gate: bool = True
    wb_finalize_reserve_seconds: float = 120.0
    wb_iteration_caps: bool = False
    wb_c10_gate: bool = True
    erp_gpu: bool = False
    erp_ensemble: bool = False
    erp_astra: bool = False
    budget_total: float = 0.0
    disabled_unicef: tuple = ()
    disabled_world_bank: tuple = ()

    @classmethod
    def cpu_safe(cls):
        return cls()

    @classmethod
    def full(cls):
        return cls()

    @classmethod
    def all_off(cls):
        return cls(**{'r'+str(i): False for i in range(1,10)},
                   gfic=False, kdb=False, linear_non_erpis=False,
                   neural_non_erpis=False, item_calibration=False)

    def any_non_erpis(self):
        return True
