import numpy as np
from scipy.linalg import cho_factor, cho_solve, svd
from scipy.optimize import minimize
from wb_ordinal_given import append_numeric


def _rows(selector, size):
    values = np.asarray(selector)
    if values.ndim != 1:
        raise ValueError("Row selectors must have one dimension")
    if values.dtype == bool:
        if len(values) != size:
            raise ValueError("Boolean row selectors must cover all respondents")
        return np.flatnonzero(values)
    result = values.astype(np.int64)
    if np.any(result < 0) or np.any(result >= size):
        raise ValueError("Row index outside the frame")
    return result


def _one_hot(codes, cards, rows):
    offsets = np.r_[0, np.cumsum(cards + 1)]
    result = np.zeros((len(rows), int(offsets[-1])), dtype=float)
    for column, card in enumerate(cards):
        selected = codes[rows, column]
        levels = np.where((selected >= 0) & (selected < card), selected, card)
        result[np.arange(len(rows)), offsets[column] + levels] = 1.0
    return result


def _softmax_blocks(logits, widths, starts):
    maxima = np.maximum.reduceat(logits, starts, axis=-1)
    probabilities = logits - np.repeat(maxima, widths, axis=-1)
    np.exp(probabilities, out=probabilities)
    totals = np.add.reduceat(probabilities, starts, axis=-1)
    probabilities /= np.repeat(totals, widths, axis=-1)
    return probabilities, maxima + np.log(totals)


def predict_reduced_rank(feature_codes, feature_cards, target_codes,
                         target_cards, train_rows, query_rows, rank=8,
                         strength=20.0, alpha=0.5, seed=13, max_iter=60, repair=False,
                         numeric_features=None):
    if not np.isfinite(strength) or strength <= 0:
        raise ValueError("strength must be finite and positive")
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("alpha must be finite and positive")
    if int(rank) != rank or rank < 1:
        raise ValueError("rank must be a positive integer")
    if int(max_iter) != max_iter or max_iter < 1:
        raise ValueError("max_iter must be a positive integer")
    if repair:
        max_iter = 250
    features = np.asarray(feature_codes, dtype=np.int64)
    targets = np.asarray(target_codes, dtype=np.int64)
    cards = np.asarray(feature_cards, dtype=np.int64)
    widths = np.asarray(target_cards, dtype=np.int64)
    if features.ndim != 2 or targets.ndim != 2:
        raise ValueError("Code matrices must have two dimensions")
    if len(features) != len(targets):
        raise ValueError("Code matrices must share respondents")
    if cards.ndim != 1 or len(cards) != features.shape[1] or np.any(cards < 1):
        raise ValueError("Every feature needs a positive schema cardinality")
    if widths.ndim != 1 or len(widths) != targets.shape[1] or np.any(widths < 1):
        raise ValueError("Every target needs a positive schema cardinality")
    train, query = _rows(train_rows, len(features)), _rows(query_rows, len(features))
    offsets = np.r_[0, np.cumsum(widths)]
    output_size = int(offsets[-1])
    fit_targets = targets[train]
    valid = (fit_targets >= 0) & (fit_targets < widths[None, :])
    valid_counts = valid.sum(axis=0)
    cells = int(valid_counts.sum())
    priors, label_rows, label_values = [], [], []
    intercept = np.zeros(output_size, dtype=float)
    for item, width in enumerate(widths):
        rows = np.flatnonzero(valid[:, item])
        values = fit_targets[rows, item]
        counts = np.bincount(values, minlength=width).astype(float)
        prior = (counts + alpha) / (len(rows) + alpha * width)
        start, end = offsets[item:item + 2]
        intercept[start:end] = np.log(prior)
        priors.append(prior)
        label_rows.append(rows)
        label_values.append(values)

    diagnostics = {
        "training_rows": int(len(train)),
        "query_rows": int(len(query)),
        "feature_columns": int(np.sum(cards + 1)) + (0 if numeric_features is None else np.asarray(numeric_features).shape[1]),
        "active_feature_columns": 0,
        "output_columns": output_size,
        "valid_counts": valid_counts.tolist(),
        "observed_training_cells": cells,
        "requested_rank": int(rank),
        "rank": 0,
        "strength": float(strength),
        "alpha": float(alpha),
        "seed": int(seed),
        "max_iter": int(max_iter),
        "iterations": 0,
        "converged": True,
        "solver": "marginal_only",
        "reason": "degenerate_input",
        "regularization_scaling": "mean_cell_nll_plus_strength_over_n_penalty" if repair else "summed_likelihood_strength_divided_by_observed_cells",
        "pseudo_counts": "alpha_per_schema_option_at_centered_feature_origin",
    }

    def marginal_result():
        return [np.broadcast_to(p, (len(query), len(p))).copy() for p in priors], diagnostics

    if not (cells and len(cards) and len(query) and np.any(widths > 1)):
        return marginal_result()
    design = append_numeric(_one_hot(features, cards, train), numeric_features, train)
    feature_mean = design.mean(axis=0)
    design -= feature_mean
    varying = np.any(design != 0.0, axis=0)
    design = np.ascontiguousarray(design[:, varying])
    dimension = design.shape[1]
    diagnostics["active_feature_columns"] = int(dimension)
    effective_rank = min(int(rank), dimension, int(np.sum(widths - 1)))
    if not effective_rank:
        diagnostics["reason"] = "constant_given"
        return marginal_result()

    residual = np.zeros((len(train), output_size), dtype=float)
    for item, width in enumerate(widths):
        start, end = offsets[item:item + 2]
        rows, values, prior = label_rows[item], label_values[item], priors[item]
        residual[rows, start:end] = -prior
        residual[rows, start + values] += 1.0
        residual[:, start:end] /= np.maximum(prior, 0.01)
    gram = design.T @ design
    gram.flat[::dimension + 1] += strength
    coefficients = cho_solve(cho_factor(gram, lower=True, check_finite=False),
                             design.T @ residual, check_finite=False)
    left, singular, right = svd(coefficients, full_matrices=False,
                                check_finite=False, lapack_driver="gesvd")
    root = np.sqrt(np.maximum(singular[:effective_rank], 0.0))
    initial_a = left[:, :effective_rank] * root
    initial_b = root[:, None] * right[:effective_rank]
    initialization = "ridge_svd"
    if repair:
        max_logit = float(np.max(np.abs((design @ initial_a) @ initial_b), initial=0.0))
        scale = min(1.0, np.sqrt(5.0 / max(max_logit, 1e-12)))
        initial_a *= scale
        initial_b *= scale
        initialization = "ridge_svd_logits_capped_5"
    if not np.any(root > 1e-12):
        generator = np.random.default_rng(seed)
        initial_a = generator.normal(0.0, 0.01, size=(dimension, effective_rank))
        initial_b = generator.normal(0.0, 0.01, size=(effective_rank, output_size))
        initialization = "fixed_seed_nonzero"
    for item, count in enumerate(valid_counts):
        if not count:
            initial_b[:, offsets[item]:offsets[item + 1]] = 0.0
    a_size = dimension * effective_rank
    b_size = effective_rank * output_size
    valid_items, valid_rows = np.nonzero(valid.T)
    valid_options = offsets[valid_items] + fit_targets[valid_rows, valid_items]
    option_valid = None if np.all(valid) else np.repeat(valid, widths, axis=1)
    option_widths = np.repeat(widths, widths)

    def unpack(parameters):
        a = parameters[:a_size].reshape(dimension, effective_rank)
        b = parameters[a_size:a_size + b_size].reshape(effective_rank, output_size)
        bias = parameters[a_size + b_size:]
        return a, b, bias

    def objective(parameters):
        a, b, bias = unpack(parameters)
        latent = design @ a
        logits = latent @ b + bias
        errors, normalizers = _softmax_blocks(logits, widths, offsets[:-1])
        if option_valid is not None:
            errors *= option_valid
        errors[valid_rows, valid_options] -= 1.0
        data_loss = np.sum(normalizers[valid_rows, valid_items]
                           - logits[valid_rows, valid_options])
        bias_probabilities, bias_normalizers = _softmax_blocks(bias, widths, offsets[:-1])
        pseudo_loss = alpha * (np.dot(widths, bias_normalizers) - bias.sum())
        bias_prior_gradient = alpha * (option_widths * bias_probabilities - 1.0)
        penalty_strength = strength * cells / max(len(train), 1) if repair else strength
        penalty = 0.5 * penalty_strength * (np.sum(a * a) + np.sum(b * b))
        gradient_a = (design.T @ (errors @ b.T) + penalty_strength * a) / cells
        gradient_b = (latent.T @ errors + penalty_strength * b) / cells
        gradient_bias = (errors.sum(axis=0) + bias_prior_gradient) / cells
        value = (data_loss + pseudo_loss + penalty) / cells
        gradient = np.r_[gradient_a.ravel(), gradient_b.ravel(), gradient_bias]
        return float(value), gradient

    initial = np.r_[initial_a.ravel(), initial_b.ravel(), intercept]
    initial_objective, _ = objective(initial)
    result = minimize(objective, initial, method="L-BFGS-B", jac=True,
                      options={"maxiter": int(max_iter), "maxls": 30,
                               "ftol": 1e-9, "gtol": 1e-7})
    final = result.x
    final_objective, final_gradient = objective(final)
    used_initial = (not np.isfinite(final_objective)
                    or not np.isfinite(final_gradient).all()
                    or final_objective > initial_objective)
    if used_initial:
        final = initial
        final_objective, final_gradient = objective(final)
    a, b, bias = unpack(final)
    query_design = (append_numeric(_one_hot(features, cards, query), numeric_features, query) - feature_mean)[:, varying]
    logits = (query_design @ a) @ b + bias
    all_probabilities, _ = _softmax_blocks(logits, widths, offsets[:-1])
    np.maximum(all_probabilities, np.finfo(float).tiny, out=all_probabilities)
    totals = np.add.reduceat(all_probabilities, offsets[:-1], axis=1)
    all_probabilities /= np.repeat(totals, widths, axis=1)
    predictions = []
    for item, width in enumerate(widths):
        start, end = offsets[item:item + 2]
        probabilities = all_probabilities[:, start:end].copy()
        if not valid_counts[item]:
            probabilities[:] = priors[item]
        predictions.append(probabilities)
    diagnostics.update({
        "rank": effective_rank,
        "solver": "lbfgs_multinomial_shared_factors",
        "initialization": initialization,
        "iterations": int(result.nit),
        "function_evaluations": int(result.nfev),
        "converged": bool(result.success and not used_initial),
        "reason": "initialization_fallback" if used_initial else str(result.message),
        "initial_objective": initial_objective,
        "final_objective": final_objective,
        "gradient_inf_norm": float(np.max(np.abs(final_gradient))),
    })
    return predictions, diagnostics
