from time import perf_counter

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

import legacy
import gfic_legacy as gfic

EPSILON = 0.01
PRIOR = 0.5
MAX_ITER = 60


def candidate(data, train, query, budget=None, *, items=None, threads=8):
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    selected = set(data.targets if items is None else items)
    if selected.difference(data.targets):
        raise ValueError("HGB item subset contains a non-target")
    x = np.column_stack([data.features[name] for name in data.given]).astype(float)
    if any(data.cards[name] > 255 for name in data.given):
        raise ValueError("HGB categorical cardinality exceeds max_bins")
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True,
                                                  item_calibration=True))
    labels, cards = gfic.content_targets(data, laws, train)
    values = {item: None for item in data.targets}
    details = {}
    started = perf_counter()
    with threadpool_limits(limits=int(threads), user_api="openmp"):
        with threadpool_limits(limits=1, user_api="blas"):
            for column, item in enumerate(data.targets):
                if item not in selected:
                    continue
                if budget is not None:
                    budget.checkpoint()
                item_started = perf_counter()
                y = labels[train, column]
                usable = y >= 0
                y = y[usable]
                width = int(cards[column])
                counts = np.bincount(y, minlength=width)
                prior = (counts + PRIOR) / (len(y) + PRIOR * width)
                seen = np.flatnonzero(counts)
                iterations = 0
                if len(seen) < 2 or not x.shape[1]:
                    p = np.tile(prior, (len(query), 1))
                    status = "marginal_insufficient_classes"
                else:
                    model = HistGradientBoostingClassifier(
                        loss="log_loss", learning_rate=0.08,
                        max_iter=MAX_ITER, max_leaf_nodes=7,
                        min_samples_leaf=30, l2_regularization=10.0,
                        max_bins=255,
                        categorical_features=np.ones(x.shape[1], dtype=bool),
                        early_stopping=False, random_state=1020)
                    model.fit(x[train[usable]], y)
                    p = np.zeros((len(query), width), dtype=float)
                    p[:, model.classes_.astype(int)] = model.predict_proba(x[query])
                    p = (1 - EPSILON) * p + EPSILON * prior[None, :]
                    iterations = int(model.n_iter_)
                    status = "fitted"
                if item in laws:
                    p = gfic.compose_gate(p, laws[item], query)
                values[item] = legacy.normalize(p)
                details[item] = {
                    "seconds": perf_counter() - item_started,
                    "train_rows": int(len(y)), "classes_seen": int(len(seen)),
                    "iterations": iterations, "status": status,
                }
    elapsed = perf_counter() - started
    return legacy.Candidate("WB_HGB", values), {
        "seconds": elapsed, "over_60_seconds": elapsed > 60,
        "given": list(data.given), "selected_items": [n for n in data.targets if n in selected],
        "gate_items": [n for n in laws if n in selected],
        "categorical_features": "all GIVEN", "openmp_threads": int(threads),
        "epsilon_marginal": EPSILON, "prior_per_class": PRIOR,
        "max_iter": MAX_ITER, "max_leaf_nodes": 7, "min_samples_leaf": 30,
        "l2_regularization": 10.0, "early_stopping": False,
        "selection": "all items" if items is None else "explicit TRAIN-only subset supplied by caller",
        "items": details,
    }
