from time import perf_counter

class CandidateBudgetExceeded(RuntimeError):
    pass

class Budget:
    def __init__(self, instrument, imported_at, total=900.0, completed=(), quotas=None):
        self.instrument = instrument
        self.started = perf_counter()
        self.total = float(total)
        self.global_deadline = imported_at + 0.85 * self.total
        self.quotas = dict(quotas or {})
        self.quota = self.quotas.get(instrument, 5.0)
        self.wb_reserve = (self.quotas.get('world_bank', 0.0)
                           if instrument != 'world_bank' and 'world_bank' not in completed else 0.0)
        self.hard_deadline = min(self.started + self.quota,
                                self.global_deadline - self.wb_reserve)
        self.finalization_reserve = min(20.0, max(2.0, 0.15 * self.quota))
        self.deadline = self.hard_deadline - self.finalization_reserve
        self.finalizing = False
        self.disabled = set()
        self.events = []

    def reserve_finalization(self, seconds):
        self.finalization_reserve = min(max(0.0, float(seconds)), max(2.0, 0.25 * self.quota))
        if not self.finalizing:
            self.deadline = self.hard_deadline - self.finalization_reserve

    def remaining(self):
        return max(0.0, self.deadline - perf_counter())

    def global_exhausted(self):
        return perf_counter() >= self.global_deadline

    def begin_finalization(self):
        self.finalizing = True
        self.deadline = self.hard_deadline
        self.checkpoint()

    def allow(self, name):
        self.checkpoint()
        return name not in self.disabled

    def observe(self, name, elapsed, remaining_fits):
        self.checkpoint()
        return True

    def disable(self, name, reason):
        self.disabled.add(name)
        self.events.append({'candidate': name, 'reason': reason})

    def checkpoint(self):
        if perf_counter() >= self.deadline:
            raise CandidateBudgetExceeded('instrument emergency deadline reached')

    def diagnostics(self):
        return {'instrument': self.instrument, 'quota': self.quota,
                'finalization_reserve': self.finalization_reserve,
                'finalizing': self.finalizing,
                'total': self.total, 'emergency_fraction': 0.85,
                'wb_reserve': self.wb_reserve, 'remaining': self.remaining(),
                'disabled': sorted(self.disabled), 'events': list(self.events)}
