import itertools
import math
from time import perf_counter

import numpy as np
from scipy.special import gammaln, logsumexp

import legacy
import gfic_legacy as gfic


NAME = "BCT_OPTION3"
DEPTH = 3
ALPHA = 0.5
STOP = 0.5
STATE_CAP = 300000
PREDICT_CHUNK = 256


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


class _Geometry:
    def __init__(self, x, cards, budget=None):
        self.cards = tuple(int(c) for c in cards)
        self.depth = min(DEPTH, len(cards))
        self.levels = [tuple(itertools.combinations(range(len(cards)), d))
                       for d in range(self.depth + 1)]
        self.sizes = {s: math.prod(self.cards[g] for g in s)
                      for level in self.levels for s in level}
        self.state_count = sum(self.sizes.values())
        if self.state_count > STATE_CAP:
            raise ValueError("BCT dense context-state cap exceeded; depth unchanged")
        self.codes = {}
        self.edges = {}
        for level in self.levels:
            for s in level:
                _checkpoint(budget)
                code = np.zeros(len(x), dtype=np.int64)
                for g in s:
                    code = code * self.cards[g] + x[:, g]
                self.codes[s] = code
                edges = []
                if len(s) < self.depth:
                    for g in range(len(cards)):
                        if g in s:
                            continue
                        child = tuple(sorted(s + (g,)))
                        after = math.prod(self.cards[h] for h in child if h > g)
                        idx = np.arange(self.sizes[child], dtype=np.int64)
                        parent = (idx // (after * self.cards[g])) * after + idx % after
                        edges.append((child, parent))
                self.edges[s] = edges


def _fit_predict(geometry, train, y, query, width, budget):
    use = (y >= 0) & (y < width)
    train, y = train[use], y[use]
    if not len(train):
        return np.full((len(query), width), 1.0 / width), {"empty_train": True}
    nodes = {}
    for level in geometry.levels:
        for s in level:
            _checkpoint(budget)
            code = geometry.codes[s][train]
            counts = np.bincount(code * width + y,
                                 minlength=geometry.sizes[s] * width).reshape(-1, width)
            evidence = (gammaln(width * ALPHA)
                        - gammaln(counts.sum(1) + width * ALPHA)
                        + (gammaln(counts + ALPHA) - gammaln(ALPHA)).sum(1))
            nodes[s] = {"counts": counts, "logE": evidence}
    for level in reversed(geometry.levels):
        for s in level:
            _checkpoint(budget)
            node = nodes[s]
            edges = geometry.edges[s]
            if not edges:
                node["logW"] = node["logE"]
                node["poststop"] = np.ones(len(node["logE"]))
                continue
            logits = [np.bincount(parent, weights=nodes[child]["logW"],
                                   minlength=geometry.sizes[s])
                      for child, parent in edges]
            split = np.stack(logits) + np.log1p(-STOP) - np.log(len(edges))
            stop = node["logE"] + np.log(STOP)
            node["logW"] = logsumexp(np.vstack((stop[None, :], split)), axis=0)
            node["poststop"] = np.exp(stop - node["logW"])
            node["postsplit"] = np.exp(split - node["logW"][None, :])
    result = np.empty((len(query), width), dtype=np.float64)
    for offset in range(0, len(query), PREDICT_CHUNK):
        _checkpoint(budget)
        rows = query[offset:offset + PREDICT_CHUNK]
        predictions = {}
        for level in reversed(geometry.levels):
            for s in level:
                _checkpoint(budget)
                node = nodes[s]
                codes = geometry.codes[s][rows]
                counts = node["counts"][codes]
                probabilities = ((counts + ALPHA)
                                 / (counts.sum(1, keepdims=True) + width * ALPHA))
                probabilities *= node["poststop"][codes, None]
                for j, (child, _) in enumerate(geometry.edges[s]):
                    probabilities += node["postsplit"][j, codes, None] * predictions[child]
                predictions[s] = probabilities
        result[offset:offset + len(rows)] = predictions[()]
    if (not np.isfinite(result).all() or (result < 0).any()
            or not np.allclose(result.sum(1), 1.0, rtol=0, atol=2e-10)):
        raise ValueError("Invalid BCT predictive distribution")
    return result, {"root_stop": float(nodes[()]["poststop"][0]),
                    "log_evidence": float(nodes[()]["logW"][0]),
                    "valid_rows": int(len(train))}


def candidate(data, train_idx, pred_idx, budget=None):
    started = perf_counter()
    train = np.asarray(train_idx, dtype=np.int64)
    query = np.asarray(pred_idx, dtype=np.int64)
    if np.intersect1d(train, query).size:
        raise ValueError("BCT training and predicted respondents must be disjoint")
    _checkpoint(budget)
    x = np.asarray(data.x, dtype=np.int64)
    cards = np.asarray(data.xcards, dtype=np.int64)
    if np.any(x < 0) or np.any(x >= cards[None, :]):
        raise ValueError("BCT requires legacy.Data categorical encoding")
    geometry = _Geometry(x, cards, budget)
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
    probabilities, diagnostics, gated_items = {}, {}, []
    for column, (item, width) in enumerate(zip(data.targets, data.ycards)):
        _checkpoint(budget)
        labels = np.asarray(data.y[train, column], dtype=np.int64)
        law = laws.get(item)
        eligible = bool(law and width == law["sentinel"] + 1
                        and law["n_open"] >= 20 and law["n_closed"] >= 20
                        and law["v_open"] == 0 and law["v_closed"] == 0)
        if eligible:
            sentinel = law["sentinel"]
            content = labels.copy()
            content[content == sentinel] = -1
            value, detail = _fit_predict(geometry, train, content, query, sentinel, budget)
            value = gfic.compose_gate(value, law, query)
            unknown = ~law["known"][query]
            if unknown.any():
                direct, _ = _fit_predict(geometry, train, labels, query[unknown], width, budget)
                value[unknown] = direct
            detail.update({"eligible": True, "open": law["n_open"],
                           "closed": law["n_closed"], "violations": 0,
                           "gate_composition": "current_smoothed_compose_gate"})
            gated_items.append(item)
        else:
            value, detail = _fit_predict(geometry, train, labels, query, width, budget)
            detail["eligible"] = False
            if law:
                detail.update({"open": law["n_open"], "closed": law["n_closed"],
                               "violations": law["v_open"] + law["v_closed"]})
        probabilities[item] = value
        diagnostics[item] = detail
    _checkpoint(budget)
    return legacy.Candidate(NAME, probabilities), {
        "source": "archived H2 BCT_OPTION3; current OOF and smoothed gate composition",
        "depth": DEPTH, "alpha": ALPHA, "stop": STOP,
        "state_cap": STATE_CAP, "dense_states_per_target": geometry.state_count,
        "gate_items": gated_items, "items": diagnostics,
        "seconds": perf_counter() - started}
