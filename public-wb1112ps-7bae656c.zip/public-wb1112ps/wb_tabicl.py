from contextlib import ExitStack
import gzip
import hashlib
import io
import os
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd

import legacy
import gfic_legacy as gfic
from budget import CandidateBudgetExceeded

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

CHECKPOINT_PATH = Path(__file__).resolve().parent / "models" / "tabicl-v2.ckpt.gz"
CHECKPOINT_SHA256 = "bdc7dbd5e4ff21f8f0456fcf90c6b7cdf72dbea960f2d05b19bec19f9b3d4ed0"
CHECKPOINT_BYTES = 110368038
CHECKPOINT_REVISION = "4dcd344ece2c00be9e831fdd35bed57b5ad83e19"
MAX_CLASSES = 10
SMOOTHING = 0.001
MARGINAL_ALPHA = 0.5
NAME = "TabICL_WB"
_DEVICE = "cpu"
_DEVICE_STATUS = "CPU default"


def _initial_device(torch, model):
    try:
        import config as _route_config
        policy = str(getattr(_route_config, "TABICL_DEVICE", "auto"))
    except Exception:
        policy = "cpu"
    if policy != "auto":
        model.to("cpu")
        return "cpu", "CPU fixed by configuration"
    if not torch.cuda.is_available():
        return "cpu", "CUDA unavailable"
    try:
        index = torch.cuda.current_device()
        device = "cuda:%d" % index
        probe = torch.ones((4, 4), device=device)
        result = probe @ probe
        torch.cuda.synchronize(index)
        if not bool(torch.isfinite(result).all()):
            raise RuntimeError("Nonfinite CUDA probe")
        model.to(device)
        del probe, result
        return device, "CUDA allocation, GEMM and checkpoint transfer passed"
    except Exception as error:
        model.to("cpu")
        return "cpu", "CUDA probe failed: %s" % type(error).__name__


def _preload():
    import torch
    from tabicl import TabICLClassifier
    from tabicl._model.tabicl import TabICL
    from importlib.metadata import version
    if version("tabicl") != "2.2.0":
        raise RuntimeError("TabICL 2.2.0 is required")
    with gzip.open(CHECKPOINT_PATH, "rb") as stream:
        payload = stream.read(CHECKPOINT_BYTES + 1)
    if len(payload) != CHECKPOINT_BYTES or hashlib.sha256(payload).hexdigest() != CHECKPOINT_SHA256:
        raise ValueError("TabICL checkpoint integrity mismatch")
    checkpoint = torch.load(io.BytesIO(payload), map_location="cpu", weights_only=True)
    model_config = checkpoint["config"]
    with torch.random.fork_rng(devices=[]):
        model = TabICL(**model_config)
        model.load_state_dict(checkpoint["state_dict"], strict=True)
    if model.max_classes != MAX_CLASSES:
        raise ValueError("Unexpected TabICL class limit")
    model.eval()
    global _DEVICE, _DEVICE_STATUS
    _DEVICE, _DEVICE_STATUS = _initial_device(torch, model)

    class OfflineClassifier(TabICLClassifier):
        def _load_model(self):
            self.model_ = model
            self.model_config_ = model_config
            self.model_path_ = CHECKPOINT_PATH

    return torch, model, OfflineClassifier


_IMPORT_STARTED = perf_counter()
_TORCH, _MODEL, _FACTORY = None, None, None
try:
    _TORCH, _MODEL, _FACTORY = _preload()
    AVAILABLE, STATUS = True, "ready: verified module-level checkpoint"
except Exception as error:
    AVAILABLE, STATUS = False, "%s: %s" % (type(error).__name__, error)
IMPORT_SECONDS = perf_counter() - _IMPORT_STARTED


def availability():
    return {"available": AVAILABLE, "status": STATUS,
            "checkpoint_sha256": CHECKPOINT_SHA256,
            "checkpoint_revision": CHECKPOINT_REVISION,
            "import_seconds": IMPORT_SECONDS, "device": _DEVICE,
            "device_status": _DEVICE_STATUS,
            "package": "tabicl==2.2.0", "max_classes": MAX_CLASSES,
            "native_max_classes": MAX_CLASSES,
            "support_many_classes": True}


def _kwargs(n_estimators=1):
    return dict(n_estimators=n_estimators, norm_methods=["none"],
                feat_shuffle_method="latin", class_shuffle_method="shift",
                softmax_temperature=0.9, average_logits=True,
                support_many_classes=True, batch_size=1, kv_cache=False,
                model_path=str(CHECKPOINT_PATH), allow_auto_download=False,
                device=_DEVICE, use_amp=False, use_fa3=False,
                offload_mode=False, disk_offload_dir=None,
                random_state=42, n_jobs=None, verbose=False,
                inference_config={name: {"offload": False, "use_async": False}
                                  for name in ("COL_CONFIG", "ROW_CONFIG", "ICL_CONFIG")})


def _categorical_features(frame, schema):
    result = {}
    for name, record in schema["items"].items():
        if record["class"] == "GIVEN":
            result[name] = pd.Categorical(frame[name], categories=legacy.options_for(schema, name))
    return pd.DataFrame(result, index=frame.index)


def _family(item):
    if item.startswith("sc_nstd_"):
        return "tasks"
    if item.startswith("sc_"):
        return "scales"
    if item.startswith("tr_"):
        return "tracer"
    return "user"


def _class_cost(width):
    return 1.0 if width <= MAX_CLASSES else 1.0 + np.ceil(width / MAX_CLASSES)


def _priority_proxy(data, plans):
    families = {name: [] for name in ("tasks", "user", "scales", "tracer")}
    for column, item in enumerate(data.targets):
        entropy_sum, total = 0.0, 0
        record = data.schema["items"][item]
        gate = record.get("gate")
        factored = bool(gate and gate["parent"] in data.given)
        width = len(data.options[item]) - int(factored)
        for plan in plans:
            if plan["kind"] != "outer":
                continue
            query = np.asarray(plan["query"], dtype=int)
            total += len(query)
            opened = np.ones(len(query), dtype=bool)
            if factored:
                parent = data.frame[gate["parent"]].iloc[query]
                opened = parent.isin(gate["observed_if"]).to_numpy()
            if not opened.any():
                continue
            pooled, members = None, 0
            for candidate in plan.get("bank", {}).values():
                p = candidate.probabilities.get(item)
                if p is not None:
                    p = np.asarray(p)[opened, :width]
                    p = legacy.normalize(p)
                    pooled = p.copy() if pooled is None else pooled + p
                    members += 1
            if members:
                pooled = legacy.normalize(pooled)
                entropy_sum -= float(np.sum(pooled * np.log(np.maximum(pooled, np.finfo(float).tiny))))
        score = entropy_sum / max(total, 1) / _class_cost(width)
        families[_family(item)].append((item, score, column))
    for entries in families.values():
        entries.sort(key=lambda entry: (-entry[1], entry[2]))
    return [entries[position] for position in range(max(map(len, families.values()), default=0))
            for entries in families.values() if position < len(entries)]


def _predict_item(features, labels, width, train, query, check, n_estimators=1):
    train = np.asarray(train, dtype=int)
    query = np.asarray(query, dtype=int)
    fit_rows = train[labels[train] >= 0]
    y = labels[fit_rows]
    counts = np.bincount(y, minlength=width).astype(np.float64)
    marginal = (counts + MARGINAL_ALPHA) / (len(y) + MARGINAL_ALPHA * width)
    check()
    if len(y) == 0:
        return np.tile(marginal, (len(query), 1))
    if np.unique(y).size == 1:
        result = np.zeros((len(query), width), dtype=np.float64)
        result[:, y[0]] = 1.0
    else:
        estimator = _FACTORY(**_kwargs(n_estimators=n_estimators))
        estimator.fit(features.iloc[fit_rows], y)
        check()
        predicted = np.asarray(estimator.predict_proba(features.iloc[query]), dtype=np.float64)
        check()
        raw_classes = np.asarray(estimator.classes_)
        classes = raw_classes.astype(int)
        if (not np.array_equal(raw_classes, classes) or np.any(classes < 0)
                or np.any(classes >= width) or len(set(classes)) != len(classes)
                or predicted.shape != (len(query), len(classes))
                or not np.isfinite(predicted).all() or np.any(predicted < 0)
                or np.any(predicted.sum(1) <= 0)):
            raise ValueError("Invalid TabICL output")
        result = np.zeros((len(query), width), dtype=np.float64)
        result[:, classes] = predicted / predicted.sum(1, keepdims=True)
    return (1.0 - SMOOTHING) * result + SMOOTHING * marginal[None, :]


def _cpu_after_failure(error):
    global _DEVICE, _DEVICE_STATUS
    _MODEL.to("cpu")
    _DEVICE = "cpu"
    _DEVICE_STATUS = "CPU retry after CUDA %s" % type(error).__name__


class _FallbackFailure(Exception):
    pass


def fit_plans(frame, schema, plans, budget=None, max_items=None, cap_seconds=None,
              config=None, threads=8, selected_items=None, n_estimators=1, frozen=False,
              cpu_fallback_allowance=None):
    started = perf_counter()
    try:
        return _fit_plans(frame, schema, plans, budget=budget, max_items=max_items,
                          cap_seconds=cap_seconds, config=config, threads=threads,
                          selected_items=selected_items, n_estimators=n_estimators,
                          frozen=frozen, cpu_fallback_allowance=cpu_fallback_allowance)
    except Exception as error:
        fallback = isinstance(error, _FallbackFailure)
        cause = error.__cause__ if fallback and error.__cause__ is not None else error
        return [{} for _ in plans], {
            **availability(), "status": "failed_atomically", "covered_items": [],
            "items": [], "discarded_items": list(error.args[0]) if fallback else [],
            "error_type": type(cause).__name__, "error": str(cause),
            "elapsed_seconds": perf_counter() - started,
        }


def _fit_plans(frame, schema, plans, budget=None, max_items=None, cap_seconds=None,
               config=None, threads=8, selected_items=None, n_estimators=1, frozen=False,
               cpu_fallback_allowance=None):
    if not isinstance(n_estimators, (int, np.integer)) or n_estimators < 1:
        raise ValueError("n_estimators must be a positive integer")
    n_estimators = int(n_estimators)
    started = perf_counter()
    detail = {**availability(), "status": "empty", "covered_items": [],
              "items": [], "excluded_items": [], "max_items": max_items,
              "priority_basis": "label-free OOF content entropy per class-cost; round-robin tasks/user/scales/tracer",
              "device_fallbacks": [], "n_estimators": n_estimators, "frozen": bool(frozen)}
    if not AVAILABLE:
        detail.update(status="unavailable", error=STATUS, elapsed_seconds=perf_counter() - started)
        return [{} for _ in plans], detail
    config = config or legacy.Config()
    full_data = legacy.Data(frame, schema, config)
    features = _categorical_features(frame, schema)
    contexts = []
    for plan in plans:
        train = np.asarray(plan["train"], dtype=int)
        query = np.asarray(plan["query"], dtype=int)
        if np.intersect1d(train, query).size:
            raise ValueError("TabICL train/query rows overlap")
        outside = np.setdiff1d(np.arange(len(frame)), train)
        masked = legacy.mask_respondents(frame, schema, outside)
        data = legacy.Data(masked, schema, config)
        laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
        targets, cards = gfic.content_targets(data, laws, train)
        contexts.append((data, laws, targets, cards, train, query))
    probabilities = [{item: None for item in full_data.targets} for _ in plans]
    deadline = float("inf") if cap_seconds is None else started + max(0.0, float(cap_seconds))

    def check():
        if perf_counter() >= deadline:
            raise CandidateBudgetExceeded("TabICL allowance reached")
        if budget is not None:
            budget.checkpoint()

    priorities = _priority_proxy(full_data, plans)
    if selected_items is not None:
        order = {item: position for position, item in enumerate(selected_items)}
        unknown = set(order) - set(full_data.targets)
        if unknown:
            raise ValueError("Unknown selected TabICL items: " + repr(sorted(unknown)))
        priorities = sorted((entry for entry in priorities if entry[0] in order),
                            key=lambda entry: order[entry[0]])
        detail["selected_items"] = list(order)
    detail["priorities"] = [{"item": item, "content_entropy_per_cost": score,
                             "family": _family(item)}
                            for item, score, _ in priorities]
    cleanup = ExitStack()
    try:
        check()
        old_threads = _TORCH.get_num_threads()
        cleanup.callback(_TORCH.set_num_threads, old_threads)
        _TORCH.set_num_threads(max(1, int(threads)))
        cuda_devices = [_TORCH.cuda.current_device()] if _DEVICE.startswith("cuda") else []
        cleanup.enter_context(_TORCH.random.fork_rng(devices=cuda_devices))
        _TORCH.random.default_generator.manual_seed(42)
        if cuda_devices:
            _TORCH.cuda.manual_seed(42)
        old_deterministic = _TORCH.are_deterministic_algorithms_enabled()
        old_warn_only = _TORCH.is_deterministic_algorithms_warn_only_enabled()
        cleanup.callback(_TORCH.use_deterministic_algorithms, old_deterministic, warn_only=old_warn_only)
        _TORCH.use_deterministic_algorithms(True)
        for module in _MODEL.modules():
            handle = module.register_forward_pre_hook(lambda _module, _inputs: check())
            cleanup.callback(handle.remove)
        longest_cost_unit = 0.0
        for item, proxy, column in priorities:
            widths = [context[3][column] for context in contexts]
            if any(width < 1 for width in widths):
                detail["excluded_items"].append({"item": item, "reason": "empty_support", "width": max(widths)})
                continue
            if max_items is not None and len(detail["covered_items"]) >= max(0, int(max_items)):
                break
            check()
            remaining = deadline - perf_counter()
            if budget is not None:
                remaining = min(remaining, budget.remaining())
            cost = _class_cost(max(widths))
            if not frozen and longest_cost_unit and remaining <= longest_cost_unit * cost:
                detail["excluded_items"].append({"item": item, "reason": "remaining_budget",
                                                "width": max(widths)})
                continue
            item_started, pending, folds, gain_sum, count = perf_counter(), [], [], 0.0, 0
            for attempt in range(2):
                pending, folds, gain_sum, count = [], [], 0.0, 0
                try:
                    for plan, (data, laws, targets, cards, train, query) in zip(plans, contexts):
                        fit_started = perf_counter()
                        p = _predict_item(features, targets[:, column], cards[column], train, query, check,
                                          n_estimators=n_estimators)
                        if item in laws:
                            p = gfic.compose_gate(p, laws[item], query)
                        if (p.shape != (len(query), full_data.ycards[column]) or not np.isfinite(p).all()
                                or np.any(p < 0) or not np.allclose(p.sum(1), 1, atol=1e-9, rtol=0)):
                            raise ValueError("Invalid composed TabICL output")
                        pending.append(p)
                        folds.append({"kind": plan["kind"], "seconds": perf_counter() - fit_started,
                                      "train_rows": int(np.sum(targets[train, column] >= 0)),
                                      "query_rows": len(query), "device": _DEVICE,
                                      "n_estimators": n_estimators})
                        if plan["kind"] == "outer" and "C1" in plan.get("bank", {}):
                            labels = full_data.y[query, column]
                            valid = labels >= 0
                            row = np.flatnonzero(valid)
                            base = plan["bank"]["C1"].probabilities[item]
                            gain_sum += float((np.log(np.maximum(p[row, labels[valid]], np.finfo(float).tiny))
                                              - np.log(np.maximum(base[row, labels[valid]], np.finfo(float).tiny))).sum())
                            count += len(row)
                    break
                except CandidateBudgetExceeded:
                    raise
                except RuntimeError as error:
                    if not _DEVICE.startswith("cuda") or attempt:
                        raise
                    detail["device_fallbacks"].append({"item": item, "from": _DEVICE,
                                                      "reason": type(error).__name__,
                                                      "error": str(error),
                                                      "n_estimators_before": n_estimators,
                                                      "n_estimators_after": 1})
                    try:
                        _cpu_after_failure(error)
                    except Exception as failure:
                        raise _FallbackFailure(list(detail["covered_items"])) from failure
                    n_estimators = 1
                    longest_cost_unit = 0.0
                    if cpu_fallback_allowance is not None:
                        now = perf_counter()
                        capped, allocation = cpu_fallback_allowance(max(0.0, deadline - now))
                        if allocation is not None:
                            deadline = min(deadline, now + max(0.0, float(capped)))
                            detail["device_fallbacks"][-1]["allocation"] = allocation
                    check()
            check()
            for bank, p in zip(probabilities, pending):
                bank[item] = p
            seconds = perf_counter() - item_started
            longest_cost_unit = max(longest_cost_unit, seconds / cost)
            detail["covered_items"].append(item)
            detail["items"].append({"item": item, "seconds": seconds, "folds": folds,
                                   "oof_gain_vs_C1_nats": gain_sum / count if count else None,
                                   "oof_rows": count, "priority_content_entropy_per_cost": proxy,
                                   "many_class": max(widths) > MAX_CLASSES,
                                   "device": _DEVICE, "n_estimators": n_estimators})
        detail["status"] = "budget" if any(x["reason"] == "remaining_budget" for x in detail["excluded_items"]) else "ok"
    except CandidateBudgetExceeded:
        detail["status"] = "budget"
    except _FallbackFailure:
        raise
    except Exception as error:
        detail.update(status="error", error_type=type(error).__name__, error=str(error))
    finally:
        try:
            cleanup.close()
        except Exception as error:
            detail["cleanup_error"] = type(error).__name__
        detail["elapsed_seconds"] = perf_counter() - started
        detail.update(device=_DEVICE, device_status=_DEVICE_STATUS)
    if not detail["covered_items"]:
        return [{} for _ in plans], detail
    return [{NAME: legacy.Candidate(NAME, values)} for values in probabilities], detail
