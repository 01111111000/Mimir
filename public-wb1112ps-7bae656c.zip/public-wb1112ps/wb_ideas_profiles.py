from time import perf_counter

import numpy as np
from scipy.optimize import minimize
from scipy.sparse import vstack
from scipy.special import expit, logit

import gfic_legacy as gfic
import legacy
import wb_response as response

NAME = "WB_PROFILE_NA"
PROFILE_GIVEN = ("user.age", "user.gender", "user.country", "user.educationLevel",
                 "user.wageOfSimilarEmployees", "user.lowestAcceptablePay")
PROFILE_L2 = 20.0
MAX_ITER = 80


def subbattery(item):
    tail = item.removeprefix("sc_nstd_")
    if item.startswith("sc_"):
        if tail in ("extra", "agree", "consc", "stability", "open"):
            return "sc_big_five"
        if tail in ("s_aware", "s_manage", "soc_aware"):
            return "sc_emotional_intelligence"
        if tail in ("realistic", "invest", "artistic", "social", "enterp", "convent"):
            return "sc_riasec"
        if tail.startswith(("ds_", "corsi_")):
            return "sc_memory"
        if tail.startswith("tmt_"):
            return "sc_trail_making"
        if tail.startswith("mtpt_"):
            return "sc_mirror_tracing"
        return "sc_" + tail
    if item.startswith("tr_"):
        if item in ("tr_employment_status", "tr_job_full", "tr_job_number", "tr_job_offers"):
            return "tr_employment"
        if item in ("tr_similar_wage_after", "tr_low_pay_after", "tr_search_hours_after",
                    "tr_applications_next_1m", "tr_target_sector", "tr_riasec_target_sector"):
            return "tr_job_search"
        if item in ("tr_feel_work", "tr_self_efficacy"):
            return "tr_attitudes"
        return "tr_feedback"
    if item.startswith("user."):
        if item in ("user.accessedLearningLinks", "user.howManyHoursToUpskillPerWeek",
                    "user.plannedCourses", "user.helpGetInterview", "user.helpGetJobInDesiredSector"):
            return "user_upskilling"
        if item in ("user.howLongSearchingForJob", "user.howManyHoursSearchedPerWeek",
                    "user.howManyApplicationsLastMonth", "user.expectedToFindJobInSixMonths",
                    "user.howLongUnemployed", "user.howLongInCurrentPosition",
                    "user.appliedInThePastSector", "user.preferredSector"):
            return "user_initial_work"
        return "user_feedback"
    return "other"


def profile_codes(data, rows):
    codes = np.zeros(len(rows), dtype=np.int64)
    for bit, name in enumerate(PROFILE_GIVEN):
        if name not in data.given or "Not answered" not in data.options[name]:
            raise ValueError("WB_PROFILE_NA requires the six documented GIVEN fields")
        codes |= ((data.codes[name][rows] == data.options[name].index("Not answered"))
                  .astype(np.int64) << bit)
    return codes


def _states(data, train, laws):
    labels = np.asarray(data.y[train], dtype=np.int64)
    columns, na_indices, cards, state = [], [], [], []
    for j, item in enumerate(data.targets):
        gate = data.schema["items"][item].get("gate")
        if gate and item not in laws:
            continue
        width = laws[item]["sentinel"] if item in laws else data.ycards[j]
        options = data.options[item][:width]
        if "Not answered" not in options or width < 2:
            continue
        na = options.index("Not answered")
        y = labels[:, j]
        valid = (y >= 0) & (y < width)
        columns.append(j)
        na_indices.append(na)
        cards.append(width - 1)
        state.append(np.where(valid, (y == na).astype(int), -1))
    return columns, na_indices, cards, (np.column_stack(state) if state
                                       else np.empty((len(train), 0), dtype=int))


def candidate(data, train, query, budget=None, reference=None):
    started = perf_counter()
    train, query = np.asarray(train, int), np.asarray(query, int)
    if np.intersect1d(train, query).size or train.ndim != 1 or query.ndim != 1:
        raise ValueError("TRAIN and QUERY must be disjoint vectors")
    if not len(train) or not len(query):
        return legacy.Candidate(NAME, {}), {"status": "empty_train_or_query"}
    reused = reference is not None
    if reference is None:
        reference, _ = response.candidate(data, train, query, budget)
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
    columns, na_indices, cards, state = _states(data, train, laws)
    if not columns:
        return legacy.Candidate(NAME, {}), {"status": "no_eligible_items"}
    x, xq = response._design(data, train, query)
    base, state_detail = response._fit_state(
        x, vstack((x, xq), format="csr"), state,
        [response._family(data.targets[j]) for j in columns], cards, budget)
    offsets = logit(np.clip(base[:len(train)], 1e-10, 1 - 1e-10))
    profiles, query_profiles = profile_codes(data, train), profile_codes(data, query)
    battery_names = list(dict.fromkeys(subbattery(data.targets[j]) for j in columns))
    battery = np.array([battery_names.index(subbattery(data.targets[j])) for j in columns])
    n_batteries = len(battery_names)
    valid = state >= 0
    target = np.maximum(state, 0)
    weights = valid / np.bincount(battery)[battery][None, :]
    keys = profiles[:, None] * n_batteries + battery[None, :]

    def objective(flat):
        response._checkpoint(budget)
        logits = offsets + flat[keys]
        loss = np.sum(weights * (np.logaddexp(0., logits) - target * logits))
        residual = weights * (expit(logits) - target)
        grad = np.bincount(keys.ravel(), weights=residual.ravel(), minlength=len(flat))
        return float(loss + .5 * PROFILE_L2 * np.dot(flat, flat)), grad + PROFILE_L2 * flat

    fit = minimize(objective, np.zeros(64 * n_batteries), method="L-BFGS-B", jac=True,
                   callback=lambda _: response._checkpoint(budget),
                   options={"maxiter": MAX_ITER, "ftol": 1e-10, "gtol": 1e-6})
    if not np.isfinite(fit.x).all():
        raise FloatingPointError("Nonfinite profile correction")
    corrections = fit.x.reshape(64, n_batteries)
    values = {}
    for h, (j, na) in enumerate(zip(columns, na_indices)):
        item = data.targets[j]
        p = np.array(reference.probabilities[item], dtype=float, copy=True)
        sentinel = laws[item]["sentinel"] if item in laws else None
        open_mass = 1 - p[:, sentinel] if sentinel is not None else np.ones(len(query))
        old = np.clip(p[:, na] / np.maximum(open_mass, 1e-12), 1e-10, 1 - 1e-10)
        new = expit(logit(old) + corrections[query_profiles, battery[h]])
        substantive = [k for k in range(p.shape[1]) if k not in (na, sentinel)]
        p[:, substantive] *= ((1 - new) / (1 - old))[:, None]
        p[:, na] = new * open_mass
        values[item] = legacy.normalize(p)
    return legacy.Candidate(NAME, values), {
        "status": "fitted", "model": "profile_subbattery_log_odds_correction",
        "profile_given": list(PROFILE_GIVEN), "profile_count_train": int(len(np.unique(profiles))),
        "subbatteries": {data.targets[j]: subbattery(data.targets[j]) for j in columns},
        "l2_respondent_units": PROFILE_L2, "reference_reused": reused,
        "state": state_detail, "iterations": int(fit.nit), "converged": bool(fit.success),
        "max_abs_correction": float(np.max(np.abs(corrections))),
        "content_ratios_and_gate_masses_preserved": True,
        "seconds": perf_counter() - started,
    }
