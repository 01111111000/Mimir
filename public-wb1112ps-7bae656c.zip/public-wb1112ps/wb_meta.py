from dataclasses import dataclass, replace
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

import legacy
import gfic_legacy as gfic
import wb_factorized_pool as factor
from budget import CandidateBudgetExceeded


@dataclass
class MetaState:
    stack: dict
    choices: dict
    class_losses: dict
    temperature: float
    marginal_weight: float
    pairs: dict
    pools: dict
    pool_names: dict
    config: object
    diagnostics: dict


class _FactorDeadline:
    def __init__(self, seconds, parent=None):
        self.deadline = perf_counter() + max(0.0, float(seconds))
        self.parent = parent

    def checkpoint(self):
        if self.parent is not None:
            self.parent.checkpoint()
        if perf_counter() >= self.deadline:
            raise CandidateBudgetExceeded('factorized meta reservation exhausted')


def subset_bank(bank, positions):
    positions = np.asarray(positions, dtype=int)
    return {name: legacy.Candidate(name, {
        item: None if p is None else p[positions]
        for item, p in candidate.probabilities.items()})
        for name, candidate in bank.items()}


def _check_raw(bank, provenance=None):
    if any(name == 'GFIC_C4' or name.startswith('GFIC_C4_') for name in bank):
        raise ValueError('GFIC_C4 must be excluded from the honest WB meta bank')
    if 'C1' not in bank:
        raise ValueError('C1 is required as calibration reference, even when excluded from mixing')
    if any(name.startswith('KDB_') for name in bank):
        if not isinstance(provenance, dict) or provenance.get('kdb_temperature_applied') is not False:
            raise ValueError('Raw kDB provenance must explicitly declare kdb_temperature_applied=False')


def _check(budget):
    if budget is not None:
        budget.checkpoint()


def _selected(bank, choices):
    out = dict(bank)
    for name, key in choices.items():
        if key not in bank:
            raise ValueError('Selected raw class variant missing from prediction bank: ' + key)
        out[name] = legacy.Candidate(name, bank[key].probabilities)
    return out


def _fit_linear(bank, data, rows, config, item_calibration, budget):
    _check(budget)
    selected, count, losses = legacy.select_classes(bank, data, rows, config)
    choices = {'C4': 'C4_%d' % count} if count is not None else {}
    enabled = tuple(name for name in config.enabled if name in selected)
    if not enabled:
        enabled = ('C1',)
    cfg = replace(config, enabled=enabled)
    stack = legacy.fit_stack(selected, data, rows, cfg)
    _check(budget)
    temperature, blend = legacy.fit_calibration(stack, selected['C1'], data, rows, cfg)
    if not np.isfinite([temperature, blend]).all():
        temperature, blend = 1.0, 0.0
    if item_calibration:
        pairs = gfic.fit_item_calibration(stack, selected['C1'], data, rows,
                                          cfg, temperature, blend, budget)
    else:
        pairs = {item: (temperature, blend) for item in data.targets}
    for item, pair in pairs.items():
        if not np.isfinite(pair).all():
            pairs[item] = (temperature, blend)
    _check(budget)
    return MetaState(stack, choices, losses, temperature, blend, pairs, {}, {}, cfg,
                     {'training_rows': len(rows), 'factorized': False,
                      'candidate_names': stack['names'], 'classes': choices,
                      'item_calibration': bool(item_calibration)})


def _fit_factor(bank, data, rows, linear, strength, budget, max_iter, solver='slsqp'):
    selected = _selected(bank, linear.choices)
    pools, names_by_item = {}, {}
    for item in data.targets:
        _check(budget)
        names = [name for name in linear.stack['names']
                 if selected[name].probabilities.get(item) is not None]
        if not names:
            continue
        slots = [linear.stack['names'].index(name) for name in names]
        prior = legacy.normalize(linear.stack['weights'][item][slots])
        options = list(data.options[item])
        gate = data.schema.get('gated_value', 'NA_GATED')
        gate_index = options.index(gate) if gate in options else None
        na_index = options.index('Not answered') if 'Not answered' in options else None
        if len(options) <= sum(v is not None for v in (gate_index, na_index)):
            continue
        temperature, blend = linear.pairs[item]
        pools[item] = factor.fit_item(
            np.stack([selected[name].probabilities[item] for name in names]),
            data.codes[item][rows], prior, gate_index=gate_index, na_index=na_index,
            metric_floor=linear.config.metric_floor, strength=strength,
            temperature=temperature, marginal_blend=blend,
            marginal_probs=selected['C1'].probabilities[item],
            output_floor=linear.config.floor, max_iter=max_iter, budget=budget, solver=solver)
        names_by_item[item] = names
    _check(budget)
    return replace(linear, pools=pools, pool_names=names_by_item,
                   diagnostics={**linear.diagnostics, 'factorized': True,
                                'factor_strength': float(strength),
                                'factor_items': len(pools),
                                'factor_max_iter': int(max_iter), 'factor_solver': str(solver),
                                'factor_optimizer_iterations': sum(
                                    s.diagnostics.get('iterations', 0) for s in pools.values())})


def fit_meta(bank, data, rows, config, *, positions=None, factorized=False,
             factor_strength=200.0, item_calibration=True, budget=None,
             factor_max_iter=80, provenance=None, factor_solver='slsqp'):
    _check_raw(bank, provenance)
    rows = np.asarray(rows, dtype=int)
    if positions is not None:
        positions = np.asarray(positions, dtype=int)
        bank, rows = subset_bank(bank, positions), rows[positions]
    if not len(rows):
        raise ValueError('At least one visible meta-fit respondent is required')
    started = perf_counter()
    with threadpool_limits(limits=1):
        state = _fit_linear(bank, data, rows, config, item_calibration, budget)
        if factorized:
            state = _fit_factor(bank, data, rows, state, factor_strength, budget,
                                factor_max_iter, factor_solver)
    state.diagnostics['seconds'] = perf_counter() - started
    state.diagnostics['bank_provenance'] = dict(provenance or {})
    return state


def predict_meta(bank, state, pool_failure=None):
    selected = _selected(bank, state.choices)
    prediction = gfic.apply_stack(selected, state.stack, state.temperature,
                                 state.marginal_weight, state.config, state.pairs)
    try:
        pooled = {}
        for item, pool in state.pools.items():
            value = factor.predict_item(
                np.stack([selected[name].probabilities[item] for name in state.pool_names[item]]),
                pool, marginal_probs=selected['C1'].probabilities[item])
            if not np.isfinite(value).all() or (value < 0).any():
                raise ValueError('Invalid factorized pool output')
            pooled[item] = value
    except Exception as error:
        if pool_failure is None:
            raise
        pool_failure.update(status='failed_atomically', exception=type(error).__name__)
        return prediction
    prediction.probabilities.update(pooled)
    return prediction


def respondent_nll(prediction, data, rows, metric_floor=1e-3):
    rows = np.asarray(rows, dtype=int)
    losses = np.zeros(len(rows))
    counts = np.zeros(len(rows), dtype=int)
    for item in data.targets:
        p = prediction.probabilities[item]
        y = data.codes[item][rows]
        valid = y >= 0
        if p.shape != (len(rows), len(data.options[item])):
            raise ValueError('Prediction rows/options do not align with evaluation respondents')
        if not np.isfinite(p).all() or (p < 0).any() or not np.allclose(p.sum(1), 1, atol=1e-8):
            raise ValueError('Illegal probability vector in meta evaluation')
        q = metric_floor + (1 - p.shape[1] * metric_floor) * p[valid, y[valid]]
        losses[valid] -= np.log(q)
        counts[valid] += 1
    return np.divide(losses, counts, out=np.full(len(rows), np.nan), where=counts > 0)


def honest_compare(bank, data, rows, fold_of, config, *, factor_strength=200.0,
                   item_calibration=True, seed=981013, budget=None, factor_max_iter=80,
                   provenance=None, factor_solver='slsqp'):
    _check_raw(bank, provenance)
    rows, fold_of = np.asarray(rows, dtype=int), np.asarray(fold_of)
    if rows.shape != fold_of.shape or len(np.unique(rows)) != len(rows):
        raise ValueError('OOF respondent rows and base fold identities must align uniquely')
    if not np.issubdtype(fold_of.dtype, np.integer) or (fold_of < 0).any():
        raise ValueError('Every OOF respondent must have one nonnegative integer base fold identity')
    details, positions_scored, linear_losses, factor_losses = [], [], [], []
    with threadpool_limits(limits=1):
        for fold in np.unique(fold_of):
            _check(budget)
            block = np.flatnonzero(fold_of == fold)
            if len(block) < 4:
                return {'accepted': False, 'status': 'insufficient_held_block', 'folds': details}
            permutation = np.random.default_rng(seed + int(fold)).permutation(block)
            fit_pos, valid_pos = permutation[::2], permutation[1::2]
            fit_bank = subset_bank(bank, fit_pos)
            valid_bank = subset_bank(bank, valid_pos)
            linear = _fit_linear(fit_bank, data, rows[fit_pos], config, item_calibration, budget)
            candidate = _fit_factor(fit_bank, data, rows[fit_pos], linear,
                                    factor_strength, budget, factor_max_iter, factor_solver)
            before = respondent_nll(predict_meta(valid_bank, linear), data,
                                    rows[valid_pos], config.metric_floor)
            after = respondent_nll(predict_meta(valid_bank, candidate), data,
                                   rows[valid_pos], config.metric_floor)
            if not np.isfinite(before).all() or not np.isfinite(after).all():
                raise ValueError('Nonfinite guard loss')
            linear_losses.extend(before.tolist())
            factor_losses.extend(after.tolist())
            positions_scored.extend(valid_pos.tolist())
            details.append({'base_fold': int(fold), 'meta_fit_count': len(fit_pos),
                            'validation_count': len(valid_pos),
                            'meta_fit_positions': fit_pos.tolist(),
                            'validation_positions': valid_pos.tolist(),
                            'disjoint_respondents': not bool(np.intersect1d(fit_pos, valid_pos).size),
                            'same_base_block': True, 'delta_nll': float(np.mean(before - after)),
                            'classes': linear.choices})
    delta = np.asarray(linear_losses) - np.asarray(factor_losses)
    gain = float(delta.mean()) if len(delta) else 0.0
    return {'accepted': bool(len(delta) and gain > 0.0), 'status': 'completed',
            'delta_nll': gain, 'respondents': len(delta), 'folds': details,
            'positions': positions_scored, 'linear_nll': linear_losses,
            'factor_nll': factor_losses,
            'interpretation': 'TRAIN admission guard; external query required for performance estimate'}


def fit_with_guard(bank, data, rows, fold_of, config, *, factorized=False,
                   factor_strength=200.0, item_calibration=True, budget=None,
                   factor_seconds=60.0, factor_max_iter=80, provenance=None, factor_solver='slsqp'):
    started = perf_counter()
    linear = fit_meta(bank, data, rows, config, item_calibration=item_calibration,
                      budget=budget, provenance=provenance)
    details = {'linear': linear.diagnostics, 'factor_requested': bool(factorized),
               'factor_reserve_seconds': float(factor_seconds), 'factor_accepted': False}
    if not factorized:
        details.update(status='disabled', seconds=perf_counter() - started)
        return linear, details
    factor_started = perf_counter()
    reservation = _FactorDeadline(factor_seconds, budget)
    try:
        comparison = honest_compare(bank, data, rows, fold_of, config,
                                     factor_strength=factor_strength,
                                     item_calibration=item_calibration, budget=reservation,
                                     factor_max_iter=factor_max_iter, provenance=provenance,
                                     factor_solver=factor_solver)
        details['guard'] = comparison
        if comparison['accepted']:
            with threadpool_limits(limits=1):
                candidate = _fit_factor(bank, data, np.asarray(rows, dtype=int), linear,
                                        factor_strength, reservation, factor_max_iter, factor_solver)
            reservation.checkpoint()
            details.update(factor_accepted=True, status='accepted', factor=candidate.diagnostics,
                           factor_seconds=perf_counter() - factor_started,
                           seconds=perf_counter() - started)
            return candidate, details
        details['status'] = 'validation_rejected'
    except CandidateBudgetExceeded as error:
        details.update(status='reservation_exhausted', reason=str(error))
    except Exception as error:
        details.update(status='failed_atomically', exception=type(error).__name__)
    details.update(factor_seconds=perf_counter() - factor_started, seconds=perf_counter() - started)
    return linear, details
