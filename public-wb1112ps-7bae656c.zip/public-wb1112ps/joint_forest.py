import numpy as np
from sklearn.ensemble import ExtraTreesClassifier


def _row_indices(rows, size):
    rows = np.asarray(rows)
    if rows.ndim != 1:
        raise ValueError("Row selectors must be one-dimensional")
    if rows.dtype == bool:
        if len(rows) != size:
            raise ValueError("Boolean row selectors must cover the full frame")
        return np.flatnonzero(rows)
    indices = rows.astype(np.int64)
    if np.any(indices < 0) or np.any(indices >= size):
        raise ValueError("Row index outside the frame")
    return indices


def _one_hot(codes, cards, rows):
    offsets = np.r_[0, np.cumsum(cards + 1)]
    design = np.zeros((len(rows), int(offsets[-1])), dtype=np.float32)
    selected = codes[rows]
    row_ids = np.arange(len(rows))
    for column, card in enumerate(cards):
        values = selected[:, column]
        levels = np.where((values >= 0) & (values < card), values, card)
        design[row_ids, offsets[column] + levels] = 1.0
    return design


def predict_joint_forest(feature_codes, feature_cards, target_codes, target_cards,
                         train_rows, query_rows, seed=13, trees=24, max_depth=7,
                         min_leaf=64, alpha=20.0, repair=False):
    if repair:
        max_depth, alpha = 11, 1.5
    max_features = "sqrt" if repair else 0.7
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("alpha must be finite and strictly positive")
    for name, value in (("trees", trees), ("max_depth", max_depth), ("min_leaf", min_leaf)):
        if not isinstance(value, (int, np.integer)) or value < 1:
            raise ValueError(name + " must be a positive integer")

    features = np.asarray(feature_codes, dtype=np.int64)
    target_view = np.asarray(target_codes)
    cards = np.asarray(feature_cards, dtype=np.int64)
    widths = np.asarray(target_cards, dtype=np.int64)
    if features.ndim != 2 or target_view.ndim != 2:
        raise ValueError("Code matrices must have two dimensions")
    if features.shape[0] != target_view.shape[0]:
        raise ValueError("Feature and target matrices must share respondents")
    if cards.ndim != 1 or len(cards) != features.shape[1] or np.any(cards < 1):
        raise ValueError("Each feature needs a positive schema cardinality")
    if widths.ndim != 1 or len(widths) != target_view.shape[1] or np.any(widths < 1):
        raise ValueError("Each target needs a positive schema cardinality")
    train = _row_indices(train_rows, len(features))
    query = _row_indices(query_rows, len(features))
    if np.intersect1d(train, query).size:
        raise ValueError("Training and query respondents must be disjoint")

    fit_targets = np.asarray(target_view[train], dtype=np.int64)
    valid = (fit_targets >= 0) & (fit_targets < widths)
    valid_counts = valid.sum(axis=0)
    priors = []
    for column, width in enumerate(widths):
        counts = np.bincount(fit_targets[valid[:, column], column], minlength=width)
        priors.append((counts + 0.5) / (counts.sum() + 0.5 * width))
    predictions = [np.broadcast_to(p, (len(query), len(p))).copy() for p in priors]
    active = np.flatnonzero(valid_counts > 0)
    eligible = valid[:, active].all(axis=1) if len(active) else np.zeros(len(train), dtype=bool)
    fit_rows = train[eligible]
    diag = {
        "model": "shared_partition_multinomial_forest",
        "training_rows": int(len(train)),
        "fit_rows": int(len(fit_rows)),
        "query_rows": int(len(query)),
        "feature_columns": int(np.sum(cards + 1)),
        "output_columns": int(np.sum(widths)),
        "active_outputs": int(len(active)),
        "valid_counts": valid_counts.tolist(),
        "trees": int(trees),
        "max_depth": int(max_depth),
        "min_leaf": int(min_leaf),
        "max_features": max_features,
        "alpha": float(alpha),
        "marginal_alpha": 0.5,
        "seed": int(seed),
        "criterion": "entropy",
        "n_jobs": 8,
        "fitted": False,
        "nodes": 0,
        "leaves": 0,
    }
    if not (len(fit_rows) and len(query) and len(cards) and len(active)):
        return predictions, diag

    x_train = _one_hot(features, cards, fit_rows)
    x_query = _one_hot(features, cards, query)
    y_train = fit_targets[eligible][:, active]
    forest = ExtraTreesClassifier(
        n_estimators=int(trees), criterion="entropy", max_depth=int(max_depth),
        min_samples_leaf=int(min_leaf), max_features=max_features, bootstrap=False,
        random_state=int(seed), n_jobs=8,
    )
    from joblib import parallel_backend
    with parallel_backend("threading", n_jobs=8):
        forest.fit(x_train, y_train[:, 0] if len(active) == 1 else y_train)
    for column in active:
        predictions[column].fill(0.0)

    for estimator in forest.estimators_:
        leaves, leaf_indices = np.unique(estimator.apply(x_train), return_inverse=True)
        query_leaves = np.searchsorted(leaves, estimator.apply(x_query))
        leaf_counts = np.bincount(leaf_indices, minlength=len(leaves))[:, None]
        for local, column in enumerate(active):
            width = int(widths[column])
            counts = np.bincount(
                leaf_indices * width + y_train[:, local],
                minlength=len(leaves) * width,
            ).reshape(len(leaves), width)
            probability = (counts + alpha * priors[column]) / (leaf_counts + alpha)
            predictions[column] += probability[query_leaves] / len(forest.estimators_)
        diag["nodes"] += int(estimator.tree_.node_count)
        diag["leaves"] += int(len(leaves))

    for probabilities in predictions:
        probabilities /= probabilities.sum(axis=1, keepdims=True)
    diag["fitted"] = True
    return predictions, diag
