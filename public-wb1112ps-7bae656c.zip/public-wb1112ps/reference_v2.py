from dataclasses import asdict, dataclass, field, replace
from time import perf_counter

import numpy as np
from contextlib import nullcontext

try:
    from threadpoolctl import threadpool_limits
except ImportError:
    def threadpool_limits(**kwargs):
        return nullcontext()

import legacy


MIN_COMPLETE_ROWS = 40
MIN_CALIBRATION_ROWS = 8
NEW_CANDIDATES = ("LinearFull", "NeuralShared", "StructLF")


@dataclass(frozen=True)
class Config:
    seed: int = 13
    meta_fraction: float = 0.25
    calibration_share: float = 0.25
    base_config: legacy.Config = field(default_factory=legacy.Config)
    enable_linear: bool = True
    enable_neural: bool = True
    enable_structure: bool = True


def _candidate_config(config):
    names = [name for name in config.base_config.enabled if name not in NEW_CANDIDATES]
    if config.enable_linear:
        names.append("LinearFull")
    if config.enable_neural:
        names.append("NeuralShared")
    if config.enable_linear and config.enable_structure:
        names.append("StructLF")
    return replace(config.base_config, seed=config.seed, enabled=tuple(dict.fromkeys(names)))


def _split_meta(complete, config):
    rng = np.random.default_rng(config.seed)
    shuffled = rng.permutation(complete)
    count = min(len(complete) - 2, max(2, int(len(complete) * config.meta_fraction)))
    meta, train = np.sort(shuffled[:count]), np.sort(shuffled[count:])
    positions = rng.permutation(len(meta))
    calibration_count = min(len(meta) - 1, max(1, int(len(meta) * config.calibration_share)))
    calibration = np.sort(positions[:calibration_count])
    weights = np.sort(positions[calibration_count:])
    return train, meta, weights, calibration


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


def _family(name):
    return "C4" if name.startswith("C4_") else name


def _fit_bank_impl(frame, schema, train, query, config, base_config, classes=None,
                   budget=None, failed=None, state=None):
    failed = set() if failed is None else failed
    _checkpoint(budget)
    outside = np.ones(len(frame), dtype=bool)
    outside[train] = False
    masked = legacy.mask_respondents(frame, schema, np.flatnonzero(outside))
    with threadpool_limits(limits=8):
        candidates, times, details = legacy.fit_candidates(
            masked, schema, train, query, base_config, classes,
            budget=budget, failed=failed
        )
    state.update(bank=candidates, times=times, details=details)
    _checkpoint(budget)
    variants = []
    if config.enable_linear:
        variants.append("LinearFull")
    if config.enable_neural:
        variants.append("NeuralShared")
    data = None
    for name in variants:
        if name in failed:
            continue
        _checkpoint(budget)
        started = perf_counter()
        try:
            from conditional_mlp import NeuralConfig, predict_neural
            if data is None:
                data = legacy.Data(masked, schema, base_config)
            model_config = NeuralConfig(seed=config.seed,
                metric_floor=base_config.metric_floor, threads=8)
            if name == "LinearFull":
                model_config = replace(model_config, hidden=())
            values, detail = predict_neural(data.x, data.xcards, data.y,
                data.ycards, train, query, model_config, budget=budget)
            if any(not np.isfinite(p).all() or (p < 0).any() or
                   (p.sum(axis=1) <= 0).any() for p in values if p is not None):
                raise ValueError("invalid candidate distributions")
            candidates[name] = legacy.Candidate(name, dict(zip(data.targets, values)))
            details["components"][name] = detail
        except Exception as exc:
            from budget import CandidateBudgetExceeded
            if isinstance(exc, CandidateBudgetExceeded):
                raise
            failed.add(name)
            details["components"][name] = {"failed": type(exc).__name__}
        times[name] = perf_counter() - started
        _checkpoint(budget)
    if config.enable_structure and config.enable_linear and "StructLF" not in failed:
        if "LinearFull" in failed or "LinearFull" not in candidates:
            failed.add("StructLF")
        else:
            _checkpoint(budget)
            started = perf_counter()
            try:
                from structure import propagate
                values, detail = propagate(masked, schema, train, query,
                    candidates["LinearFull"].probabilities, round_name=data.round)
                candidates["StructLF"] = legacy.Candidate("StructLF", values)
                details["components"]["StructLF"] = detail
            except Exception as exc:
                from budget import CandidateBudgetExceeded
                if isinstance(exc, CandidateBudgetExceeded):
                    raise
                failed.add("StructLF")
                details["components"]["StructLF"] = {"failed": type(exc).__name__}
            times["StructLF"] = perf_counter() - started
            _checkpoint(budget)
    candidates = {k: v for k, v in candidates.items() if _family(k) not in failed}
    return candidates, times, details


def _fit_bank(frame, schema, train, query, config, base_config, classes=None,
              budget=None, failed=None):
    from budget import CandidateBudgetExceeded
    state = {}
    try:
        return _fit_bank_impl(frame, schema, train, query, config, base_config,
                              classes, budget, failed, state)
    except CandidateBudgetExceeded as error:
        if state:
            error.partial_bank = {name: candidate for name, candidate in state['bank'].items()
                                  if _family(name) not in (failed or set())}
            error.partial_times = dict(state['times'])
            error.partial_details = state['details']
        raise


def _small_route(frame, schema, complete, query, data, config, budget):
    reduced = replace(config, enable_linear=False, enable_neural=False,
        enable_structure=False, base_config=replace(config.base_config,
        enabled=("C1", "C2")))
    base_config = _candidate_config(reduced)
    failed = set()
    bank, times, details = _fit_bank(frame, schema, complete, query, reduced,
        base_config, budget=budget, failed=failed)
    names = [n for n in ("C1", "C2") if n in bank]
    if "C1" not in bank:
        raise RuntimeError("C1 unavailable in reduced UNHCR route")
    probabilities = {}
    for item in data.targets:
        parts = [bank[n].probabilities[item] for n in names
                 if bank[n].probabilities.get(item) is not None]
        probabilities[item] = legacy.output_distribution(sum(parts) / len(parts), base_config.floor)
    candidate = legacy.Candidate("reduced", probabilities)
    _checkpoint(budget)
    output, remap = _render(frame, schema, complete, query, data, candidate, base_config)
    return output, {"route": "bounded_C1_C2", "candidate_names": names,
        "failed_families": sorted(failed), "component_seconds": times,
        "final": details, "wave_remap": remap}


def _render(frame, schema, complete, query, data, prediction, base_config):
    remapped_items, details = legacy.detect_wave_zero_items(frame, schema, complete)
    wave1_query = (frame.iloc[query]["wave"].eq("1").fillna(False).to_numpy(dtype=bool)
                   if remapped_items else np.zeros(len(query), dtype=bool))
    output = []
    for position in range(len(query)):
        for item in data.targets:
            p = prediction.predict(position, item)
            if wave1_query[position] and item in remapped_items:
                p = legacy.remap_wave_zero_vector(p, remapped_items[item], base_config.floor)
            output.append(p.tolist())
    return output, details


def _predict_with_diagnostics_impl(frame, schema, config=None, budget=None, state=None):
    config = config or Config()
    if not 0 < config.meta_fraction < 1 or not 0 < config.calibration_share < 1:
        raise ValueError("Meta and calibration fractions must be strictly between zero and one")
    started = perf_counter()
    base_config = _candidate_config(config)
    data = legacy.Data(frame, schema, base_config)
    complete = legacy.complete_rows(frame, schema)
    query = legacy.hidden_rows(frame, schema)
    if not len(query):
        return [], {"route": "empty_query", "seconds": perf_counter() - started}
    if not data.c5_applicable or len(complete) < MIN_COMPLETE_ROWS:
        output, details = _small_route(frame, schema, complete, query, data, config, budget)
        details["reason"] = ("non_ERPIS" if not data.c5_applicable else
                             "fewer_than_40_complete_respondents")
        details["seconds"] = perf_counter() - started
        return output, details
    if (base_config.k <= 0 or base_config.alpha <= 0 or base_config.weight_k <= 0
            or base_config.m < 0 or base_config.kernel_width <= 0 or base_config.floor <= 0
            or base_config.metric_floor < 0
            or max(data.ycards) * base_config.metric_floor >= 1
            or "C1" not in base_config.enabled):
        raise ValueError("Invalid candidate smoothing configuration or missing C1 reference")

    failed = set()
    train, meta, weight_positions, calibration_positions = _split_meta(complete, config)
    state.update(config=config, base_config=base_config, data=data, complete=complete,
                 query=query, train=train, meta=meta, weight_positions=weight_positions,
                 calibration_positions=calibration_positions, failed=failed,
                 started=started, stage="meta")
    bank, times, meta_details = _fit_bank(frame, schema, train, meta, config,
        base_config, budget=budget, failed=failed)
    state.update(bank=bank, times=dict(times), meta_details=meta_details)
    _checkpoint(budget)
    with threadpool_limits(limits=8):
        selected, classes, class_losses = legacy.select_classes(
            bank, data, meta, base_config, selection=weight_positions)
    state.update(selected=selected, classes=classes, class_losses=class_losses)
    _checkpoint(budget)
    state["stage"] = "final"
    final, final_times, final_details = _fit_bank(frame, schema, complete, query,
        config, base_config, (classes,) if classes else None,
        budget=budget, failed=failed)
    state.update(final=final, final_times=final_times, final_details=final_details, stage="assembly")
    if classes and "C4_%d" % classes in final:
        final["C4"] = final.pop("C4_%d" % classes)
    survivors = {name for name in selected if name in final and _family(name) not in failed}
    selected = {k: v for k, v in selected.items() if k in survivors}
    final = {k: v for k, v in final.items() if k in survivors}
    if "C1" not in survivors:
        raise RuntimeError("C1 unavailable after atomic UNHCR family filtering")
    if "C4" not in survivors:
        classes = None
    for name, seconds in final_times.items():
        times[name] = times.get(name, 0.0) + seconds
    _checkpoint(budget)
    with threadpool_limits(limits=8):
        t = perf_counter()
        stack = legacy.fit_stack(selected, data, meta, base_config, selection=weight_positions)
        times["meta_weights"] = perf_counter() - t
        _checkpoint(budget)
        t = perf_counter()
        if len(calibration_positions) >= MIN_CALIBRATION_ROWS:
            temperature, marginal_weight = legacy.fit_calibration(
                stack, selected["C1"], data, meta, base_config, selection=calibration_positions)
            calibration_status = "fitted_on_disjoint_meta_respondents"
        else:
            temperature, marginal_weight = 1.0, 0.0
            calibration_status = "identity: fewer than 8 calibration respondents"
        times["meta_calibration"] = perf_counter() - t
        _checkpoint(budget)
        prediction = legacy.apply_stack(final, stack, temperature, marginal_weight, base_config)
    _checkpoint(budget)
    t = perf_counter()
    output, remap_details = _render(frame, schema, complete, query, data, prediction, base_config)
    times["wave_remap"] = perf_counter() - t
    diagnostics = {
        "route": "respondent_meta_split",
        "config": asdict(config),
        "failed_families": sorted(failed),
        "split": {"base_training_rows": train.tolist(), "meta_rows": meta.tolist(),
                  "weight_rows": meta[weight_positions].tolist(),
                  "calibration_rows": meta[calibration_positions].tolist(),
                  "query_rows": query.tolist()},
        "classes": classes,
        "class_meta_fit_nll": class_losses,
        "candidate_names": stack["names"],
        "instrument_weights": stack["instrument"].tolist(),
        "item_weights": {name: weights.tolist() for name, weights in stack["weights"].items()},
        "mean_item_weights": np.mean(list(stack["weights"].values()), axis=0).tolist(),
        "temperature": temperature,
        "marginal_weight": marginal_weight,
        "calibration_status": calibration_status,
        "minimum_calibration_rows": MIN_CALIBRATION_ROWS,
        "component_seconds": times,
        "meta": meta_details,
        "final": final_details,
        "wave_remap": remap_details,
        "seconds": perf_counter() - started,
    }
    return output, diagnostics


def _recover_completed(frame, schema, state, error, budget):
    if state.get("stage") == "final":
        state["final"] = getattr(error, "partial_bank", {})
        state["final_times"] = getattr(error, "partial_times", {})
        state["final_details"] = getattr(error, "partial_details", {})
    if not state.get("selected") or not state.get("final"):
        raise error
    selected = dict(state["selected"])
    final = dict(state["final"])
    classes = state.get("classes")
    if classes and "C4_%d" % classes in final:
        final["C4"] = final.pop("C4_%d" % classes)
    survivors = {name for name in selected if name in final
                 and _family(name) not in state["failed"]}
    if "C1" not in survivors or not (survivors - {"C1"}):
        raise error
    selected = {name: value for name, value in selected.items() if name in survivors}
    final = {name: value for name, value in final.items() if name in survivors}
    budget.begin_finalization()
    _checkpoint(budget)
    data, meta, base_config = state["data"], state["meta"], state["base_config"]
    with threadpool_limits(limits=8):
        stack = legacy.fit_stack(selected, data, meta, base_config,
                                 selection=state["weight_positions"])
        _checkpoint(budget)
        if len(state["calibration_positions"]) >= MIN_CALIBRATION_ROWS:
            temperature, marginal_weight = legacy.fit_calibration(
                stack, selected["C1"], data, meta, base_config,
                selection=state["calibration_positions"])
            status = "fitted_on_disjoint_meta_respondents"
        else:
            temperature, marginal_weight = 1.0, 0.0
            status = "identity: fewer than 8 calibration respondents"
        _checkpoint(budget)
        prediction = legacy.apply_stack(final, stack, temperature, marginal_weight, base_config)
    _checkpoint(budget)
    output, remap = _render(frame, schema, state["complete"], state["query"],
                            data, prediction, base_config)
    _checkpoint(budget)
    return output, {
        "route": "respondent_meta_split_completed_members",
        "deadline_recovered": True, "deadline_stage": state["stage"],
        "candidate_names": stack["names"], "failed_families": sorted(state["failed"]),
        "classes": classes if "C4" in survivors else None,
        "instrument_weights": stack["instrument"].tolist(),
        "item_weights": {item: weights.tolist() for item, weights in stack["weights"].items()},
        "temperature": temperature, "marginal_weight": marginal_weight,
        "calibration_status": status,
        "meta": state.get("meta_details", {}), "final": state.get("final_details", {}),
        "component_seconds": {
            name: state.get("times", {}).get(name, 0.0) + state.get("final_times", {}).get(name, 0.0)
            for name in set(state.get("times", {})) | set(state.get("final_times", {}))},
        "wave_remap": remap, "seconds": perf_counter() - state["started"]}


def predict_with_diagnostics(frame, schema, config=None, budget=None):
    from budget import CandidateBudgetExceeded
    state = {}
    try:
        return _predict_with_diagnostics_impl(frame, schema, config, budget, state)
    except CandidateBudgetExceeded as error:
        if budget is None:
            raise
        return _recover_completed(frame, schema, state, error, budget)


def predict(frame, schema):
    return predict_with_diagnostics(frame, schema)[0]
