from time import perf_counter

import numpy as np
from scipy.optimize import minimize
from scipy.sparse import csr_matrix, hstack
from scipy.special import expit, logsumexp

import gfic_legacy as gfic
import legacy
import wb_ordinal_given


NAME = "WB_RESPONSE"
MAX_ITER = 100
STATE_L2 = (0.001, 0.01, 0.04)
CONTENT_L2 = 0.002
PRIOR = 0.5


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


def _family(item):
    if item.startswith("sc_"):
        return "sc"
    if item.startswith("tr_"):
        return "tr"
    if item.startswith("user."):
        return "user"
    return "other"


def _design(data, train, query):
    rows = np.concatenate((train, query))
    columns, offset = [], 0
    for name in data.given:
        card = len(data.options[name]) + 1
        values = np.asarray(data.codes[name][rows], dtype=np.int64)
        values = np.where((values >= 0) & (values < card - 1), values, card - 1)
        columns.append(values + offset)
        offset += card
    if not columns:
        return csr_matrix((len(train), 0)), csr_matrix((len(query), 0))
    indices = np.column_stack(columns)
    indptr = np.arange(0, indices.size + 1, len(columns), dtype=np.int64)
    matrix = csr_matrix((np.ones(indices.size), indices.ravel(), indptr),
                        shape=(len(rows), offset))
    counts = np.asarray(matrix[:len(train)].sum(axis=0)).ravel()
    selected = (counts > 0) & (counts < len(train))
    matrix = matrix[:, selected]
    numeric = wb_ordinal_given.for_data(data)
    if numeric is not None:
        active = np.ptp(numeric[train], axis=0) > 0 if len(train) else np.zeros(numeric.shape[1], bool)
        matrix = hstack((matrix, csr_matrix(numeric[rows][:, active])), format="csr")
    return matrix[:len(train)], matrix[len(train):]


def _minimize(objective, initial, budget, max_iter=MAX_ITER):
    result = minimize(objective, initial.ravel(), method="L-BFGS-B", jac=True,
                      callback=lambda _: _checkpoint(budget),
                      options={"maxiter": int(max_iter), "maxls": 25,
                               "ftol": 1e-8, "gtol": 2e-5})
    _checkpoint(budget)
    if not np.isfinite(result.x).all() or not np.isfinite(result.fun):
        raise FloatingPointError("Nonfinite WB_RESPONSE fit")
    return result, {"converged": bool(result.success),
                    "iterations": int(result.nit),
                    "evaluations": int(result.nfev),
                    "optimizer_status": int(result.status)}


def _fit_state(x, xq, labels, families, substantive_cards, budget, max_iter=MAX_ITER):
    n, features = x.shape
    items = labels.shape[1]
    if not items:
        return np.empty((xq.shape[0], 0)), {"items": 0}
    valid = labels >= 0
    target = np.where(valid, labels, 0).astype(float)
    counts = valid.sum(axis=0)
    answered_prior = PRIOR * np.asarray(substantive_cards, dtype=float)
    prior = (target.sum(axis=0) + PRIOR) / (counts + PRIOR + answered_prior)
    family_names = list(dict.fromkeys(families))
    family_ids = np.array([family_names.index(f) for f in families], dtype=int)
    n_families = len(family_names)
    parameter_heads = 1 + n_families + items
    sharing_scale = np.r_[1.0 / np.sqrt(items),
                          1.0 / np.sqrt(np.bincount(family_ids)),
                          np.ones(items)]
    initial_weights = np.zeros((features, parameter_heads))
    initial_bias = np.log(prior) - np.log1p(-prior)
    initial = np.r_[initial_weights.ravel(), initial_bias]
    penalties = np.r_[STATE_L2[0], np.full(n_families, STATE_L2[1]),
                      np.full(items, STATE_L2[2])] * sharing_scale ** 2
    transpose = x.T.tocsr()
    scale = float(max(1, n))

    def unpack(flat):
        weights = flat[:features * parameter_heads].reshape(features, parameter_heads)
        bias = flat[features * parameter_heads:]
        scaled = weights * sharing_scale[None, :]
        effective = (scaled[:, :1] + scaled[:, 1 + family_ids]
                     + scaled[:, 1 + n_families:])
        return weights, bias, effective

    def objective(flat):
        _checkpoint(budget)
        weights, bias, effective = unpack(flat)
        logits = x @ effective + bias
        loss = np.sum((np.logaddexp(0.0, logits) - target * logits) * valid) / scale
        loss += np.sum(answered_prior * np.logaddexp(0.0, bias)
                       + PRIOR * np.logaddexp(0.0, -bias)) / scale
        loss += 0.5 * np.sum(penalties[None, :] * weights ** 2)
        residual = (expit(logits) - target) * valid / scale
        effective_gradient = np.asarray(transpose @ residual)
        gradient = np.zeros_like(weights)
        gradient[:, 0] = effective_gradient.sum(axis=1)
        for family in range(n_families):
            gradient[:, 1 + family] = effective_gradient[:, family_ids == family].sum(axis=1)
        gradient[:, 1 + n_families:] = effective_gradient
        gradient *= sharing_scale[None, :]
        gradient += penalties[None, :] * weights
        bias_gradient = residual.sum(axis=0) + ((PRIOR + answered_prior) * expit(bias) - PRIOR) / scale
        return float(loss), np.r_[gradient.ravel(), bias_gradient]

    result, diagnostics = _minimize(objective, initial, budget, max_iter)
    _, bias, effective = unpack(result.x)
    probability = expit(xq @ effective + bias)
    probability[:, counts == 0] = prior[counts == 0]
    diagnostics.update({"items": items, "families": family_names,
                        "valid_cells": int(valid.sum()),
                        "l2_global_family_item": list(STATE_L2)})
    return probability, diagnostics


def _fit_content(x, xq, labels, cards, budget, max_iter=MAX_ITER):
    n, features = x.shape
    priors, result_probabilities, active = [], [], []
    for j, width in enumerate(cards):
        valid = labels[:, j] >= 0
        counts = np.bincount(labels[valid, j], minlength=width).astype(float)
        prior = (counts + PRIOR) / (counts.sum() + width * PRIOR)
        priors.append(prior)
        result_probabilities.append(np.tile(prior, (xq.shape[0], 1)))
        if width > 1 and valid.sum() >= 20 and np.count_nonzero(counts) >= 2:
            active.append(j)
    if not active or features == 0:
        return result_probabilities, {"active_heads": 0, "fallback": "content_marginals"}
    active_cards = np.asarray([cards[j] for j in active])
    active_labels = labels[:, active]
    offsets = np.r_[0, np.cumsum(active_cards)]
    width = int(offsets[-1])
    initial = np.zeros((features + 1, width))
    initial[-1] = np.concatenate([np.log(priors[j]) for j in active])
    groups = []
    for card in sorted(set(active_cards)):
        heads = np.flatnonzero(active_cards == card)
        columns = np.concatenate([np.arange(offsets[j], offsets[j + 1]) for j in heads])
        truth = active_labels[:, heads]
        valid = truth >= 0
        selected_rows, selected_heads = np.nonzero(valid)
        groups.append((heads, columns, int(card), valid,
                       selected_rows, selected_heads, truth[valid]))
    transpose = x.T.tocsr()
    scale = float(max(1, n))

    def objective(flat):
        _checkpoint(budget)
        weights = flat.reshape(features + 1, width)
        logits = x @ weights[:-1] + weights[-1]
        residual = np.zeros_like(logits)
        loss, bias_prior_gradient = 0.0, np.zeros(width)
        for heads, columns, card, valid, rr, hh, truth in groups:
            _checkpoint(budget)
            block = logits[:, columns].reshape(n, len(heads), card)
            normalizer = logsumexp(block, axis=2)
            loss += np.sum(normalizer[rr, hh] - block[rr, hh, truth]) / scale
            error = np.exp(block - normalizer[:, :, None]) * valid[:, :, None]
            error[rr, hh, truth] -= 1.0
            residual[:, columns] = error.reshape(n, -1) / scale
            bias = weights[-1, columns].reshape(len(heads), card)
            bias_norm = logsumexp(bias, axis=1)
            loss += PRIOR * np.sum(card * bias_norm - bias.sum(axis=1)) / scale
            bias_prior_gradient[columns] = (PRIOR * (card * np.exp(bias - bias_norm[:, None]) - 1)
                                             / scale).ravel()
        loss += 0.5 * CONTENT_L2 * np.sum(weights[:-1] ** 2)
        gradient = np.empty_like(weights)
        gradient[:-1] = np.asarray(transpose @ residual) + CONTENT_L2 * weights[:-1]
        gradient[-1] = residual.sum(axis=0) + bias_prior_gradient
        return float(loss), gradient.ravel()

    result, diagnostics = _minimize(objective, initial, budget, max_iter)
    weights = result.x.reshape(features + 1, width)
    logits = xq @ weights[:-1] + weights[-1]
    for head, item in enumerate(active):
        block = logits[:, offsets[head]:offsets[head + 1]]
        result_probabilities[item] = np.exp(block - logsumexp(block, axis=1)[:, None])
    diagnostics.update({"active_heads": len(active), "packed_width": width,
                        "l2": CONTENT_L2})
    return result_probabilities, diagnostics


def candidate(data, train, query, budget=None, max_iter=MAX_ITER):
    started = perf_counter()
    _checkpoint(budget)
    train = np.asarray(train, dtype=np.int64)
    query = np.asarray(query, dtype=np.int64)
    if train.ndim != 1 or query.ndim != 1 or np.intersect1d(train, query).size:
        raise ValueError("WB_RESPONSE requires disjoint one-dimensional TRAIN and QUERY")
    if len(np.unique(train)) != len(train) or len(np.unique(query)) != len(query):
        raise ValueError("WB_RESPONSE row indices must be unique")
    if not len(train) or not len(query):
        values = {item: np.full((len(query), width), 1.0 / width)
                  for item, width in zip(data.targets, data.ycards)}
        return legacy.Candidate(NAME, values), {"fallback": "empty_train_or_query"}

    labels = np.asarray(data.y[train], dtype=np.int64).copy()
    if labels.shape != (len(train), len(data.targets)):
        raise ValueError("WB_RESPONSE target shape differs from schema")
    for j, width in enumerate(data.ycards):
        if np.any(labels[:, j] < -1) or np.any(labels[:, j] >= width):
            raise ValueError("WB_RESPONSE TRAIN label outside schema")
    x, xq = _design(data, train, query)
    laws = gfic.gate_laws(data, train, gfic.Config(gate_factor=True))
    content_labels, content_cards = labels.copy(), list(data.ycards)
    state_columns, state_labels, families, nonresponse_indices = [], [], [], {}
    for j, item in enumerate(data.targets):
        law = laws.get(item)
        if law:
            content_labels[content_labels[:, j] == law["sentinel"], j] = -1
            content_cards[j] = law["sentinel"]
        options = data.options[item][:content_cards[j]]
        nonresponse = [k for k, option in enumerate(options)
                       if str(option).strip().casefold() == "not answered"]
        hidden_gate = bool(data.schema["items"][item].get("gate") and law is None)
        if len(nonresponse) != 1 or content_cards[j] < 2 or hidden_gate:
            continue
        index = nonresponse[0]
        original = content_labels[:, j].copy()
        state = np.where(original >= 0, (original == index).astype(int), -1)
        content_labels[original == index, j] = -1
        content_labels[original > index, j] -= 1
        content_cards[j] -= 1
        state_columns.append(j)
        state_labels.append(state)
        families.append(_family(item))
        nonresponse_indices[j] = index

    _checkpoint(budget)
    state_matrix = np.column_stack(state_labels) if state_labels else np.empty((len(train), 0), int)
    missing, state_detail = _fit_state(x, xq, state_matrix, families,
                                       [content_cards[j] for j in state_columns], budget, max_iter)
    content, content_detail = _fit_content(x, xq, content_labels, content_cards, budget, max_iter)
    state_lookup = {column: j for j, column in enumerate(state_columns)}
    values = {}
    for j, item in enumerate(data.targets):
        _checkpoint(budget)
        probability = content[j]
        if j in nonresponse_indices:
            index = nonresponse_indices[j]
            mass = missing[:, state_lookup[j]]
            full = np.empty((len(query), probability.shape[1] + 1))
            full[:, :index] = probability[:, :index] * (1 - mass[:, None])
            full[:, index] = mass
            full[:, index + 1:] = probability[:, index:] * (1 - mass[:, None])
            probability = full
        if item in laws:
            probability = gfic.compose_gate(probability, laws[item], query)
        if probability.shape != (len(query), data.ycards[j]) or not np.isfinite(probability).all():
            raise FloatingPointError("WB_RESPONSE output shape or finiteness error")
        values[item] = legacy.normalize(probability)
    return legacy.Candidate(NAME, values), {
        "model": "hierarchical_nonresponse_and_vectorized_content",
        "train_rows": len(train), "query_rows": len(query),
        "given": list(data.given), "design_width": int(x.shape[1]),
        "state_items": [data.targets[j] for j in state_columns],
        "gate_items": list(laws), "state": state_detail, "content": content_detail,
        "max_iter": int(max_iter), "prior_per_class": PRIOR,
        "seconds": perf_counter() - started,
    }
