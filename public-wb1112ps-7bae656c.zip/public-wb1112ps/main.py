from time import perf_counter
_IMPORTED_AT = perf_counter()
import math
import os
try:
    import config as _cpu_config
    _THREADS = _cpu_config.THREADS
    _CPU_LIMITS = dict(_cpu_config.CPU_LIMITS)
except Exception as _error:
    try:
        _THREADS = max(1, min(8, len(os.sched_getaffinity(0))))
    except Exception:
        _THREADS = max(1, min(8, os.cpu_count() or 8))
    _CPU_LIMITS = {'threads': _THREADS, 'error': type(_error).__name__}
for _thread_variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_thread_variable] = str(_THREADS)
from dataclasses import asdict, replace
from contextlib import nullcontext

_IMPORT_ERRORS = {}
for _name in ('config', 'budget', 'numpy', 'threadpoolctl', 'torch',
              'cascade', 'latent', 'ridge', 'ordinal', 'joint_forest',
              'reduced_rank', 'legacy', 'structure', 'conditional_mlp',
              'neural', 'gfic_legacy', 'kdb_runtime', 'kdb',
              'wb_calibration', 'wb_interactions', 'wb_h2_bct', 'wb_tabicl',
              'wb_response', 'wb_transitions', 'wb_sector', 'wb_ordinal_sc', 'wb_factorized_pool', 'wb_meta',
              'nonerpis', 'reference_v2'):
    try:
        globals()[_name] = __import__(_name)
    except Exception as _error:
        _IMPORT_ERRORS[_name] = type(_error).__name__
if 'threadpoolctl' in globals():
    try:
        threadpoolctl.threadpool_info()
    except Exception as _error:
        _IMPORT_ERRORS['threadpool_preinit'] = type(_error).__name__
if 'torch' in globals():
    try:
        torch.set_num_threads(_THREADS)
        torch.set_num_interop_threads(_THREADS)
    except Exception as _error:
        _IMPORT_ERRORS['torch_threads'] = type(_error).__name__
if 'config' in globals():
    Config = config.Config
_COMPLETED_INSTRUMENTS = set()
VARIANT = 'wb-focus-1018'
STRICT = True
_STRICT_IMPORT_FAILURE = any(_name not in ('wb_tabicl', 'threadpool_preinit', 'torch_threads')
                             for _name in _IMPORT_ERRORS)
STRICT_IMPORT_MESSAGE = 'strict: a required module failed to import'
STRICT_ROUTE_MESSAGE = 'strict: World Bank route unavailable'
CUDA_AVAILABLE = str(getattr(globals().get('wb_tabicl'), '_DEVICE', 'cpu')).startswith('cuda')


def reset_runtime():
    global _IMPORTED_AT
    _IMPORTED_AT = perf_counter()
    _COMPLETED_INSTRUMENTS.clear()


def instrument_name(schema):
    keys = set(schema.get('items', {}))
    signatures = {
        'world_bank': {'group', 'user.age', 'user.educationLevel', 'user.hadJob'},
        'unicef': {'Country', 'Q01', 'Q13'},
        'unhcr': {'wave', 's3_11_intent_return_12m_lbl', 's1_2_country_asylum_lbl'},
    }
    return next((name for name, signature in signatures.items() if signature <= keys), 'generic')


def _layout(frame, schema):
    targets = [n for n,r in schema['items'].items() if r.get('class') == 'PREDICT']
    blank = frame[targets].isna().to_numpy()
    hidden = [i for i,row in enumerate(blank) if all(row)] if targets else []
    cells = [(i, n) for i in hidden for n in targets]
    options = {n: list(schema['items'][n]['values']) +
               ([schema.get('gated_value','NA_GATED')] if schema['items'][n].get('gate') else [])
               for n in targets}
    return targets, blank, hidden, cells, options


def detect_phase(schema, n_hidden):
    split = schema.get('split', {})
    n_rows = schema.get('dataset', {}).get('n_rows', schema.get('n_rows', 0))
    candidates = {}
    for phase, role in ((1,'dev'),(2,'test')):
        value = next((split[k] for k in ('n_'+role, role, role.upper()) if k in split), None)
        if value is None:
            continue
        value = float(value)
        if 0 < value < 1:
            if not n_rows:
                continue
            value *= float(n_rows)
        candidates[phase] = abs(float(n_hidden) - value)
    if len(candidates) == 2:
        return min(candidates, key=candidates.get), 'hidden_count_nearest_split'
    nearest = min(candidates.values(), default=float('inf'))
    matches = [phase for phase, delta in candidates.items() if delta <= 1.0 and delta == nearest]
    return (matches[0], 'hidden_count_matches_split') if len(matches)==1 else (1, 'ambiguous_or_custom_schema_safe_900s')


def _c1(frame, schema, layout):
    targets, blank, hidden, cells, options = layout
    complete = [i for i,row in enumerate(blank) if not any(row)]
    priors = {}
    for j,n in enumerate(targets):
        opts=options[n]; counts={value:0 for value in opts}
        column=frame[n].to_numpy()
        for i in complete:
            value=column[i]
            if value in counts:
                counts[value]+=1
        den=sum(counts.values())+0.5*len(opts)
        priors[n]=[(counts[value]+0.5)/den for value in opts]
    return [list(priors[n]) for _,n in cells]


def _validate(vectors, layout):
    cells,options=layout[3],layout[4]
    if len(vectors)!=len(cells):
        raise ValueError('wrong vector count')
    result=[]
    for vector,(_,n) in zip(vectors,cells):
        if len(vector)!=len(options[n]):
            raise ValueError('wrong vector width')
        p=[float(x) for x in vector]
        if not all(math.isfinite(x) and x>=0 for x in p) or sum(p)<=0:
            raise ValueError('invalid probabilities')
        result.append(p)
    return result


def _reduced(frame, schema, emergency=None):
    cfg=legacy.Config(enabled=('C1','C2'))
    data=legacy.Data(frame,schema,cfg)
    train,query=legacy.complete_rows(frame,schema),legacy.hidden_rows(frame,schema)
    ranks={n:data.ranks(n,train) for n in data.targets}
    probabilities=legacy.hierarchy(data,train,query,ranks)
    candidate=legacy.Candidate('C1_C2',{
        n:0.5*probabilities[n]+0.5*data.marginal(n,train)[None,:]
        for n in data.targets})
    output,remap=reference_v2._render(frame,schema,train,query,data,candidate,cfg)
    return output, {'route':'reduced_C1_C2','candidate_names':['C1','C2'],'wave_remap':remap}


def predict_with_diagnostics(frame, schema, config=None):
    started=perf_counter()
    layout=_layout(frame,schema)
    fallback=_validate(_c1(frame,schema,layout),layout)
    instrument=instrument_name(schema)
    phase,phase_reason=detect_phase(schema,len(layout[2]))
    strict=STRICT and phase==2 and instrument!='generic'
    if strict and _STRICT_IMPORT_FAILURE:
        raise RuntimeError(STRICT_IMPORT_MESSAGE)
    events=[]
    diagnostic={'variant':VARIANT,'instrument':instrument,'phase':phase,
                'phase_detection':phase_reason,'import_errors':dict(_IMPORT_ERRORS),
                'hardware_cuda':CUDA_AVAILABLE,'threads':_THREADS,'cpu_limits':dict(_CPU_LIMITS),
                'fallback_events':events,
                'c1_seconds':perf_counter()-started}
    if instrument=='generic' or 'Config' not in globals() or 'budget' not in globals():
        return fallback,dict(diagnostic,route='C1',seconds=perf_counter()-started)
    flags=config or Config()
    flags=replace(flags, phase=phase)
    if phase==1 and flags.wb_factor_reserve_phase1_seconds>0:
        flags=replace(flags, wb_factor_reserve_seconds=flags.wb_factor_reserve_phase1_seconds)
    table=globals()['config'].COMPOSITION[phase]
    spec=table[instrument]
    enabled=flags.optional_families or spec['optional']
    resolved_base = flags.base_families or spec['base']
    if instrument == 'world_bank' and not flags.wb_prune_members and not flags.base_families:
        resolved_base = tuple(n for n in globals()['config'].BASE_FAMILIES if n != 'C5')
    flags=replace(flags,base_families=resolved_base,optional_families=enabled,
                  gfic=flags.gfic and 'GFIC' in enabled,kdb=flags.kdb and 'KDB_HLS1' in enabled,
                  linear_non_erpis=flags.linear_non_erpis and 'LinearFull' in enabled,
                  neural_non_erpis=flags.neural_non_erpis and 'NeuralShared' in enabled,
                  erp_gpu=False,tabicl=False,erp_astra=False,erp_ensemble=False)
    if instrument!='world_bank':
        flags=replace(flags,**{'r'+str(i):False for i in range(1,10)})
    total=900.0 if phase==1 else 3600.0
    if 0 < flags.budget_total < total:
        total=flags.budget_total
    emergency=budget.Budget(instrument,_IMPORTED_AT,total,_COMPLETED_INSTRUMENTS,
                            {k:v['quota'] for k,v in table.items()})
    if instrument == 'world_bank':
        emergency.reserve_finalization(flags.wb_finalize_reserve_seconds)
    try:
        pool=threadpoolctl.threadpool_limits(limits=_THREADS) if 'threadpoolctl' in globals() else nullcontext()
    except Exception as error:
        events.append({'stage':'threadpool','exception':type(error).__name__})
        pool=nullcontext()
    with pool:
        safety_output,safety_details=fallback,{'route':'C1'}
        try:
            safety_output,safety_details=_reduced(frame,schema)
            safety_output=_validate(safety_output,layout)
        except Exception as error:
            events.append({'stage':'prepare_C1_C2','exception':type(error).__name__})
        if instrument != 'world_bank':
            output,details=safety_output,dict(safety_details,reason='world_bank_focus')
        elif emergency.global_exhausted():
            output,details=safety_output,dict(safety_details,reason='global_85_percent_guard')
        else:
            try:
                emergency.checkpoint()
                if instrument=='unhcr':
                    rich=spec['route']=='a'
                    base=legacy.Config(enabled=spec['base'])
                    cfg=reference_v2.Config(base_config=base,enable_linear=rich,
                        enable_neural=rich,enable_structure=rich)
                    output,details=reference_v2.predict_with_diagnostics(frame,schema,cfg,budget=emergency)
                else:
                    output,details=nonerpis.run(frame,schema,flags,emergency)
                output=_validate(output,layout)
            except Exception as error:
                events.append({'stage':'route','exception':type(error).__name__})
                output,details=safety_output,safety_details
    if strict and instrument=='world_bank' and (
            details.get('reason')=='global_85_percent_guard' or any(e.get('stage')=='route' for e in events)):
        raise RuntimeError(STRICT_ROUTE_MESSAGE)
    _COMPLETED_INSTRUMENTS.add(instrument)
    diagnostic.update(details)
    diagnostic.update(flags=asdict(flags),emergency_budget=emergency.diagnostics(),
                      planned_composition=spec,seconds=perf_counter()-started)
    return output,diagnostic


def predict(frame,schema):
    return predict_with_diagnostics(frame,schema)[0]
