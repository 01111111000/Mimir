from types import SimpleNamespace
import numpy as np
from scipy.optimize import minimize
import legacy
import gfic_legacy as gfic


def conditional_prior(data, train, query, laws, fallback, strength=20.):
    result = {n: p.copy() for n, p in fallback.probabilities.items()}
    for item, law in laws.items():
        k = law['sentinel']; y = data.codes[item]
        valid = train[(y[train] >= 0) & (y[train] < k)]
        pooled = (np.bincount(y[valid], minlength=k) + .5)
        pooled /= pooled.sum()
        content = np.tile(pooled, (len(query), 1))
        for state in (False, True):
            rows = valid[law['known'][valid] & (law['open'][valid] == state)]
            counts = np.bincount(y[rows], minlength=k)
            p = (counts + strength * pooled) / (len(rows) + strength)
            selected = law['known'][query] & (law['open'][query] == state)
            content[selected] = p
        result[item] = gfic.compose_gate(content, law, query)
    return legacy.Candidate('C1_conditional', result)


def fit_pairs(mixed, priors, data, rows, config, common, item_enabled, gate_enabled, budget=None):
    pairs = {}
    for item in data.targets:
        if budget is not None:budget.checkpoint()
        gate = data.schema['items'][item].get('gate')
        factored = gate_enabled and gate and gate['parent'] in data.given
        if not item_enabled:
            pairs[item] = common
            continue
        y = data.codes[item][rows]; valid = y >= 0
        b = mixed[item][valid]; m = priors.probabilities[item][valid]; actual = y[valid]
        width = b.shape[1]
        if not len(actual):
            pairs[item] = common
            continue
        if factored:
            sentinel = m[:, -1].copy()
            b = legacy.normalize(b[:, :-1]); m = legacy.normalize(m[:, :-1])
        def objective(theta):
            p = gfic.calibrate(b, m, *theta)
            if factored:
                p = legacy.output_distribution(p, config.floor)
                p = np.column_stack([p * (1-sentinel[:, None]), sentinel])
            else:
                p = legacy.output_distribution(p, config.floor)
            q = config.metric_floor + (1-width*config.metric_floor)*p[np.arange(len(actual)), actual]
            return -float(np.log(q).mean())
        fit = minimize(objective, common, method='L-BFGS-B', bounds=((.4,3.),(0.,1.)), options={'maxiter':50,'ftol':1e-10})
        theta = fit.x if np.isfinite(fit.fun) else np.asarray(common)
        n = int(np.sum(actual != width - 1)) if factored else len(actual)
        theta = (n*theta + config.weight_k*np.asarray(common))/(n+config.weight_k)
        pairs[item] = tuple(map(float, theta))
    return pairs


def apply(candidates, stack, pairs, priors, laws, query, config):
    out = {}
    for item, weights in stack['weights'].items():
        parts = [(w,candidates[name].probabilities.get(item)) for w,name in zip(weights,stack['names'])]
        parts = [(w,p) for w,p in parts if p is not None]
        total = sum(w for w,p in parts)
        p = sum(w*p for w,p in parts)/total if total else candidates['C1'].probabilities[item]
        marginal = priors.probabilities[item]
        if item in laws:
            content = gfic.calibrate(legacy.normalize(p[:,:-1]), legacy.normalize(marginal[:,:-1]), *pairs[item])
            content = legacy.output_distribution(content, config.floor)
            out[item] = gfic.compose_gate(content, laws[item], query)
        else:
            p = gfic.calibrate(p, marginal, *pairs[item])
            out[item] = legacy.output_distribution(p, config.floor)
    return legacy.Candidate('C6',out)
