from dataclasses import replace
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

import legacy
import gfic_legacy as gfic
import kdb_runtime as kdb_model
try:
    import neural as neural_model
except Exception:
    neural_model = None
import config as route_config
import wb_meta
import wb_calibration
import wb_interactions
import wb_h2_bct
import wb_response
import wb_transitions
import wb_sector
import wb_ordinal_sc
import wb_ordinal_given
import wb_ideas_class_bias
try:
    import wb_ideas_tabm
except Exception:
    wb_ideas_tabm = None
import wb_ideas_arms
import wb_ideas_profiles
import wb_ideas_hgb
import wb_ideas_kdb
try:
    import wb_tabicl
except Exception:
    wb_tabicl = None
wb_kumo = None
if bool(getattr(route_config.Config(), 'wb_kumo', False)):
    try:
        import wb_kumo
    except Exception:
        wb_kumo = None
from scipy.optimize import minimize_scalar


GFIC_NAMES = ("GFIC_C4", "GFIC_C7", "GFIC_C8")
OPTIONAL_NAMES = GFIC_NAMES + ("KDB_HLS1", "LinearFull", "NeuralShared")


def _tabicl_cpu_allowance(allowance, budget, flags, *, phase, on_cuda, is_wb,
                          factor_reserve):
    if (budget is None or not is_wb or phase != 2 or on_cuda
            or not bool(getattr(flags, 'wb_cpu_phase2_time_guard', True))):
        return allowance, None
    imported_at = budget.global_deadline - 0.85 * budget.total
    target_deadline = imported_at + 0.65 * budget.total
    other_quotas = sum(float(quota) for name, quota in budget.quotas.items()
                       if name != 'world_bank')
    cpu_cap = max(0.0, target_deadline - perf_counter()
                  - budget.finalization_reserve - factor_reserve - other_quotas)
    capped = min(allowance, cpu_cap)
    return capped, {'reason': 'phase2_cpu_65_percent_guard',
                    'original_seconds': allowance, 'allocated_seconds': capped,
                    'cpu_cap_seconds': cpu_cap, 'target_fraction': 0.65,
                    'target_deadline': target_deadline,
                    'finalization_reserve_seconds': budget.finalization_reserve,
                    'factor_reserve_seconds': factor_reserve,
                    'other_instrument_quota_seconds': other_quotas}


def _masked_data(frame, schema, train, config):
    outside = np.ones(len(frame), dtype=bool)
    outside[train] = False
    masked = legacy.mask_respondents(frame, schema, np.flatnonzero(outside))
    return masked, legacy.Data(masked, schema, config)


def _contexts(complete, query, config, crossfit=True):
    plans, outer, inner = [], [], []
    for held in legacy.respondent_folds(complete, config.folds, config.seed):
        train = np.setdiff1d(complete, held)
        index = len(plans)
        plans.append({"train": train, "query": held, "kind": "outer"})
        outer.append(index)
        inner_indices = []
        for nested_held in ([] if crossfit else legacy.respondent_folds(train, config.folds, config.seed)):
            inner_indices.append(len(plans))
            plans.append({"train": np.setdiff1d(train, nested_held),
                          "query": nested_held, "kind": "inner"})
        inner.append(inner_indices)
    final = len(plans)
    plans.append({"train": complete, "query": query, "kind": "final"})
    return plans, outer, inner, final


def _collect(plans, indices, rows, schema):
    positions = {int(row): i for i, row in enumerate(rows)}
    targets = [name for name, item in schema["items"].items() if item["class"] == "PREDICT"]
    oof = {}
    for index in indices:
        context = plans[index]
        pos = np.array([positions[int(row)] for row in context["query"]])
        for name, candidate in context["bank"].items():
            if name not in oof:
                oof[name] = legacy.Candidate(name, {
                    item: None if candidate.probabilities[item] is None else
                    np.empty((len(rows), len(legacy.options_for(schema, item))))
                    for item in targets})
            for item in targets:
                if oof[name].probabilities[item] is not None:
                    oof[name].probabilities[item][pos] = candidate.probabilities[item]
    return oof


def _select(bank, data, rows, config):
    selected, count, losses = legacy.select_classes(bank, data, rows, config)
    choice = {"C4": "C4_%d" % count} if count is not None else {}
    gfic_losses = {}
    for name, candidate in bank.items():
        if name.startswith("GFIC_C4_"):
            p = legacy.true_probabilities(candidate, data, rows, config)
            gfic_losses[name] = -float(np.log(np.maximum(p, np.finfo(float).tiny)).mean()) if len(p) else 0.0
    selected = {name: candidate for name, candidate in selected.items()
                if not name.startswith("GFIC_C4_")}
    if gfic_losses:
        name = min(gfic_losses, key=gfic_losses.get)
        selected["GFIC_C4"] = legacy.Candidate("GFIC_C4", bank[name].probabilities)
        choice["GFIC_C4"] = name
    return selected, choice, dict(losses, **gfic_losses)


def _validate_bank(bank, data, query):
    for candidate in bank.values():
        for item, width in zip(data.targets, data.ycards):
            p = candidate.probabilities.get(item)
            if p is None:
                continue
            if (p.shape != (len(query), width) or not np.isfinite(p).all()
                    or (p < 0).any() or not np.allclose(p.sum(1), 1, rtol=0, atol=1e-9)):
                raise ValueError("Invalid optional candidate probability vector")


def _gate_content(data, train):
    config = gfic.Config(gate_factor=True, item_calibration=True)
    laws = gfic.gate_laws(data, train, config)
    y, cards = gfic.content_targets(data, laws, train)
    return laws, y, cards


def _compose(data, values, laws, query):
    values = list(values)
    for law in laws.values():
        values[law["column"]] = gfic.compose_gate(values[law["column"]], law, query)
    return dict(zip(data.targets, values))


def _gfic_bank(masked, data, train, query, flags, budget=None, reuse_bank=None, classes=None, failed=()):
    config = gfic.Config(gate_factor=True, item_calibration=bool(flags.item_calibration),
                         ordinal_given=bool(getattr(flags,"ordinal_given",False)),
                         enabled=tuple(n for n in (("C7",) if getattr(flags,"wb_prune_members",True) else ("C4", "C7", "C8")) if n not in failed))
    repair_fields = {name: bool(getattr(flags, name, False)) for name in ("r3","r4","r5","r6","r7","r8")
                     if name in config.__dataclass_fields__}
    config = replace(config, **repair_fields)
    bank, times, details = gfic.fit_candidates(masked, data.schema, train, query, config,
                                               classes=classes, reuse_bank=reuse_bank)
    result = {}
    laws = gfic.gate_laws(data, train, config)
    for name, candidate in bank.items():
        if name.startswith("C4_"):
            key = "GFIC_C4"
        elif name in ("C7", "C8"):
            key = name
            if reuse_bank and name in reuse_bank:
                candidate.probabilities = {item: candidate.probabilities[item] if item in laws
                                          else reuse_bank[name].probabilities[item] for item in data.targets}
        else:
            continue
        result[key] = legacy.Candidate(key, candidate.probabilities)
    return result, {"component_seconds": times, **details}


def _iteration_caps(flags):
    return (bool(getattr(flags, 'wb_iteration_caps', False))
            and int(getattr(flags, 'phase', 0) or 0) in route_config.WB_ITERATION_CAP_PHASES)


def _kdb_bank(masked, data, train, query, flags, budget=None):
    laws, targets, cards = _gate_content(data, train)
    max_iter = route_config.WB_ITERATION_CAPS['KDB_HLS1'] if _iteration_caps(flags) else 60
    values, details = [], []
    for column, width in enumerate(cards):
        if budget is not None and hasattr(budget, "checkpoint"):
            budget.checkpoint()
        with threadpool_limits(limits=getattr(flags, "wb_blas_threads", 1), user_api="blas"):
            p, detail = kdb_model.predict_kdb(data.x, data.xcards, targets[:, column], width,
                                    train, query, k=1, smoothing="hls", parent_main=bool(getattr(flags,"r9",False)),
                                    max_iter=max_iter)
        values.append(p)
        details.append(detail)
    return {"KDB_HLS1": legacy.Candidate("KDB_HLS1", _compose(data, values, laws, query))}, {
        "k": 1, "ridge": 1.0, "max_iter": max_iter, "prior": 0.5,
        "gate_items": list(laws), "items": details}


def _neural_bank(masked, data, train, query, flags, budget=None, linear=False, ensemble=False, reuse_bank=None):
    if neural_model is None:
        raise ImportError("Neural family unavailable")
    laws, targets, cards = _gate_content(data, train)
    config = neural_model.NeuralConfig(seed=13, threads=min(int(getattr(flags,"wb_torch_threads",8)),route_config.THREADS), device="cpu",
                                       regularization_scaled=bool(getattr(flags,"r5",False)),
                                       max_seconds=float(getattr(flags,"wb_neural_fit_seconds",0.0)))
    if linear:
        config = replace(config, hidden=())
    runner = neural_model.predict_neural_bagged if ensemble else neural_model.predict_neural
    extra = {}
    if ensemble:
        extra["ensemble_size"] = int(getattr(flags,"wb_neural_seeds",3))
    if getattr(flags,"ordinal_given",False):
        extra["numeric_features"] = wb_ordinal_given.for_data(data)
    if ensemble and reuse_bank and 'NeuralShared' in reuse_bank:
        extra['cached_first'] = getattr(reuse_bank['NeuralShared'], '_content_values', None)
    values, details = runner(data.x, data.xcards, targets, cards,
                                     train, query, config, budget=budget, **extra)
    name = "WB_NEURAL_ENSEMBLE" if ensemble else ("LinearFull" if linear else "NeuralShared")
    member = legacy.Candidate(name, _compose(data, values, laws, query))
    if name == 'NeuralShared':
        member._content_values = values
    return {name: member}, {
        **details, "gate_items": list(laws)}


def _add_atomic(name, runner, plans, frame, schema, flags, budget, config):
    pending, records = [], []
    started = perf_counter()
    try:
        for index, plan in enumerate(plans):
            if budget is not None:
                budget.checkpoint()
            masked, data = _masked_data(frame, schema, plan["train"], config)
            t = perf_counter()
            with threadpool_limits(limits=route_config.THREADS):
                bank, details = runner(masked, data, plan["train"], plan["query"], flags, budget, plan)
            _validate_bank(bank, data, plan["query"])
            records.append({"fit": index, "kind": plan["kind"], "seconds": perf_counter()-t,
                            "train_rows": len(plan["train"]), "query_rows": len(plan["query"]), "details": details})
            pending.append(bank)
    except Exception as error:
        if isinstance(error, TimeoutError) or type(error).__name__ == "CandidateBudgetExceeded":
            raise
        return False, {"status": "failed_atomically", "exception": type(error).__name__,
                       "message": str(error), "seconds": perf_counter()-started,
                       "completed_fits": len(pending), "fits": records}
    for plan, bank in zip(plans, pending):
        plan["bank"].update(bank)
    return True, {"status": "accepted", "seconds": perf_counter()-started, "fits": records}


def waterfill(p, metric_floor, output_floor):
    p = np.asarray(p, dtype=float)
    p = p / p.sum(axis=1, keepdims=True)
    n, width = p.shape
    ratio = metric_floor / (1.0 - width * metric_floor)
    order = np.argsort(-p, axis=1)
    sorted_p = np.take_along_axis(p, order, axis=1)
    lam = np.cumsum(sorted_p, axis=1) / (1.0 + np.arange(1, width + 1)[None, :] * ratio)
    m = np.maximum((sorted_p > lam * ratio).sum(axis=1), 1)
    chosen = lam[np.arange(n), m - 1]
    q = np.maximum(p / chosen[:, None] - ratio, 0.0)
    q = np.maximum(q / q.sum(axis=1, keepdims=True), output_floor)
    return q / q.sum(axis=1, keepdims=True)


def _render(frame, schema, complete, query, data, prediction, config, waterfilled=False):
    remapped, details = legacy.detect_wave_zero_items(frame, schema, complete)
    wave1 = (frame.iloc[query]["wave"].eq("1").fillna(False).to_numpy(dtype=bool)
             if remapped else np.zeros(len(query), dtype=bool))
    filled = {}
    if waterfilled:
        for item in data.targets:
            block = prediction.probabilities.get(item)
            if block is not None and block.shape == (len(query), len(data.options[item])):
                filled[item] = waterfill(block, config.metric_floor, config.floor)
        details = dict(details, waterfill_items=len(filled))
    output = []
    for row in range(len(query)):
        for item in data.targets:
            p = filled[item][row] if item in filled else prediction.predict(row, item)
            if wave1[row] and item in remapped:
                p = legacy.remap_wave_zero_vector(p, remapped[item], config.floor)
            output.append(p.tolist())
    return output, details


def _subset(bank, positions):
    return {name: legacy.Candidate(name, {item: None if p is None else p[positions]
            for item,p in candidate.probabilities.items()}) for name,candidate in bank.items()}


def _temper_kdb(plans, outer, final, complete, data, config, budget=None):
    oof = _collect(plans,outer,complete,data.schema)['KDB_HLS1']
    lookup = {int(row):i for i,row in enumerate(complete)}
    details=[]
    pending=[]
    for index in range(len(plans)):
        plan=plans[index]
        keep=np.isin(complete,plan['train'])
        pair={}
        for item in data.targets:
            if budget is not None:budget.checkpoint()
            p=oof.probabilities[item][keep]; y=data.codes[item][complete[keep]]; valid=y>=0
            logp=np.log(np.maximum(p[valid],1e-300)); y=y[valid]
            def objective(t):
                q=np.exp(logp/t-(logp/t).max(1,keepdims=True));q/=q.sum(1,keepdims=True)
                score=config.metric_floor+(1-p.shape[1]*config.metric_floor)*q[np.arange(len(y)),y]
                return -float(np.log(score).mean()) if len(y) else 0.
            t=float(minimize_scalar(objective,bounds=(.4,3.),method='bounded').x) if len(y) else 1.
            t=(len(y)*t+config.weight_k)/(len(y)+config.weight_k)
            q=plan['bank']['KDB_HLS1'].probabilities[item]
            pending.append((plan,item,gfic.calibrate(q,q,t,0.)))
            pair[item]=t
        details.append({'plan':index,'temperatures':pair,'training_rows':int(keep.sum())})
    for plan,item,value in pending:
        plan['bank']['KDB_HLS1'].probabilities[item]=value
    return details


def _propagate_parent_gates(prediction, schema):
    items, changed = schema['items'], []
    for name, record in items.items():
        gate = record.get('gate')
        if (record.get('class') != 'PREDICT' or not gate
                or items.get(gate.get('parent'), {}).get('class') != 'PREDICT'):
            continue
        parent = gate['parent']
        options = list(items[parent]['values']) + ([schema.get('gated_value', 'NA_GATED')]
                                                   if items[parent].get('gate') else [])
        open_mass = sum(prediction.probabilities[parent][:, options.index(v)]
                        for v in gate.get('observed_if', []) if v in options)
        child = prediction.probabilities[name]
        content = child[:, :-1] / np.maximum(child[:, :-1].sum(1, keepdims=True), 1e-300)
        closed = np.clip(1.0 - open_mass, 0.0, 1.0)[:, None]
        prediction.probabilities[name] = np.concatenate([(1.0 - closed) * content, closed], axis=1)
        changed.append(name)
    return changed


def _idea_bank(result):
    candidate, details = result
    return {candidate.name: candidate}, details


def _single_bank(module,data,train,query,budget,**kwargs):
    candidate,details=module.candidate(data,train,query,budget,**kwargs)
    return {candidate.name:candidate},details


def _recover(frame,schema,state,budget):
    if budget is not None:
        budget.begin_finalization()
    plans=state.get('plans',[])
    if not plans or any(not p.get('bank') for p in plans):
        from budget import CandidateBudgetExceeded
        raise CandidateBudgetExceeded('No complete cross-fitted bank; use prepared C1+C2')
    common=set.intersection(*(set(p['bank']) for p in plans))
    if not {'C1','C2'} <= common:
        from budget import CandidateBudgetExceeded
        raise CandidateBudgetExceeded('Incomplete reference families; use prepared C1+C2')
    for plan in plans:
        plan['bank']={n:c for n,c in plan['bank'].items() if n in common}
    data,complete,query,base=(state[k] for k in ('data','complete','query','base'))
    oof=_collect(plans,state['outer'],complete,schema)
    selected,count,_=legacy.select_classes(oof,data,complete,base)
    final=dict(plans[state['final']]['bank'])
    if count is not None:
        final['C4']=final['C4_%d'%count]
    cfg=replace(base,enabled=tuple(n for n in selected if n != 'C1'))
    stack=legacy.fit_stack(selected,data,complete,cfg)
    if budget is not None:budget.checkpoint()
    prediction=legacy.apply_stack(final,stack,1.0,0.0,cfg)
    output,remap=_render(frame,schema,complete,query,data,prediction,cfg)
    return output,{'route':'completed_members_stack','candidate_names':stack['names'],
        'instrument_weights':stack['instrument'].tolist(),'wave_remap':remap,
        'calibration_status':'identity_after_deadline',
        'optional':state.get('optional',{}),'component_seconds':state.get('component_seconds',{})}


def build_bank(frame, schema, flags, budget=None):
    capture = {"bank_only": True}
    return _run(frame, schema, flags, budget=budget, cache=capture, state={})


def run(frame,schema,flags,budget=None,cache=None):
    state={}
    try:
        return _run(frame,schema,flags,budget,cache,state)
    except Exception as error:
        if type(error).__name__!='CandidateBudgetExceeded':
            raise
        return _recover(frame,schema,state,budget)


def _run(frame, schema, flags, budget=None, cache=None, state=None):
    started=perf_counter()
    base=legacy.Config()
    repairs={name: bool(getattr(flags,name,False)) for name in ('r3','r4','r5','r6','r7','r8')
             if name in base.__dataclass_fields__}
    configured_base = getattr(flags, 'base_families', ()) or (
        route_config.WB_BASE_FAMILIES if getattr(flags, 'wb_prune_members', True) else base.enabled)
    if getattr(flags, 'wb_prune_members', True):
        configured_base = tuple(n for n in configured_base if n not in ('C1', 'C4', 'C5', 'C8', 'GFIC_C4'))
    base=replace(base,ordinal_given=bool(getattr(flags,"ordinal_given",False)),enabled=tuple(configured_base),factor_rank=int(getattr(flags,'c10_rank',16)),
                 blas_threads=int(getattr(flags,'wb_blas_threads',1)),
                 weight_k=float(getattr(flags,'wb_stack_strength',200)),**repairs)
    base=replace(base,regularized_stack=bool(getattr(flags,'wb_regularized_stack',False)),
                 c10_gate=bool(getattr(flags,'wb_c10_gate',False)),folds=int(getattr(flags,'wb_folds',3)))
    if _iteration_caps(flags):
        base=replace(base,factor_max_iter=int(route_config.WB_ITERATION_CAPS['C10']))
    complete,query=legacy.complete_rows(frame,schema),legacy.hidden_rows(frame,schema)
    data=legacy.Data(frame,schema,base)
    if len(complete)<3 or not len(query) or not data.targets:
        return legacy.predict_with_diagnostics(frame,schema,replace(base,enabled=('C1','C2')))
    crossfit=bool(getattr(flags,'e1',True))
    plans,outer,inner,final_index=_contexts(complete,query,base,crossfit)
    state.update(plans=plans,outer=outer,final=final_index,data=data,complete=complete,
                 query=query,base=base)
    component_seconds={}; component_records=[];failures={};count=None; failed=set(); global_class_losses={}
    with threadpool_limits(limits=route_config.THREADS):
      for family in ('C1_C2',) + tuple(n for n in base.enabled if n not in ('C1','C2')):
        pending = []
        for index,plan in enumerate(plans):
            if budget is not None: budget.checkpoint()
            masked,_=_masked_data(frame,schema,plan['train'],base)
            classes=None
            if family=='C4' and index==final_index and 'C4' not in failed:
                for prior_plan,addition in zip(plans,pending):
                    prior_plan['bank'].update(addition)
                oof=_collect(plans,outer,complete,schema)
                _,count,global_class_losses=legacy.select_classes(oof,data,complete,base)
                classes=(count,) if count else None
            family_config=replace(base,enabled=('C1','C2') if family=='C1_C2' else (family,))
            try:
                bank,times,detail=legacy.fit_candidates(masked,schema,plan['train'],plan['query'],family_config,classes,
                    checkpoint=budget.checkpoint if budget else None, failed=failed,reuse_bank=plan.get('bank'))
            except Exception as error:
                raise
            component_records.append({'family':family,'plan':index,'kind':plan['kind'],'train_rows':len(plan['train']),'query_rows':len(plan['query']),'seconds':dict(times),'details':detail})
            pending.append(bank)
            failures.setdefault(str(index),{}).update(detail.get('failures',{}))
            for key,value in times.items():component_seconds[key]=component_seconds.get(key,0.)+value
        for plan,addition in zip(plans,pending):
            plan.setdefault('bank',{}).update(addition)
        state['component_seconds']=component_seconds
    all_names=set.union(*(set(plan['bank']) for plan in plans))
    common=set.intersection(*(set(plan['bank']) for plan in plans))
    absent=all_names-common
    absent={name for name in absent if not name.startswith('C4_')}
    c4_failed=any(not any(k.startswith('C4_') for k in plan['bank']) for plan in plans) if 'C4' in base.enabled else False
    for plan in plans:
        plan['bank']={k:v for k,v in plan['bank'].items() if k not in absent and not(c4_failed and k.startswith('C4_'))}
    for plan in plans:
        plan['bank']={k:v for k,v in plan['bank'].items() if k.split('_')[0] not in failed}
    base_oof=_collect(plans,outer,complete,schema)
    for index,plan in enumerate(plans):
        if index==final_index:
            plan['gfic_classes']=(count,) if count else (4,)
        else:
            subset=np.flatnonzero(np.isin(complete,plan['train']))
            _,local_count,_=legacy.select_classes(_subset(base_oof,subset),data,complete[subset],base)
            plan['gfic_classes']=(local_count,) if local_count else (4,)
    optional={};enabled=list(base.enabled)
    state.update(optional=optional,component_seconds=component_seconds)
    configured=tuple(getattr(flags,'optional_families',()) or route_config.WB_FAMILIES)
    requested={name: name in configured and bool(getattr(flags,attr,True)) for name,attr in
               (('GFIC','gfic'),('KDB_HLS1','kdb'),('LinearFull','linear_non_erpis'),('NeuralShared','neural_non_erpis'))}
    is_wb='group' in schema['items'] and 'user.hadJob' in schema['items']
    requested.update({name:is_wb and name in configured and bool(getattr(flags,attr,True))
                      for name,attr in (('WB_INTERACTIONS','wb_interactions'),
                                        ('BCT_OPTION3','wb_h2_bct'),('TABICL','wb_tabicl'),
                                        ('WB_RESPONSE','wb_response'),('WB_TRANSITIONS','wb_transitions'),
                                        ('WB_NEURAL_ENSEMBLE','wb_neural_ensemble'),
                                        ('WB_SECTOR','wb_sector'),('WB_ORDINAL_SC','wb_ordinal_sc'))})
    if 'group' in schema['items'] and not bool(getattr(flags,'r9',False)):
        requested['KDB_HLS1']=False
    requested["KDB2"] = is_wb and bool(getattr(flags,"wb_kdb2",False))
    if requested["KDB2"] and getattr(flags,"wb_kdb2_replace",False):
        requested["KDB_HLS1"] = False
    requested["WB_HGB"] = is_wb and bool(getattr(flags,"wb_hgb",False))
    requested["WB_PROFILE_NA"] = is_wb and bool(getattr(flags,"wb_profile_na",False))
    requested["WB_SHARED_ARMS"] = is_wb and bool(getattr(flags,"wb_shared_arms",False))
    requested["WB_TABM"] = is_wb and bool(getattr(flags,"wb_tabm",False))
    if requested["WB_TABM"]:
        requested["WB_NEURAL_ENSEMBLE"] = False
    specs=[
      ("KDB2",lambda m,d,t,q,f,b,p:_single_bank(wb_ideas_kdb,d,t,q,b,parent_main=bool(f.r9))),
      ('GFIC',lambda m,d,t,q,f,b,p:_gfic_bank(m,d,t,q,f,b,reuse_bank=p['bank'],classes=p['gfic_classes'],failed=failed)),
      ('KDB_HLS1',lambda m,d,t,q,f,b,p:_kdb_bank(m,d,t,q,f,b)),
      ('WB_TRANSITIONS',lambda m,d,t,q,f,b,p:_single_bank(wb_transitions,d,t,q,b)),
      ('WB_RESPONSE',lambda m,d,t,q,f,b,p:_single_bank(wb_response,d,t,q,b,
          max_iter=(route_config.WB_ITERATION_CAPS['WB_RESPONSE'] if _iteration_caps(f) else wb_response.MAX_ITER))),
      ('BCT_OPTION3',lambda m,d,t,q,f,b,p:_single_bank(wb_h2_bct,d,t,q,b)),
      ('LinearFull',lambda m,d,t,q,f,b,p:_neural_bank(m,d,t,q,f,b,linear=True)),
      ('NeuralShared',lambda m,d,t,q,f,b,p:_neural_bank(m,d,t,q,f,b,linear=False)),
      ('WB_INTERACTIONS',lambda m,d,t,q,f,b,p:_single_bank(wb_interactions,d,t,q,b)),
      ('WB_NEURAL_ENSEMBLE',lambda m,d,t,q,f,b,p:_neural_bank(m,d,t,q,f,b,ensemble=True,reuse_bank=p['bank'])),
      ('WB_SECTOR',lambda m,d,t,q,f,b,p:_single_bank(wb_sector,d,t,q,b)),
      ("WB_HGB",lambda m,d,t,q,f,b,p:_idea_bank(wb_ideas_hgb.candidate(d,t,q,b,items=(f.wb_hgb_items or None)))),
      ("WB_PROFILE_NA",lambda m,d,t,q,f,b,p:_idea_bank(wb_ideas_profiles.candidate(d,t,q,b,reference=p['bank'].get('WB_RESPONSE')))),
      ("WB_SHARED_ARMS",lambda m,d,t,q,f,b,p:_idea_bank(wb_ideas_arms.candidate(d,t,q,b))),
      ("WB_TABM",lambda m,d,t,q,f,b,p:_idea_bank(wb_ideas_tabm.candidate(d,t,q,b))),
      ('WB_ORDINAL_SC',lambda m,d,t,q,f,b,p:_single_bank(wb_ordinal_sc,d,t,q,b))]
    for name,runner in specs:
        if not requested[name]:continue
        accepted,detail=_add_atomic(name,runner,plans,frame,schema,flags,budget,base)
        if accepted and name=='GFIC':
            for plan in plans:
                for family in ('C7','C8'):
                    if family in failed:plan['bank'].pop(family,None)
        optional[name]=detail;component_seconds[name]=detail.get('seconds',0.)
        if accepted:enabled.extend((() if getattr(flags,'wb_prune_members',True) else ('GFIC_C4',)) if name=='GFIC' else (name,))
    if requested['TABICL']:
        if wb_tabicl is None:
            optional['TABICL']={'status':'failed_atomically','exception':'ImportError'}
        else:
            reserve=(float(getattr(flags,'wb_factor_reserve_seconds',0.0))
                     if bool(getattr(flags,'wb_factorized',False)) else 0.0)
            allowance=(max(0.0,budget.remaining()-reserve)
                       if budget is not None else None)
            frozen=bool(getattr(flags,'wb_tabicl_frozen',False))
            phase=int(getattr(flags,'phase',2) or 2)
            lists=(getattr(route_config,'TABICL_ITEMS_CUDA',route_config.TABICL_ITEMS)
                   if str(getattr(wb_tabicl,'_DEVICE','cpu')).startswith('cuda') else route_config.TABICL_ITEMS)
            selected=(getattr(flags,'wb_tabicl_items',None) or lists.get(phase)
                      if frozen else None)
            estimators=int(getattr(flags,'wb_tabicl_estimators',0) or 0)
            on_cuda=str(getattr(wb_tabicl,'_DEVICE','cpu')).startswith('cuda')
            n_estimators=estimators if (on_cuda and phase==2 and estimators>1) else 1
            allowance,allocation_detail=_tabicl_cpu_allowance(
                allowance,budget,flags,phase=phase,on_cuda=on_cuda,is_wb=is_wb,
                factor_reserve=reserve)
            def cpu_fallback_allowance(remaining,_phase=phase,_reserve=reserve):
                return _tabicl_cpu_allowance(remaining,budget,flags,phase=_phase,
                    on_cuda=False,is_wb=is_wb,factor_reserve=_reserve)
            banks,detail=wb_tabicl.fit_plans(frame,schema,plans,budget=budget,
                max_items=getattr(flags,'wb_tabicl_max_items',0) or None,
                cap_seconds=allowance,config=base,selected_items=selected,frozen=frozen,
                n_estimators=n_estimators,threads=route_config.THREADS,
                cpu_fallback_allowance=cpu_fallback_allowance if on_cuda else None)
            if allocation_detail is not None:
                detail['allocation']=allocation_detail
            for plan,bank in zip(plans,banks):
                plan['bank'].update(bank)
            optional['TABICL']=detail
            component_seconds['TABICL']=detail.get('elapsed_seconds',0.)
            if any('TabICL_WB' in bank for bank in banks):enabled.append('TabICL_WB')
            refine_items=((getattr(flags,'wb_tabicl_refine_items',None)
                           or route_config.TABICL_REFINE_ITEMS.get(phase) or ()) if frozen else None)
            if (bool(getattr(flags,'wb_tabicl_refine',True))
                    and (refine_items is None or len(refine_items))
                    and detail.get('status')=='ok'
                    and (frozen or len(detail.get('covered_items',[]))==len(data.targets))
                    and (budget is None or budget.remaining()>reserve+5.0)):
                allowance=max(0.0,budget.remaining()-reserve) if budget is not None else None
                allowance,allocation_detail=_tabicl_cpu_allowance(
                    allowance,budget,flags,phase=phase,
                    on_cuda=str(getattr(wb_tabicl,'_DEVICE','cpu')).startswith('cuda'),
                    is_wb=is_wb,factor_reserve=reserve)
                refined,refine_detail=wb_tabicl.fit_plans(frame,schema,plans,budget=budget,
                    cap_seconds=allowance,config=base,n_estimators=4,
                    selected_items=refine_items,frozen=frozen,threads=route_config.THREADS)
                if allocation_detail is not None:
                    refine_detail['allocation']=allocation_detail
                refine_name='TabICL_WB_ENSEMBLE'
                for plan,bank in zip(plans,refined):
                    if 'TabICL_WB' in bank:
                        plan['bank'][refine_name]=legacy.Candidate(refine_name,bank['TabICL_WB'].probabilities)
                optional[refine_name]=refine_detail
                component_seconds[refine_name]=refine_detail.get('elapsed_seconds',0.)
                if any(refine_name in p['bank'] for p in plans):enabled.append(refine_name)
    if is_wb and bool(getattr(flags,'wb_kumo',False)):
        phase=int(getattr(flags,'phase',2) or 2)
        if wb_kumo is None:
            optional['KUMO']={'status':'failed_atomically','exception':'ImportError'}
        elif phase!=2 or not str(getattr(wb_kumo,'_DEVICE','cpu')).startswith('cuda'):
            optional['KUMO']={'status':'skipped','reason':'CUDA and phase 2 only','phase':phase,
                              'availability':wb_kumo.availability()}
        else:
            reserve=(float(getattr(flags,'wb_factor_reserve_seconds',0.0))
                     if bool(getattr(flags,'wb_factorized',False)) else 0.0)
            allowance=(max(0.0,budget.remaining()-reserve)
                       if budget is not None else None)
            many=bool(getattr(flags,'wb_kumo_many_class',False))
            lists=route_config.KUMO_ITEMS_CUDA_MANY if many else route_config.KUMO_ITEMS_CUDA
            selected=tuple(getattr(flags,'wb_kumo_items',None) or lists.get(phase,()))
            banks,detail=wb_kumo.fit_plans(frame,schema,plans,budget=budget,cap_seconds=allowance,
                config=base,selected_items=selected,many_class=many,
                n_estimators=max(1,int(getattr(flags,'wb_kumo_estimators',1) or 1)),
                threads=route_config.THREADS)
            for plan,bank in zip(plans,banks):
                plan['bank'].update(bank)
            optional['KUMO']=detail
            component_seconds['KUMO']=detail.get('elapsed_seconds',0.)
            if any(wb_kumo.NAME in bank for bank in banks):enabled.append(wb_kumo.NAME)
    state.update(optional=optional,component_seconds=component_seconds)
    config=replace(base,enabled=tuple(dict.fromkeys(enabled)))
    oof = _collect(plans, outer, complete, schema)
    raw_diagnostics = {'component_seconds': component_seconds, 'component_records': component_records,
                       'optional': optional, 'failed_families': failures, 'requested': requested,
                       'removed_base_members': sorted(absent), 'seconds': perf_counter()-started}
    capture = {'plans': plans, 'outer': outer, 'final': final_index, 'complete': complete,
               'query': query, 'data': data, 'config': config, 'oof': oof,
               'diagnostics': raw_diagnostics, 'provenance': {'kdb_temperature_applied': False, 'base_oof_raw': True}}
    if cache is not None:
        cache.update(capture)
        if cache.get('bank_only'):
            return capture
    if budget is not None:
        budget.begin_finalization()
    if bool(getattr(flags, 'wb_honest_meta', True)):
        if getattr(flags, 'wb_kdb_temper', False):
            raise ValueError('Honest meta route requires raw, untempered kDB')
        if getattr(flags, 'r2', False):
            raise ValueError('Honest meta route does not implement gate-aware R2 calibration')
        if 'GFIC_C4' in oof:
            raise ValueError('Honest meta route excludes adaptively selected GFIC_C4')
        fold_of = np.full(len(complete), -1, dtype=int)
        for fold, plan_index in enumerate(outer):
            fold_of[np.isin(complete, plans[plan_index]['query'])] = fold
        if np.any(fold_of < 0) or sum(len(plans[i]['query']) for i in outer) != len(complete):
            raise ValueError('OOF folds must cover each complete respondent exactly once')
        meta, meta_details = wb_meta.fit_with_guard(oof, data, complete, fold_of, config,
            factorized=bool(getattr(flags, 'wb_factorized', False)),
            factor_strength=float(getattr(flags, 'wb_factor_strength', 200)),
            item_calibration=bool(getattr(flags, 'item_calibration', True)), budget=budget,
            factor_seconds=float(getattr(flags, 'wb_factor_reserve_seconds', 60)),
            provenance={'kdb_temperature_applied':False,'base_oof_raw':True},
            factor_solver=str(getattr(flags, 'wb_factor_solver', 'slsqp')))
        pool_failure = {}
        prediction = wb_meta.predict_meta(dict(plans[final_index]['bank']), meta, pool_failure)
        if pool_failure:
            meta_details.update(pool_application=pool_failure, factor_accepted=False,
                                status='pool_application_failed')
        if bool(getattr(flags, 'wb_parent_gate', False)):
            raw_diagnostics['parent_gate_items'] = _propagate_parent_gates(prediction, schema)
        if bool(getattr(flags, 'wb_class_bias', False)):
            from budget import CandidateBudgetExceeded
            bias_budget = (wb_meta._FactorDeadline(max(0., budget.remaining()-20.), budget)
                           if budget is not None else None)
            try:
                if bias_budget is not None:
                    bias_budget.checkpoint()
                fitted_bias = wb_ideas_class_bias.fit_crossfit_bias(
                    oof, data, complete, fold_of, meta.config,
                    strength=float(getattr(flags, 'wb_class_bias_strength', 50.)),
                    factorized=bool(getattr(flags, 'wb_factorized', False)),
                    factor_strength=float(getattr(flags, 'wb_factor_strength', 50.)),
                    item_calibration=bool(getattr(flags, 'item_calibration', True)),
                    factor_seconds=600., budget=bias_budget,
                    provenance={'kdb_temperature_applied':False,'base_oof_raw':True})
                corrected = wb_ideas_class_bias.apply_bias(
                    prediction, fitted_bias, data=data, rows=query)
                if bias_budget is not None:
                    bias_budget.checkpoint()
                prediction = corrected
                raw_diagnostics['class_bias'] = {
                    'status': 'completed', 'strength': fitted_bias['strength'],
                    'fit_rows': fitted_bias['fit_rows'], 'seconds': fitted_bias['seconds'],
                    'crossfit': fitted_bias['crossfit'], 'items': fitted_bias['diagnostics'],
                    'biases': {name: item['bias'].tolist()
                               for name, item in fitted_bias['items'].items()}}
            except CandidateBudgetExceeded as error:
                raw_diagnostics['class_bias'] = {
                    'status': 'budget_exhausted_kept_base', 'reason': str(error)}
        if budget is not None:
            budget.checkpoint()
        output, remap = _render(frame,schema,complete,query,data,prediction,config,
                                waterfilled=bool(getattr(flags,'wb_waterfill',False)))
        return output, dict(raw_diagnostics, route='non_erpis_disjoint_meta',
            seconds=perf_counter()-started, base_fit_count=len(plans),
            phase=int(getattr(flags,'phase',1)), candidate_names=meta.stack['names'],
            instrument_weights=meta.stack['instrument'].tolist(),
            item_weights={item:w.tolist() for item,w in meta.stack['weights'].items()},
            temperature=meta.temperature, marginal_weight=meta.marginal_weight,
            item_calibration=meta.pairs, classes=meta.choices,
            class_oof_nll=meta.class_losses, meta=meta_details, wave_remap=remap,
            kdb_temperature=[], plans=[{'kind':p['kind'],'train_rows':len(p['train']),
                                       'query_rows':len(p['query'])} for p in plans])
    temperature_details=[]
    if requested['KDB_HLS1'] and optional['KDB_HLS1']['status']=='accepted' and bool(getattr(flags,'wb_kdb_temper',False)):
        temperature_details=_temper_kdb(plans,outer,final_index,complete,data,config,budget)
    if budget is not None:budget.checkpoint()
    oof=_collect(plans,outer,complete,schema)
    selected={name:candidate for name,candidate in oof.items() if not name.startswith("C4_")}
    choice={};class_losses=global_class_losses
    if count is not None and "C4_%d" % count in oof:
        key="C4_%d" % count
        selected["C4"]=legacy.Candidate("C4",oof[key].probabilities)
        choice["C4"]=key
    stack=legacy.fit_stack(selected,data,complete,config)
    if budget is not None:budget.checkpoint()
    calibration={item:np.empty((len(complete),width)) for item,width in zip(data.targets,data.ycards)}
    priors={item:np.empty_like(calibration[item]) for item in data.targets}
    position_of={int(row):i for i,row in enumerate(complete)}
    calibration_details=[]
    gate_enabled=bool(getattr(flags,'r2',False))
    gate_config=gfic.Config(gate_factor=True)
    with threadpool_limits(limits=route_config.THREADS):
        for outer_index,nested_indices in zip(outer,inner):
            if budget is not None:budget.checkpoint()
            plan=plans[outer_index]
            positions=np.array([position_of[int(row)] for row in plan['query']])
            fit_positions=np.flatnonzero(~np.isin(complete,plan['query']))
            if crossfit:
                inner_bank=_subset(oof,fit_positions);inner_rows=complete[fit_positions]
                inner_data=data
            else:
                masked,inner_data=_masked_data(frame,schema,plan['train'],config)
                inner_rows=plan['train'];inner_bank=_collect(plans,nested_indices,inner_rows,schema)
            local_selected,local_choice,_=_select(inner_bank,inner_data,inner_rows,config)
            local_stack=legacy.fit_stack(local_selected,inner_data,inner_rows,config)
            for item,weights in local_stack['weights'].items():
                p=np.zeros((len(positions),len(data.options[item])))
                for w,name in zip(weights,local_stack['names']):
                    value=oof[local_choice.get(name,name)].probabilities.get(item)
                    if value is not None:p+=w*value[positions]
                calibration[item][positions]=legacy.normalize(p)
            marginal=plan['bank']['C1']
            if gate_enabled:
                laws=gfic.gate_laws(data,plan['train'],gate_config)
                marginal=wb_calibration.conditional_prior(data,plan['train'],plan['query'],laws,marginal)
            for item in data.targets:priors[item][positions]=marginal.probabilities[item]
            calibration_details.append({'classes':local_choice,'candidate_names':local_stack['names'],
                'training_rows':len(inner_rows),'held_rows':len(positions),'disjoint_labels':not bool(set(inner_rows)&set(plan['query'])),
                'instrument_weights':local_stack['instrument'].tolist()})
        if budget is not None:budget.checkpoint()
        calibration_stack={'mixed':calibration}
        prior=legacy.Candidate('C1_conditional',priors)
        temperature,marginal_weight=legacy.fit_calibration(calibration_stack,prior,data,complete,config)
        if budget is not None:budget.checkpoint()
        item_enabled=bool(getattr(flags,'item_calibration',True)) and (bool(getattr(flags,'r1',False)) or optional.get('GFIC',{}).get('status')=='accepted')
        if gate_enabled:
            pairs=wb_calibration.fit_pairs(calibration,prior,data,complete,config,(temperature,marginal_weight),item_enabled,True,budget)
        elif item_enabled:
            pairs=gfic.fit_item_calibration(calibration_stack,prior,data,complete,config,temperature,marginal_weight,budget)
        else:
            pairs={item:(temperature,marginal_weight) for item in data.targets}
        if budget is not None:budget.checkpoint()
        final=dict(plans[final_index]['bank'])
        for name,key in choice.items():final[name]=final[key]
        laws=gfic.gate_laws(data,complete,gate_config) if gate_enabled else {}
        final_prior=wb_calibration.conditional_prior(data,complete,query,laws,final['C1']) if laws else final['C1']
        prediction=(wb_calibration.apply(final,stack,pairs,final_prior,laws,query,config) if gate_enabled
                    else gfic.apply_stack(final,stack,temperature,marginal_weight,config,pairs))
        if budget is not None:budget.checkpoint()
        output,remap=_render(frame,schema,complete,query,data,prediction,config,
                             waterfilled=bool(getattr(flags,'wb_waterfill',False)))
    return output,{'route':'non_erpis_external_oof' if crossfit else 'non_erpis_nested_oof',
        'seconds':perf_counter()-started,'base_fit_count':len(plans),'phase':int(getattr(flags,'phase',1)),
        'plans':[{'kind':p['kind'],'train_rows':len(p['train']),'query_rows':len(p['query'])} for p in plans],
        'requested':requested,'optional':optional,'failed_families':failures,'removed_base_members':sorted(absent),
        'candidate_names':stack['names'],'classes':choice,'class_oof_nll':class_losses,
        'instrument_weights':stack['instrument'].tolist(),
        'item_weights':{item:w.tolist() for item,w in stack['weights'].items()},
        'temperature':temperature,'marginal_weight':marginal_weight,'item_calibration':pairs,
        'calibration_folds':calibration_details,'component_seconds':component_seconds,'component_records':component_records,'wave_remap':remap,
        'kdb_temperature':temperature_details,'gate_recomposition':{item:{key:law[key] for key in ('r_open','r_closed','n_open','n_closed')} for item,law in laws.items()},
        'gfic_integration':'C1/C2 reused, C7/C8 replaced, one elected GFIC class; item calibration independent'}
