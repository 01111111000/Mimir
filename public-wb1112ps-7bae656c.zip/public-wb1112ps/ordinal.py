import re

import numpy as np
from scipy.linalg import cho_factor, cho_solve

from ridge import _one_hot, _project_simplex, _row_indices, _shrink_project


NUMBER = r"[0-9]+(?:\.[0-9]+)?"
NUMERIC_BAND = re.compile(
    rf"^(?:[<>]=?\s*)?{NUMBER}(?:\s*[-–]\s*{NUMBER})?\+?$"
)
MORE_THAN = re.compile(rf"^more than {NUMBER}$", re.IGNORECASE)
EXTRA_OPTIONS = {
    "not answered", "not recorded", "no response", "prefer not to answer",
    "don't know", "do not know",
}


def ordered_indices(record, pure_numeric=False):
    substantive = [(index, value) for index, value in enumerate(record["values"])
                   if value.lower() not in EXTRA_OPTIONS]
    if len(substantive) < 3:
        return []
    if not all(NUMERIC_BAND.fullmatch(value) or MORE_THAN.fullmatch(value)
               for _, value in substantive):
        return []
    if not pure_numeric and not any(any(mark in value for mark in ("-", "–", "+", "<", ">"))
               or value.lower().startswith("more than ")
               for _, value in substantive):
        return []

    def numeric_key(pair):
        value = pair[1]
        return -np.inf if value.startswith("<") else float(re.search(NUMBER, value).group())

    return [index for index, _ in sorted(substantive, key=numeric_key)]


def _ridge(design, query, responses, prior, strength):
    raw = np.broadcast_to(prior, (len(query), len(prior))).copy()
    if not len(design) or not design.shape[1] or not len(query):
        return raw
    mean = design.mean(axis=0)
    centered = design - mean
    gram = centered.T @ centered
    gram.flat[::len(gram) + 1] += strength
    coefficients = cho_solve(cho_factor(gram, lower=True, check_finite=False),
                             centered.T @ (responses - prior), check_finite=False)
    return raw + (query - mean) @ coefficients


def predict_ordinal(schema, feature_codes, feature_cards, target_codes, target_cards,
                    train_rows, query_rows, strength=20.0, alpha=0.5, repair=False):
    if not np.isfinite(strength) or strength <= 0 or not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("strength and alpha must be finite and strictly positive")
    features = np.asarray(feature_codes, dtype=np.int64)
    targets = np.asarray(target_codes, dtype=np.int64)
    cards = np.asarray(feature_cards, dtype=np.int64)
    widths = np.asarray(target_cards, dtype=np.int64)
    records = [(name, record) for name, record in schema["items"].items()
               if record["class"] == "PREDICT"]
    if features.ndim != 2 or targets.ndim != 2 or len(features) != len(targets):
        raise ValueError("Code matrices must share respondents and have two dimensions")
    if cards.ndim != 1 or len(cards) != features.shape[1] or np.any(cards < 1):
        raise ValueError("Each feature needs a positive schema cardinality")
    if (widths.ndim != 1 or len(widths) != len(records)
            or targets.shape[1] != len(records)
            or any(width != len(record["values"]) + bool(record.get("gate"))
                   for width, (_, record) in zip(widths, records))):
        raise ValueError("Target cardinalities must match PREDICT schema order")
    train = _row_indices(train_rows, len(features))
    query = _row_indices(query_rows, len(features))
    design = _one_hot(features, cards, train)
    query_design = _one_hot(features, cards, query)
    training_targets = targets[train]
    predictions, details = [], []
    for column, (name, record) in enumerate(records):
        ordered = ordered_indices(record, pure_numeric=repair)
        if not ordered:
            predictions.append(None)
            continue
        width = widths[column]
        values = training_targets[:, column]
        valid = (values >= 0) & (values < width)
        values = values[valid]
        rank = np.full(width, -1, dtype=np.int64)
        rank[ordered] = np.arange(len(ordered))
        extras = np.flatnonzero(rank < 0)
        substantive = rank[values] >= 0
        details.append({"item": name, "valid_training_rows": int(valid.sum()),
                        "substantive_training_rows": int(substantive.sum()),
                        "ordinal_options": len(ordered), "extra_options": len(extras)})
        if not valid.any():
            predictions.append(np.full((len(query), width), 1.0 / width))
            continue

        group_lookup = np.zeros(width, dtype=np.int64)
        group_lookup[extras] = np.arange(1, len(extras) + 1)
        group_y = group_lookup[values]
        group_counts = np.bincount(group_y, minlength=len(extras) + 1)
        pseudo_counts = alpha * np.r_[len(ordered), np.ones(len(extras))]
        group_prior = (group_counts + pseudo_counts) / (len(values) + alpha * width)
        group_raw = _ridge(design[valid], query_design, np.eye(len(extras) + 1)[group_y], group_prior, strength)
        groups = _shrink_project(group_raw, group_prior) if repair else _project_simplex(group_raw)
        observed_rank = rank[values[substantive]]
        counts = np.bincount(observed_rank, minlength=len(ordered))
        conditional_prior = (counts + alpha) / (len(observed_rank) + alpha * len(ordered))
        cdf_prior = conditional_prior.cumsum()[:-1]
        responses = (observed_rank[:, None] <= np.arange(len(ordered) - 1)).astype(float)
        cdf = _ridge(design[valid][substantive], query_design, responses,
                     cdf_prior, strength)
        if repair:
            increments = np.diff(np.column_stack((np.zeros(len(query)), cdf, np.ones(len(query)))), axis=1)
            delta = increments - conditional_prior
            bounds = np.divide(0.99 * conditional_prior, -delta,
                               out=np.full_like(delta, np.inf), where=delta < 0)
            retained = np.minimum(0.99, bounds.min(axis=1))
            cdf = cdf_prior + retained[:, None] * (cdf - cdf_prior)
        else:
            cdf = np.maximum.accumulate(np.clip(cdf, 0, 1), axis=1)
        conditional = np.diff(np.column_stack((np.zeros(len(query)), cdf,
                                                np.ones(len(query)))), axis=1)
        prediction = np.zeros((len(query), width))
        prediction[:, ordered] = groups[:, :1] * conditional
        prediction[:, extras] = groups[:, 1:]
        predictions.append(prediction)
    return predictions, {"eligible_items": len(details), "items": details,
                         "strength": float(strength), "alpha": float(alpha),
                         "cdf_correction": "convex_marginal_shrinkage" if repair else "clip_then_cumulative_maximum"}
