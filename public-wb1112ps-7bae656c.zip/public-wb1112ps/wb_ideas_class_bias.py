from time import perf_counter

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

import legacy


DEFAULT_STRENGTH = 50.0


def _probabilities(predictions):
    return (predictions.probabilities if hasattr(predictions, 'probabilities')
            else predictions)


def _check_probability(p, n, width):
    p = np.asarray(p, dtype=np.float64)
    if p.shape != (n, width):
        raise ValueError('Class-bias prediction rows/options do not align')
    if (not np.isfinite(p).all() or (p < 0).any()
            or not np.allclose(p.sum(axis=1), 1., atol=1e-8, rtol=0.)):
        raise ValueError('Class-bias input must contain legal probabilities')
    return p


def _given_gate(data, item):
    gate = data.schema['items'][item].get('gate')
    if not gate or gate['parent'] not in data.given:
        return None
    parent = gate['parent']
    values = list(data.options[parent])
    accepted = [values.index(value) for value in gate['observed_if']]
    return {'parent': parent, 'accepted_codes': accepted,
            'parent_options': tuple(values)}


def _eligible(data, rows, gate):
    if gate is None:
        return np.ones(len(rows), dtype=bool)
    parent = gate['parent']
    if tuple(data.options[parent]) != gate['parent_options']:
        raise ValueError('GIVEN-parent option order changed after bias fit')
    return np.isin(data.codes[parent][rows], gate['accepted_codes'])


def _conditional(p, support):
    content = p[:, support]
    mass = content.sum(axis=1)
    conditional = np.divide(content, mass[:, None],
                            out=np.full_like(content, 1. / len(support)),
                            where=mass[:, None] > 0.)
    logp = np.full_like(conditional, -np.inf)
    np.log(conditional, out=logp, where=conditional > 0.)
    return mass, logp


def _objective(bias, logp, mass, actual, width, metric_floor, strength):
    logits = logp + bias[None, :]
    p = np.exp(logits - logsumexp(logits, axis=1)[:, None])
    c = 1. - width * metric_floor
    p_actual = p[np.arange(len(actual)), actual]
    q_actual = metric_floor + c * mass * p_actual
    value = -np.log(q_actual).sum() + .5 * strength * np.dot(bias, bias)
    multiplier = c * mass * p_actual / q_actual
    residual = p.copy()
    residual[np.arange(len(actual)), actual] -= 1.
    gradient = (multiplier[:, None] * residual).sum(axis=0) + strength * bias
    return float(value), gradient


def fit_bias(predictions, data, rows, *, strength=DEFAULT_STRENGTH,
             metric_floor=1e-3, max_iter=60, budget=None):
    if not np.isfinite(strength) or strength <= 0.:
        raise ValueError('Class-bias strength must be finite and positive')
    if not np.isfinite(metric_floor) or metric_floor <= 0.:
        raise ValueError('Class-bias metric_floor must be finite and positive')
    rows = np.asarray(rows)
    if rows.ndim != 1 or rows.dtype.kind not in 'iu' or (rows < 0).any():
        raise ValueError('Class-bias rows must be nonnegative integer indices')
    if len(np.unique(rows)) != len(rows):
        raise ValueError('Class-bias fit respondents must be unique')
    probabilities = _probabilities(predictions)
    state = {'items': {}, 'strength': float(strength),
             'metric_floor': float(metric_floor), 'diagnostics': {}}
    start = perf_counter()
    for item in data.targets:
        if budget is not None:
            budget.checkpoint()
        if probabilities.get(item) is None:
            continue
        options = tuple(data.options[item])
        width = len(options)
        if width * metric_floor >= 1.:
            raise ValueError('Class-bias affine floor requires K*floor < 1')
        p = _check_probability(probabilities[item], len(rows), width)
        gate_value = data.schema.get('gated_value', 'NA_GATED')
        support = np.asarray([k for k, value in enumerate(options)
                              if value != gate_value], dtype=int)
        gate = _given_gate(data, item)
        bias = np.zeros(len(support), dtype=np.float64)
        actual = np.asarray(data.codes[item][rows], dtype=int)
        valid = _eligible(data, rows, gate) & np.isin(actual, support)
        n = int(valid.sum())
        diag = {'fit_rows': n, 'iterations': 0, 'status': 'identity',
                'objective_before': None, 'objective_after': None}
        if len(support) > 1 and n:
            mass, logp = _conditional(p[valid], support)
            remap = np.full(width, -1, dtype=int)
            remap[support] = np.arange(len(support))
            target = remap[actual[valid]]
            args = (logp, mass, target, width, metric_floor, float(strength))
            initial, _ = _objective(bias, *args)
            def objective(theta):
                if budget is not None:
                    budget.checkpoint()
                return _objective(theta, *args)
            fit = minimize(objective, bias, method='L-BFGS-B', jac=True,
                           options={'maxiter': int(max_iter), 'ftol': 1e-11,
                                    'gtol': 1e-7, 'maxls': 30})
            proposed = fit.x - np.mean(fit.x)
            final, _ = _objective(proposed, *args)
            accepted = (np.isfinite(proposed).all() and np.isfinite(final)
                        and final < initial)
            if accepted:
                bias = proposed
            diag.update({'iterations': int(fit.nit),
                         'status': 'fitted' if accepted else 'identity',
                         'optimizer_success': bool(fit.success),
                         'objective_before': float(initial),
                         'objective_after': float(final if accepted else initial)})
        diag['bias_l2'] = float(np.linalg.norm(bias))
        state['items'][item] = {'options': options, 'support': support,
                                'bias': bias, 'given_gate': gate}
        state['diagnostics'][item] = diag
    state['seconds'] = perf_counter() - start
    state['fit_rows'] = len(rows)
    return state


def apply_bias(predictions, state, *, data=None, rows=None):
    probabilities = _probabilities(predictions)
    out = {item: None if p is None else np.asarray(p).copy()
           for item, p in probabilities.items()}
    if rows is not None:
        rows = np.asarray(rows)
        if rows.ndim != 1 or rows.dtype.kind not in 'iu' or (rows < 0).any():
            raise ValueError('Class-bias rows must be nonnegative integer indices')
    for item, record in state['items'].items():
        if out.get(item) is None:
            continue
        original = np.asarray(probabilities[item])
        p = _check_probability(original, len(original), len(record['options']))
        if data is not None and tuple(data.options[item]) != record['options']:
            raise ValueError('Target option order changed after bias fit')
        if not np.any(record['bias']):
            continue
        gate = record['given_gate']
        if gate is not None:
            if data is None or rows is None or len(rows) != len(p):
                raise ValueError('GIVEN-gated correction requires aligned data/rows')
            valid = _eligible(data, rows, gate)
        else:
            valid = np.ones(len(p), dtype=bool)
        positions = np.flatnonzero(valid)
        if not len(positions):
            continue
        support = record['support']
        mass, logp = _conditional(p[positions], support)
        logits = logp + record['bias'][None, :]
        corrected = mass[:, None] * np.exp(
            logits - logsumexp(logits, axis=1)[:, None])
        out[item] = p.copy()
        out[item][np.ix_(positions, support)] = corrected
    return legacy.Candidate('CLASS_BIAS', out)


def fit_crossfit_bias(oof, data, complete, fold_of, config, *,
                      strength=DEFAULT_STRENGTH, seed=981020,
                      factorized=True, factor_strength=50.0,
                      item_calibration=True, factor_seconds=600.0,
                      factor_max_iter=80, max_iter=60, budget=None,
                      provenance=None):
    import wb_meta

    started = perf_counter()
    complete = np.asarray(complete)
    fold_of = np.asarray(fold_of)
    if (complete.ndim != 1 or complete.dtype.kind not in 'iu'
            or (complete < 0).any()
            or len(np.unique(complete)) != len(complete)):
        raise ValueError('Crossfit bias needs unique absolute TRAIN row indices')
    if (fold_of.shape != complete.shape or fold_of.dtype.kind not in 'iu'
            or (fold_of < 0).any()):
        raise ValueError('Crossfit bias needs aligned nonnegative base-fold ids')
    if not len(complete):
        raise ValueError('Crossfit bias needs at least one held-out base fold')
    wb_meta._check_raw(oof, provenance)
    mixed = {item: np.full((len(complete), len(data.options[item])), np.nan)
             for item in data.targets}
    coverage = np.zeros(len(complete), dtype=np.int8)
    details = []
    for fold in np.unique(fold_of):
        if budget is not None:
            budget.checkpoint()
        block = np.flatnonzero(fold_of == fold)
        if len(block) < 8:
            raise ValueError('Crossfit bias requires >=8 respondents per base fold')
        permutation = np.random.default_rng(int(seed) + int(fold)).permutation(block)
        half_a, half_b = permutation[::2], permutation[1::2]
        for direction, fit_pos, predict_pos in (
                ('A_to_B', half_a, half_b), ('B_to_A', half_b, half_a)):
            fit_bank = wb_meta.subset_bank(oof, fit_pos)
            predict_bank = wb_meta.subset_bank(oof, predict_pos)
            meta, diagnostic = wb_meta.fit_with_guard(
                fit_bank, data, complete[fit_pos],
                np.zeros(len(fit_pos), dtype=np.int64), config,
                factorized=factorized, factor_strength=factor_strength,
                item_calibration=item_calibration, budget=budget,
                factor_seconds=factor_seconds, factor_max_iter=factor_max_iter,
                provenance=provenance)
            prediction = wb_meta.predict_meta(predict_bank, meta)
            for item in data.targets:
                mixed[item][predict_pos] = _check_probability(
                    prediction.probabilities[item], len(predict_pos),
                    len(data.options[item]))
            coverage[predict_pos] += 1
            guard = diagnostic.get('guard', {})
            details.append({
                'base_fold': int(fold), 'direction': direction,
                'meta_fit_positions': fit_pos.tolist(),
                'bias_prediction_positions': predict_pos.tolist(),
                'meta_fit_rows': int(len(fit_pos)),
                'bias_prediction_rows': int(len(predict_pos)),
                'same_base_fold': True, 'respondents_disjoint': True,
                'factor_status': diagnostic.get('status'),
                'factor_accepted': bool(diagnostic.get('factor_accepted', False)),
                'factor_guard_delta': guard.get('delta_nll'),
                'meta_seconds': float(diagnostic.get('seconds', 0.)),
                'classes': dict(meta.choices),
            })
    if not np.all(coverage == 1):
        raise ValueError('Every bias-training respondent must be predicted exactly once')
    meta_seconds = perf_counter() - started
    state = fit_bias(mixed, data, complete, strength=strength,
                     metric_floor=config.metric_floor, max_iter=max_iter,
                     budget=budget)
    state['crossfit'] = {
        'method': 'same_base_fold_reciprocal_halves_guarded_meta',
        'seed': int(seed), 'base_folds': int(len(np.unique(fold_of))),
        'respondents': int(len(complete)), 'coverage_exactly_once': True,
        'factor_requested': bool(factorized),
        'factor_strength': float(factor_strength),
        'factor_seconds_per_meta_fit': float(factor_seconds),
        'raw_bank_provenance': dict(provenance or {}),
        'meta_seconds': float(meta_seconds),
        'bias_seconds': float(state['seconds']),
        'seconds': float(perf_counter() - started),
        'folds': details,
        'interpretation': 'Offset TRAIN fit only; evaluate on external QUERY',
    }
    return state
