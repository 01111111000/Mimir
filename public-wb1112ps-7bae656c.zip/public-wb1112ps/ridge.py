import numpy as np
from scipy.linalg import cho_factor, cho_solve
from wb_ordinal_given import append_numeric


def _project_simplex(values):
    if values.shape[0] == 0:
        return values.copy()
    ordered = np.sort(values, axis=1)[:, ::-1]
    cumulative = np.cumsum(ordered, axis=1) - 1.0
    ranks = np.arange(1, values.shape[1] + 1, dtype=float)
    support = ordered > cumulative / ranks
    rho = support.sum(axis=1) - 1
    theta = cumulative[np.arange(len(values)), rho] / (rho + 1)
    result = np.maximum(values - theta[:, None], 0.0)
    return result / result.sum(axis=1, keepdims=True)


def _shrink_project(values, prior, epsilon=0.01):
    lower = epsilon * np.asarray(prior)
    mixed = (1.0 - epsilon) * values + lower
    return lower + (1.0 - epsilon) * _project_simplex((mixed - lower) / (1.0 - epsilon))


def _row_indices(rows, size):
    rows = np.asarray(rows)
    if rows.ndim != 1:
        raise ValueError("Row selectors must be one-dimensional")
    if rows.dtype == bool:
        if len(rows) != size:
            raise ValueError("Boolean row selectors must cover the full frame")
        return np.flatnonzero(rows)
    indices = rows.astype(np.int64)
    if np.any(indices < 0) or np.any(indices >= size):
        raise ValueError("Row index outside the frame")
    return indices


def _one_hot(codes, cards, rows):
    widths = cards + 1
    offsets = np.concatenate(([0], np.cumsum(widths)))
    result = np.zeros((len(rows), int(offsets[-1])), dtype=float)
    selected = codes[rows]
    for column, card in enumerate(cards):
        values = selected[:, column]
        known = (values >= 0) & (values < card)
        levels = np.where(known, values, card)
        result[np.arange(len(rows)), offsets[column] + levels] = 1.0
    return result


def predict_ridge(feature_codes, feature_cards, target_codes, target_cards,
                  train_rows, query_rows, strength=20.0, alpha=0.5, repair=False,
                  numeric_features=None):
    if not np.isfinite(strength) or strength <= 0:
        raise ValueError("strength must be finite and strictly positive")
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("alpha must be finite and strictly positive")
    features = np.asarray(feature_codes, dtype=np.int64)
    targets = np.asarray(target_codes, dtype=np.int64)
    cards = np.asarray(feature_cards, dtype=np.int64)
    widths = np.asarray(target_cards, dtype=np.int64)
    if features.ndim != 2 or targets.ndim != 2:
        raise ValueError("Code matrices must have two dimensions")
    if features.shape[0] != targets.shape[0]:
        raise ValueError("Feature and target matrices must share respondents")
    if cards.ndim != 1 or len(cards) != features.shape[1] or np.any(cards < 1):
        raise ValueError("Each feature needs a positive schema cardinality")
    if widths.ndim != 1 or len(widths) != targets.shape[1] or np.any(widths < 1):
        raise ValueError("Each target needs a positive schema cardinality")
    train = _row_indices(train_rows, len(features))
    query = _row_indices(query_rows, len(features))
    offsets = np.concatenate(([0], np.cumsum(widths)))
    residuals = np.zeros((len(train), int(offsets[-1])), dtype=float)
    intercept = np.empty(int(offsets[-1]), dtype=float)
    valid_counts = []
    fit_targets = targets[train]
    for column, width in enumerate(widths):
        values = fit_targets[:, column]
        valid = (values >= 0) & (values < width)
        counts = np.bincount(values[valid], minlength=width).astype(float)
        prior = (counts + alpha) / (counts.sum() + alpha * width)
        start, end = offsets[column:column + 2]
        intercept[start:end] = prior
        residuals[valid, start:end] = -prior
        residuals[np.flatnonzero(valid), start + values[valid]] += 1.0
        valid_counts.append(int(valid.sum()))

    raw = np.broadcast_to(intercept, (len(query), len(intercept))).copy()
    feature_width = int(np.sum(cards + 1)) + (0 if numeric_features is None else np.asarray(numeric_features).shape[1])
    fitted = bool(len(train) and feature_width and len(intercept) and len(query))
    if fitted:
        design = append_numeric(_one_hot(features, cards, train), numeric_features, train)
        feature_mean = design.mean(axis=0)
        design -= feature_mean
        gram = design.T @ design
        gram.flat[::feature_width + 1] += strength
        factor = cho_factor(gram, lower=True, check_finite=False)
        coefficients = cho_solve(factor, design.T @ residuals, check_finite=False)
        query_design = append_numeric(_one_hot(features, cards, query), numeric_features, query) - feature_mean
        raw += query_design @ coefficients

    predictions = [(_shrink_project(raw[:, offsets[j]:offsets[j + 1]], intercept[offsets[j]:offsets[j + 1]])
                    if repair else _project_simplex(raw[:, offsets[j]:offsets[j + 1]]))
                   for j in range(len(widths))]
    diagnostics = {
        "training_rows": int(len(train)),
        "feature_columns": feature_width,
        "output_columns": int(len(intercept)),
        "valid_counts": valid_counts,
        "strength": float(strength),
        "alpha": float(alpha),
        "solver": "shared_cholesky" if fitted else "marginal_only",
        "projection": "marginal_lower_simplex" if repair else "euclidean_simplex",
        "marginal_epsilon": 0.01 if repair else 0.0,
    }
    return predictions, diagnostics
