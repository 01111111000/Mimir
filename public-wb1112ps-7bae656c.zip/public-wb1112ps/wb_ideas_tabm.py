from dataclasses import asdict
from time import perf_counter

import numpy as np
import torch
from torch import nn

from neural import NeuralConfig, one_hot_features


NAME = "WB_TABM"
ENSEMBLE_SIZE = 3


def _checkpoint(budget):
    if budget is not None:
        budget.checkpoint()


class SharedEnsembleLinear(nn.Module):
    def __init__(self, input_width, output_width, members, first=False):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(output_width, input_width))
        self.input_scale = nn.Parameter(torch.ones(members, input_width))
        self.output_scale = nn.Parameter(torch.ones(members, output_width))
        self.bias = nn.Parameter(torch.empty(members, output_width))
        limit = input_width ** -0.5
        nn.init.uniform_(self.weight, -limit, limit)
        with torch.no_grad():
            initial_bias = torch.empty(output_width).uniform_(-limit, limit)
            self.bias.copy_(initial_bias.expand(members, -1))
            if first:
                self.input_scale.bernoulli_(0.5).mul_(2).sub_(1)

    def forward(self, value):
        return nn.functional.linear(value * self.input_scale, self.weight) * self.output_scale + self.bias


class TabMNetwork(nn.Module):
    def __init__(self, input_width, target_cards, prior, config, members=ENSEMBLE_SIZE):
        super().__init__()
        self.members = members
        self.target_cards = tuple(target_cards)
        blocks, width = [], input_width
        for index, hidden in enumerate(config.hidden):
            blocks.extend((SharedEnsembleLinear(width, hidden, members, first=index == 0),
                           nn.ReLU(), nn.Dropout(config.dropout)))
            width = hidden
        if not blocks:
            raise ValueError("TabM requires a nonempty hidden architecture")
        self.backbone = nn.Sequential(*blocks)
        self.output_weight = nn.Parameter(torch.zeros(members, width, sum(target_cards)))
        self.output_bias = nn.Parameter(torch.tensor(np.log(prior), dtype=torch.float32)
                                        .expand(members, -1).clone())
        self.groups = []
        offsets = np.r_[0, np.cumsum(target_cards)]
        for card in sorted(set(target_cards)):
            targets = np.flatnonzero(np.asarray(target_cards) == card)
            columns = np.concatenate([np.arange(offsets[j], offsets[j + 1]) for j in targets])
            self.groups.append((torch.as_tensor(targets), torch.as_tensor(columns), int(card)))

    def forward(self, value):
        hidden = self.backbone(value[:, None, :].expand(-1, self.members, -1))
        return torch.bmm(hidden.transpose(0, 1), self.output_weight).transpose(0, 1) + self.output_bias

    def loss(self, logits, truth, floor=0.0, average_predictions=False):
        total = logits.new_zeros(())
        cells = logits.new_zeros(())
        for targets, columns, card in self.groups:
            selected = logits[:, :, columns].reshape(len(logits), self.members, len(targets), card)
            labels = truth[:, targets]
            valid = labels >= 0
            if average_predictions:
                probability = selected.softmax(-1).mean(1)
                chosen = probability.gather(2, labels.clamp(min=0).unsqueeze(-1)).squeeze(-1)
                chosen = torch.log(floor + (1 - card * floor) * chosen) if floor else chosen.log()
                total = total - chosen[valid].sum()
                cells = cells + valid.sum()
            else:
                label_index = labels[:, None, :, None].expand(-1, self.members, -1, 1).clamp(min=0)
                chosen = selected.log_softmax(-1).gather(3, label_index).squeeze(-1)
                if floor:
                    chosen = torch.log(floor + (1 - card * floor) * chosen.exp())
                mask = valid[:, None, :].expand_as(chosen)
                total = total - chosen[mask].sum()
                cells = cells + mask.sum()
        return total / cells.clamp(min=1)

    def probabilities(self, value, batch_size=512, budget=None):
        self.eval()
        blocks = []
        with torch.no_grad():
            for start in range(0, len(value), batch_size):
                _checkpoint(budget)
                logits = self(value[start:start + batch_size])
                result = torch.empty((len(logits), sum(self.target_cards)), dtype=logits.dtype)
                for targets, columns, card in self.groups:
                    p = logits[:, :, columns].reshape(len(logits), self.members, len(targets), card)
                    result[:, columns] = p.softmax(-1).mean(1).reshape(len(logits), -1)
                blocks.append(result.numpy())
        packed = np.concatenate(blocks) if blocks else np.empty((0, sum(self.target_cards)))
        offsets = np.r_[0, np.cumsum(self.target_cards)]
        values = []
        for left, right in zip(offsets[:-1], offsets[1:]):
            p = np.maximum(packed[:, left:right].astype(np.float64), 1e-9)
            values.append(p / p.sum(1, keepdims=True))
        return values


def predict_tabm(feature_codes, feature_cards, target_codes, target_cards,
                 train_rows, query_rows, config=None, budget=None, members=ENSEMBLE_SIZE):
    config = config or NeuralConfig(device="cpu", threads=8)
    if config.device != "cpu":
        raise ValueError("This measured TabM adaptation is CPU-only")
    if members < 2 or not config.hidden:
        raise ValueError("TabM requires at least two members and nonempty hidden layers")
    if not 0 < config.validation_fraction < 0.5 or config.epochs < 1:
        raise ValueError("Invalid validation fraction or epoch count")
    _checkpoint(budget)
    started = perf_counter()
    train, query = np.asarray(train_rows, dtype=int), np.asarray(query_rows, dtype=int)
    if np.intersect1d(train, query).size:
        raise ValueError("TRAIN and QUERY must be disjoint")
    cards = [int(c) for c in target_cards]
    if not cards or min(cards) < 1:
        raise ValueError("Target cardinalities must be positive")
    y = np.asarray(target_codes[train], dtype=np.int64).copy()
    if y.shape != (len(train), len(cards)):
        raise ValueError("Target matrix shape differs from schema")
    for j, card in enumerate(cards):
        if np.any(y[:, j] >= card) or np.any(y[:, j] < -1):
            raise ValueError("TRAIN label outside schema")
    features = one_hot_features(feature_codes, feature_cards)
    varying = np.ptp(features[train], axis=0) > 0 if len(train) else np.zeros(features.shape[1], bool)
    x_train = torch.from_numpy(features[train][:, varying])
    x_query = torch.from_numpy(features[query][:, varying])
    y_train = torch.from_numpy(y)

    def prior_for(positions):
        blocks = []
        for j, card in enumerate(cards):
            labels = y[positions, j]
            counts = np.bincount(labels[labels >= 0], minlength=card).astype(float) + 0.5
            blocks.append(counts / counts.sum())
        return np.concatenate(blocks)

    if len(train) < 20 or not varying.any() or not np.any(y >= 0):
        prior = prior_for(np.arange(len(train)))
        offsets = np.r_[0, np.cumsum(cards)]
        return [np.tile(prior[a:b], (len(query), 1)) for a, b in zip(offsets[:-1], offsets[1:])], {
            "fallback": "insufficient variable training data", "seconds": perf_counter() - started}

    permutation = np.random.default_rng(config.seed).permutation(len(train))
    held_count = max(2, int(len(train) * config.validation_fraction))
    held, core = permutation[:held_count], permutation[held_count:]
    curves = []

    def fit(positions, epochs, validation=None):
        torch.random.default_generator.manual_seed(config.seed)
        model = TabMNetwork(x_train.shape[1], cards, prior_for(positions), config, members)
        steps = max(1, (len(positions) + config.batch_size - 1) // config.batch_size)
        decay = (-np.expm1(np.log1p(-config.weight_decay) / steps) / config.learning_rate
                 if config.regularization_scaled else config.weight_decay)
        optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=float(decay))
        order_rng = np.random.default_rng(config.seed)
        best, best_epoch, stale = np.inf, 1, 0
        for epoch in range(1, epochs + 1):
            _checkpoint(budget)
            model.train()
            order = order_rng.permutation(positions)
            for begin in range(0, len(order), config.batch_size):
                _checkpoint(budget)
                rows = order[begin:begin + config.batch_size]
                optimizer.zero_grad(set_to_none=True)
                loss = model.loss(model(x_train[rows]), y_train[rows])
                if not bool(torch.isfinite(loss)):
                    raise FloatingPointError("Non-finite TabM training loss")
                loss.backward()
                optimizer.step()
            if validation is not None:
                model.eval()
                total, n_cells = 0.0, 0
                with torch.no_grad():
                    for begin in range(0, len(validation), config.batch_size):
                        _checkpoint(budget)
                        rows = validation[begin:begin + config.batch_size]
                        cells = int((y_train[rows] >= 0).sum())
                        score = model.loss(model(x_train[rows]), y_train[rows], config.metric_floor,
                                           average_predictions=True)
                        total += float(score) * cells
                        n_cells += cells
                score = total / max(1, n_cells)
                curves.append({"epoch": epoch, "internal_ensemble_nll": score})
                if not np.isfinite(score):
                    raise FloatingPointError("Non-finite TabM validation loss")
                if score < best - config.min_delta:
                    best, best_epoch, stale = score, epoch, 0
                else:
                    stale += 1
                if stale >= config.patience:
                    break
        return model, best_epoch

    old_threads = torch.get_num_threads()
    old_determinism = torch.are_deterministic_algorithms_enabled()
    old_warn_only = torch.is_deterministic_algorithms_warn_only_enabled()
    try:
        torch.set_num_threads(config.threads)
        torch.use_deterministic_algorithms(True)
        with torch.random.fork_rng(devices=[]):
            _, selected_epoch = fit(core, config.epochs, held)
            model, _ = fit(np.arange(len(train)), selected_epoch)
            result = model.probabilities(x_query, config.batch_size, budget)
            parameter_count = sum(p.numel() for p in model.parameters())
    finally:
        torch.set_num_threads(old_threads)
        torch.use_deterministic_algorithms(old_determinism, warn_only=old_warn_only)
    return result, {"model": "tabm_multitask_embedded", "config": asdict(config), "members": members,
                    "training_objective": "mean_submodel_cross_entropy",
                    "selection_objective": "grader_nll_of_mean_probability",
                    "initialization": "first_R_random_signs_other_RS_ones_heads_zero_prior",
                    "training_rows": len(train), "internal_validation_rows": len(held),
                    "input_width": int(varying.sum()), "output_width": sum(cards),
                    "parameters": parameter_count, "selected_epoch": selected_epoch,
                    "curve": curves, "seconds": perf_counter() - started}


def candidate(data, train, query, budget=None, config=None):
    import legacy
    import nonerpis

    laws, targets, cards = nonerpis._gate_content(data, train)
    values, details = predict_tabm(data.x, data.xcards, targets, cards, train, query,
                                  config=config, budget=budget)
    return legacy.Candidate(NAME, nonerpis._compose(data, values, laws, query)), {
        **details, "gate_items": list(laws)}
