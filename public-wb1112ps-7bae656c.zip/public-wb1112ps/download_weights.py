import argparse
import gzip
import hashlib
import os
import shutil
import sys
from pathlib import Path

from huggingface_hub import hf_hub_download

MODELS = Path(__file__).resolve().parent / "models"

KUMO = {
    "repo_id": "nvidia/Kumo-Tabular",
    "filename": "large/classifier.pt",
    "revision": "3c3e10bbdb590ace29e7026847f92db3c603096d",
    "target": "kumo-tabular-large-classifier.pt",
    "bytes": 854850034,
    "sha256": "cc21484316949641cc3d65a7bb6c36cdea854cc569435755ff23b850018ec613",
}

TABICL = {
    "repo_id": "jingang/TabICL",
    "filename": "tabicl-classifier-v2-20260212.ckpt",
    "revision": "4dcd344ece2c00be9e831fdd35bed57b5ad83e19",
    "target": "tabicl-v2.ckpt.gz",
    "bytes": 110368038,
    "sha256": "bdc7dbd5e4ff21f8f0456fcf90c6b7cdf72dbea960f2d05b19bec19f9b3d4ed0",
}


def file_digest(path):
    digest = hashlib.sha256()
    size = 0
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
            size += len(block)
    return size, digest.hexdigest()


def kumo_ok(path):
    return path.is_file() and file_digest(path) == (KUMO["bytes"], KUMO["sha256"])


def tabicl_ok(path):
    if not path.is_file():
        return False
    with gzip.open(path, "rb") as stream:
        payload = stream.read(TABICL["bytes"] + 1)
    return len(payload) == TABICL["bytes"] and hashlib.sha256(payload).hexdigest() == TABICL["sha256"]


def fetch(spec, cache_dir):
    path = Path(hf_hub_download(repo_id=spec["repo_id"], filename=spec["filename"],
                                revision=spec["revision"], cache_dir=cache_dir))
    size, sha256 = file_digest(path)
    if (size, sha256) != (spec["bytes"], spec["sha256"]):
        raise SystemExit("%s/%s@%s: got %d bytes, sha256 %s; expected %d bytes, sha256 %s"
                         % (spec["repo_id"], spec["filename"], spec["revision"], size, sha256,
                            spec["bytes"], spec["sha256"]))
    return path


def install_kumo(cache_dir, force):
    target = MODELS / KUMO["target"]
    if not force and kumo_ok(target):
        print("kept     %s (sha256 %s)" % (target.name, KUMO["sha256"]))
        return
    source = fetch(KUMO, cache_dir)
    partial = target.with_name(target.name + ".partial")
    shutil.copyfile(source, partial)
    if not kumo_ok(partial):
        partial.unlink()
        raise SystemExit("copy of %s failed verification" % KUMO["filename"])
    os.replace(partial, target)
    print("written  %s (%d bytes, sha256 %s)" % (target.name, KUMO["bytes"], KUMO["sha256"]))


def install_tabicl(cache_dir, force):
    target = MODELS / TABICL["target"]
    if not force and tabicl_ok(target):
        print("kept     %s (decompressed sha256 %s)" % (target.name, TABICL["sha256"]))
        return
    source = fetch(TABICL, cache_dir)
    partial = target.with_name(target.name + ".partial")
    partial.write_bytes(gzip.compress(source.read_bytes(), compresslevel=6, mtime=0))
    if not tabicl_ok(partial):
        partial.unlink()
        raise SystemExit("compressed %s failed verification" % TABICL["filename"])
    os.replace(partial, target)
    size, sha256 = file_digest(target)
    print("written  %s (decompressed %d bytes, sha256 %s)" % (target.name, TABICL["bytes"], TABICL["sha256"]))
    print("         compressed %d bytes, sha256 %s" % (size, sha256))


def main():
    parser = argparse.ArgumentParser(
        description="Download the TabICL and Kumo Tabular checkpoints at the pinned revisions "
                    "into models/ and verify their SHA-256.")
    parser.add_argument("--cache-dir", default=None, help="Hugging Face cache directory")
    parser.add_argument("--force", action="store_true", help="download again even if verified")
    args = parser.parse_args()
    MODELS.mkdir(exist_ok=True)
    install_tabicl(args.cache_dir, args.force)
    install_kumo(args.cache_dir, args.force)
    print("models/ ready: both checkpoints verified")
    return 0


if __name__ == "__main__":
    sys.exit(main())
