import numpy as np
from scipy import sparse
from scipy.special import softmax, logsumexp
from scipy.optimize import minimize

def table(x,y,cx,cy):
    return np.bincount(x*cy+y,minlength=cx*cy).reshape(cx,cy).astype(float)

def mi(x,y,cx,cy):
    z=table(x,y,cx,cy);n=z.sum()
    if not n:return 0.0
    a,b=np.nonzero(z)
    return float(np.sum(z[a,b]/n*np.log(z[a,b]*n/(z.sum(1)[a]*z.sum(0)[b]))))

def cmi(x,z,y,cx,cz,cy):
    counts=np.bincount((y*cx+x)*cz+z,minlength=cy*cx*cz).reshape(cy,cx,cz).astype(float)
    a,b,c=np.nonzero(counts);n=counts.sum()
    v=counts[a,b,c]
    return float(np.sum(v/n*np.log(v*counts.sum((1,2))[a]/(counts.sum(2)[a,b]*counts.sum(1)[a,c]))))

def prefix_design(train,query):
    nr=len(train);nq=len(query);rr=[np.arange(nr)];cc=[np.zeros(nr,dtype=int)]
    rq=[np.arange(nq)];cq=[np.zeros(nq,dtype=int)];offset=1
    for d in range(1,train.shape[1]+1):
        vocab={key:i for i,key in enumerate(sorted(set(map(tuple,train[:,:d]))))}
        codes=np.fromiter((vocab[tuple(row)] for row in train[:,:d]),dtype=int,count=nr)
        qcodes=np.fromiter((vocab.get(tuple(row),-1) for row in query[:,:d]),dtype=int,count=nq)
        rr.append(np.arange(nr));cc.append(offset+codes)
        valid=qcodes>=0;rq.append(np.flatnonzero(valid));cq.append(offset+qcodes[valid])
        offset+=len(vocab)
    def build(r,c,n):
        r=np.concatenate(r);c=np.concatenate(c)
        return sparse.csr_matrix((np.ones(len(r)),(r,c)),shape=(n,offset))
    return build(rr,cc,nr),build(rq,cq,nq)

def conditional_hls(context,y,qcontext,width,l2=1.,max_iter=60):
    qcontext,qinv=np.unique(qcontext,axis=0,return_inverse=True)
    contexts,inv=np.unique(context,axis=0,return_inverse=True)
    counts=np.bincount(inv*width+y,minlength=len(contexts)*width).reshape(len(contexts),width).astype(float)
    design,qdesign=prefix_design(contexts,qcontext)
    totals=counts.sum(1);n=totals.sum();npar=design.shape[1]
    initial=np.zeros((npar,width));initial[0]=np.log((counts.sum(0)+.5)/(n+.5*width))
    def obj(flat):
        b=flat.reshape(npar,width);z=design@b;p=softmax(z,axis=1)
        loss=np.sum(totals*logsumexp(z,axis=1))-np.sum(counts*z)+.5*l2*np.sum(b*b)
        grad=design.T@(totals[:,None]*p-counts)+l2*b
        return float(loss/n),np.asarray(grad/n).ravel()
    fit=minimize(obj,initial.ravel(),jac=True,method='L-BFGS-B',options={'maxiter':max_iter,'ftol':1e-8,'gtol':1e-6})
    params=fit.x if np.isfinite(fit.fun) and fit.fun<=obj(initial.ravel())[0] else initial.ravel()
    return softmax(qdesign@params.reshape(npar,width),axis=1)[qinv],{'iterations':int(fit.nit),'converged':bool(fit.success),'parameters':int(len(params))}

def conditional_counts(context,y,qcontext,width,concentration=20.):
    qcontext,qinv=np.unique(qcontext,axis=0,return_inverse=True)
    marginal=(np.bincount(y,minlength=width)+.5)/(len(y)+.5*width)
    result=np.tile(marginal,(len(qcontext),1))
    for d in range(1,context.shape[1]+1):
        vocab={key:i for i,key in enumerate(sorted(set(map(tuple,context[:,:d]))))}
        codes=np.fromiter((vocab[tuple(row)] for row in context[:,:d]),dtype=int,count=len(context))
        counts=np.bincount(codes*width+y,minlength=len(vocab)*width).reshape(len(vocab),width)
        qcodes=np.fromiter((vocab.get(tuple(row),-1) for row in qcontext[:,:d]),dtype=int,count=len(qcontext))
        valid=qcodes>=0;c=counts[qcodes[valid]]
        result[valid]=(c+concentration*result[valid])/(c.sum(1)[:,None]+concentration)
    return result[qinv],{}

def predict_kdb(x,cards,y,width,train,query,k=1,smoothing='hls'):
    x=np.asarray(x,dtype=np.int64);y=np.asarray(y,dtype=np.int64);cards=np.asarray(cards,dtype=np.int64)
    train=np.asarray(train);query=np.asarray(query)
    train=train[(y[train]>=0)&(y[train]<width)]
    if not len(train):return np.ones((len(query),width))/width,{'empty_train':True}
    a=x[train];b=x[query];target=y[train];d=a.shape[1]
    prior=(np.bincount(target,minlength=width)+.5)/(len(target)+.5*width)
    order=sorted(range(d),key=lambda j:-mi(a[:,j],target,cards[j],width))
    cm=np.zeros((d,d))
    for i in range(d):
        for j in range(i):cm[i,j]=cm[j,i]=cmi(a[:,i],a[:,j],target,cards[i],cards[j],width)
    logp=np.tile(np.log(prior),(len(query),1));details=[]
    qclasses=np.tile(np.arange(width),len(query))
    for pos,j in enumerate(order):
        parents=sorted(order[:pos],key=lambda h:-cm[j,h])[:k]
        context=np.column_stack([target]+[a[:,h] for h in parents])
        qcontext=np.column_stack([qclasses]+[np.repeat(b[:,h],width) for h in parents])
        fn=conditional_hls if smoothing=='hls' else conditional_counts
        probs,detail=fn(context,a[:,j],qcontext,int(cards[j]))
        selected=probs[np.arange(len(qclasses)),np.repeat(b[:,j],width)].reshape(len(query),width)
        logp+=np.log(np.maximum(selected,1e-300));details.append(detail)
    return softmax(logp,axis=1),{'order':order,'fits':details}
