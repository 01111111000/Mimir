from dataclasses import dataclass, asdict
from time import perf_counter

import numpy as np
import torch
from torch import nn


@dataclass(frozen=True)
class NeuralConfig:
    seed: int = 13
    hidden: tuple = (128, 64)
    epochs: int = 160
    patience: int = 15
    batch_size: int = 512
    learning_rate: float = 0.003
    weight_decay: float = 0.01
    regularization_scaled: bool = False
    dropout: float = 0.1
    validation_fraction: float = 0.2
    min_delta: float = 1e-5
    threads: int = 8
    metric_floor: float = 1e-3


def one_hot_features(features, cards):
    features = np.asarray(features)
    blocks = []
    for column, card in enumerate(cards):
        value = features[:, column].astype(np.int64)
        value = np.where((value >= 0) & (value < card), value, card)
        blocks.append(np.eye(card + 1, dtype=np.float32)[value])
    return np.concatenate(blocks, axis=1) if blocks else np.zeros((len(features), 1), dtype=np.float32)


class ConditionalNetwork(nn.Module):
    def __init__(self, input_width, target_cards, prior, config):
        super().__init__()
        output_width = sum(target_cards)
        self.linear = nn.Linear(input_width, output_width)
        nn.init.zeros_(self.linear.weight)
        with torch.no_grad():
            self.linear.bias.copy_(torch.from_numpy(np.log(prior).astype(np.float32)))
        layers = []
        width = input_width
        for hidden in config.hidden:
            layers.extend((nn.Linear(width, hidden), nn.ReLU(), nn.Dropout(config.dropout)))
            width = hidden
        if layers:
            output = nn.Linear(width, output_width, bias=False)
            nn.init.zeros_(output.weight)
            layers.append(output)
        self.nonlinear = nn.Sequential(*layers) if layers else None
        self.groups = []
        offset = np.r_[0, np.cumsum(target_cards)]
        for card in sorted(set(target_cards)):
            targets = np.flatnonzero(np.asarray(target_cards) == card)
            columns = np.concatenate([np.arange(offset[j], offset[j + 1]) for j in targets])
            self.groups.append((torch.as_tensor(targets), torch.as_tensor(columns), int(card)))

    def forward(self, x):
        output = self.linear(x)
        if self.nonlinear is not None:
            output = output + self.nonlinear(x)
        return output

    def loss(self, logits, truth, floor=0.0):
        total = logits.new_zeros(())
        cells = 0
        for targets, columns, card in self.groups:
            selected = logits[:, columns].reshape(-1, len(targets), card)
            labels = truth[:, targets]
            valid = labels >= 0
            logp = selected.log_softmax(dim=-1)
            chosen = logp.gather(2, labels.clamp(min=0).unsqueeze(-1)).squeeze(-1)
            if floor:
                chosen = torch.log(floor + (1 - card * floor) * chosen.exp())
            total = total - chosen[valid].sum()
            cells += valid.sum()
        return total / cells.clamp(min=1)

    def probabilities(self, x, target_cards, batch_size=1024, budget=None):
        self.eval()
        blocks = []
        with torch.no_grad():
            for start in range(0, len(x), batch_size):
                if budget is not None:
                    budget.checkpoint()
                logits = self(x[start:start + batch_size])
                out = torch.empty_like(logits)
                for targets, columns, card in self.groups:
                    selected = logits[:, columns].reshape(-1, len(targets), card)
                    out[:, columns] = selected.softmax(dim=-1).reshape(len(logits), -1)
                blocks.append(out.numpy())
        packed = np.concatenate(blocks) if blocks else np.empty((0, sum(target_cards)))
        offsets = np.r_[0, np.cumsum(target_cards)]
        result = []
        for left, right in zip(offsets[:-1], offsets[1:]):
            p = np.maximum(packed[:, left:right].astype(np.float64), 1e-9)
            result.append(p / p.sum(axis=1, keepdims=True))
        return result


def predict_neural(feature_codes, feature_cards, target_codes, target_cards,
                   train_rows, query_rows, config=None, budget=None):
    config = config or NeuralConfig()
    if budget is not None:
        budget.checkpoint()
    start = perf_counter()
    train = np.asarray(train_rows, dtype=np.int64)
    query = np.asarray(query_rows, dtype=np.int64)
    cards = [int(card) for card in target_cards]
    if np.intersect1d(train, query).size:
        raise ValueError("TRAIN and QUERY must be disjoint")
    if not 0 < config.validation_fraction < 0.5 or config.epochs < 1:
        raise ValueError("Invalid neural validation or epoch configuration")
    if not cards or min(cards) < 1:
        raise ValueError("Target cardinalities must be positive")
    y = np.asarray(target_codes[train], dtype=np.int64).copy()
    if y.shape != (len(train), len(cards)):
        raise ValueError("Target matrix shape differs from schema")
    for j, card in enumerate(cards):
        if np.any(y[:, j] >= card) or np.any(y[:, j] < -1):
            raise ValueError("TRAIN label is outside schema")
    features = one_hot_features(feature_codes, feature_cards)
    varying = np.ptp(features[train], axis=0) > 0 if len(train) else np.zeros(features.shape[1], bool)
    x_train = torch.from_numpy(features[train][:, varying])
    x_query = torch.from_numpy(features[query][:, varying])
    y_train = torch.from_numpy(y)

    def prior_for(positions):
        blocks = []
        for j, card in enumerate(cards):
            labels = y[positions, j]
            counts = np.bincount(labels[labels >= 0], minlength=card).astype(float) + 0.5
            blocks.append(counts / counts.sum())
        return np.concatenate(blocks)

    if len(train) < 20 or not varying.any() or not np.any(y >= 0):
        prior = prior_for(np.arange(len(train)))
        offsets = np.r_[0, np.cumsum(cards)]
        values = [np.tile(prior[a:b], (len(query), 1)) for a, b in zip(offsets[:-1], offsets[1:])]
        return values, {"fallback": "insufficient variable training data", "seconds": perf_counter() - start}

    rng = np.random.default_rng(config.seed)
    permutation = rng.permutation(len(train))
    held_count = max(2, int(len(train) * config.validation_fraction))
    held, core = permutation[:held_count], permutation[held_count:]
    previous_threads = torch.get_num_threads()
    previous_determinism = torch.are_deterministic_algorithms_enabled()
    previous_warn_only = torch.is_deterministic_algorithms_warn_only_enabled()
    curves = []

    def fit(positions, epochs, validation=None):
        torch.random.default_generator.manual_seed(config.seed)
        network = ConditionalNetwork(x_train.shape[1], cards, prior_for(positions), config)
        steps = max(1, (len(positions) + config.batch_size - 1) // config.batch_size)
        decay = (-np.expm1(np.log1p(-config.weight_decay) / steps) / config.learning_rate
                 if config.regularization_scaled else config.weight_decay)
        optimizer = torch.optim.AdamW(network.parameters(), lr=config.learning_rate,
                                      weight_decay=float(decay))
        order_rng = np.random.default_rng(config.seed)
        best, best_epoch, patience = np.inf, 1, 0
        for epoch in range(1, epochs + 1):
            if budget is not None:
                budget.checkpoint()
            network.train()
            order = order_rng.permutation(positions)
            for begin in range(0, len(order), config.batch_size):
                if budget is not None:
                    budget.checkpoint()
                rows = order[begin:begin + config.batch_size]
                optimizer.zero_grad(set_to_none=True)
                loss = network.loss(network(x_train[rows]), y_train[rows])
                loss.backward()
                optimizer.step()
            if validation is not None:
                network.eval()
                with torch.no_grad():
                    score = float(network.loss(network(x_train[validation]), y_train[validation],
                                               config.metric_floor))
                curves.append({"epoch": epoch, "internal_nll": score})
                if not np.isfinite(score):
                    raise FloatingPointError("Non-finite internal neural loss")
                if score < best - config.min_delta:
                    best, best_epoch, patience = score, epoch, 0
                else:
                    patience += 1
                if patience >= config.patience:
                    break
        return network, best_epoch

    try:
        torch.set_num_threads(config.threads)
        torch.use_deterministic_algorithms(True)
        with torch.random.fork_rng(devices=[]):
            _, selected_epoch = fit(core, config.epochs, held)
            network, _ = fit(np.arange(len(train)), selected_epoch)
            result = network.probabilities(x_query, cards, budget=budget)
    finally:
        torch.set_num_threads(previous_threads)
        torch.use_deterministic_algorithms(previous_determinism, warn_only=previous_warn_only)
    return result, {"model": "conditional_multitask_network", "config": asdict(config),
                    "training_rows": len(train), "internal_validation_rows": len(held),
                    "input_width": int(varying.sum()), "output_width": sum(cards),
                    "selected_epoch": selected_epoch, "curve": curves,
                    "seconds": perf_counter() - start}
