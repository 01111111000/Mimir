import numpy as np
from scipy.sparse import csr_matrix
from scipy.special import logsumexp


def _one_hot(codes, cards):
    offsets = np.r_[0, np.cumsum(cards, dtype=np.int64)]
    rows, columns = np.nonzero(codes >= 0)
    indices = offsets[columns] + codes[rows, columns]
    design = csr_matrix(
        (np.ones(rows.size), (rows, indices)),
        shape=(len(codes), int(offsets[-1])),
    )
    return design, offsets


def _row_indices(rows, length):
    rows = np.asarray(rows)
    if rows.dtype == bool:
        if rows.shape != (length,):
            raise ValueError("A row mask must have one entry per respondent")
        return np.flatnonzero(rows)
    if rows.ndim != 1:
        raise ValueError("Rows must be a one-dimensional index array or mask")
    if rows.size and (np.any(rows < 0) or np.any(rows >= length)):
        raise ValueError("Respondent index outside the supplied frame")
    return rows.astype(np.int64, copy=False)


def predict_latent(feature_codes, feature_cards, target_codes, target_cards,
                   train_rows, query_rows, classes, seed=13, max_iter=60,
                   tol=1e-5, alpha=0.5, repair=False):
    features = np.asarray(feature_codes, dtype=np.int64)
    targets = np.asarray(target_codes, dtype=np.int64)
    feature_cards = np.asarray(feature_cards, dtype=np.int64)
    target_cards = np.asarray(target_cards, dtype=np.int64)
    if features.ndim != 2 or targets.ndim != 2 or len(features) != len(targets):
        raise ValueError("Features and targets must be matrices with equal rows")
    if feature_cards.shape != (features.shape[1],) or target_cards.shape != (targets.shape[1],):
        raise ValueError("Cards must have one entry per categorical column")
    cards = np.concatenate((feature_cards, target_cards))
    if np.any(cards < 1):
        raise ValueError("Each categorical column must have at least one option")
    if np.any(features < 0) or np.any(features >= feature_cards):
        raise ValueError("Features must use valid nonnegative categorical codes")
    if np.any(targets < -1) or np.any(targets >= target_cards):
        raise ValueError("Targets must be schema codes or -1 for unknown values")
    if classes < 1 or int(classes) != classes or max_iter < 1 or int(max_iter) != max_iter:
        raise ValueError("classes and max_iter must be positive integers")
    if alpha <= 0 or not np.isfinite(alpha) or tol < 0 or not np.isfinite(tol):
        raise ValueError("alpha must be positive and tol nonnegative and finite")
    classes = int(classes)
    train_rows = _row_indices(train_rows, len(features))
    query_rows = _row_indices(query_rows, len(features))
    n_train, n_query = len(train_rows), len(query_rows)
    diagnostics = {
        "classes": classes,
        "iterations": 0,
        "converged": True,
        "train_rows": n_train,
        "query_rows": n_query,
        "final_log_likelihood": 0.0,
        "final_objective": 0.0,
        "log_likelihood_history": [],
        "objective_history": [],
    }
    if n_train == 0 or len(cards) == 0:
        diagnostics["reason"] = "empty_training" if n_train == 0 else "no_columns"
        return [np.full((n_query, int(k)), 1.0 / k) for k in target_cards], diagnostics

    training_codes = np.concatenate((features[train_rows], targets[train_rows]), axis=1)
    design, offsets = _one_hot(training_codes, cards)
    feature_width = int(feature_cards.sum())
    query_design, _ = _one_hot(features[query_rows], feature_cards)

    rng = np.random.default_rng(seed)
    prototypes = np.empty(classes, dtype=np.int64)
    prototypes[0] = rng.integers(n_train)
    closest = np.full(n_train, np.inf)
    for index in range(1, classes):
        previous_profile = training_codes[prototypes[index - 1]]
        observed = (training_codes >= 0) & (previous_profile >= 0)
        distance = np.count_nonzero(observed & (training_codes != previous_profile), axis=1)
        distance = distance / np.maximum(observed.sum(axis=1), 1)
        closest = np.minimum(closest, distance)
        if index < n_train:
            closest[prototypes[:index]] = -1.0
            prototypes[index] = np.argmax(closest)
        else:
            prototypes[index] = rng.integers(n_train)
    agreement = design @ design[prototypes].T.toarray()
    initial_scores = 2.0 * agreement / np.sqrt(len(cards))
    initial_scores += rng.normal(0.0, 0.01, size=initial_scores.shape)
    responsibilities = np.exp(initial_scores - logsumexp(initial_scores, axis=1, keepdims=True))
    previous_objective = None
    converged = False

    for iteration in range(1, int(max_iter) + 1):
        option_counts = np.asarray(design.T @ responsibilities) + alpha
        block_totals = np.add.reduceat(option_counts, offsets[:-1], axis=0)
        theta = option_counts / np.repeat(block_totals, cards, axis=0)
        class_weights = (responsibilities.sum(axis=0) + alpha) / (n_train + classes * alpha)
        log_theta = np.log(theta)
        log_weights = np.log(class_weights)
        log_joint = design @ log_theta + log_weights
        log_normalizer = logsumexp(log_joint, axis=1, keepdims=True)
        log_likelihood = float(log_normalizer.sum())
        objective = log_likelihood + alpha * float(log_theta.sum() + log_weights.sum())
        diagnostics["log_likelihood_history"].append(log_likelihood)
        diagnostics["objective_history"].append(objective)
        if previous_objective is not None:
            converged = (abs(objective - previous_objective) / n_train <= tol if repair
                         else abs(objective - previous_objective) <= tol * (1.0 + abs(previous_objective)))
        if converged:
            break
        responsibilities = np.exp(log_joint - log_normalizer)
        previous_objective = objective

    feature_temperature = 2.0 if repair else 1.0
    query_log_joint = (query_design @ log_theta[:feature_width]) / feature_temperature + log_weights
    posterior = np.exp(query_log_joint - logsumexp(query_log_joint, axis=1, keepdims=True))
    predictions = []
    for column in range(len(feature_cards), len(cards)):
        profile = theta[offsets[column]:offsets[column + 1]]
        probabilities = posterior @ profile.T
        probabilities /= probabilities.sum(axis=1, keepdims=True)
        predictions.append(probabilities)
    diagnostics.update({
        "iterations": iteration,
        "converged": bool(converged),
        "final_log_likelihood": log_likelihood,
        "final_objective": objective,
        "class_weights": class_weights.tolist(),
        "feature_temperature": feature_temperature,
        "stopping_scale": "absolute_per_respondent" if repair else "relative_total",
        "reason": "tolerance" if converged else "iteration_limit",
    })
    return predictions, diagnostics
