from __future__ import annotations

import numpy as np

from wb_schema_features import ORDERED_GIVEN, NONRESPONSE


def numeric_features(frame, schema):
    columns = []
    for name, ordered in ORDERED_GIVEN.items():
        record = schema["items"].get(name)
        if record is None or record["class"] != "GIVEN":
            continue
        allowed = set(record["values"])
        unsupported = allowed.difference(ordered).difference({NONRESPONSE})
        if unsupported:
            raise ValueError(f"Unsupported ordinal categories for {name}: {sorted(unsupported)!r}")
        ranks = np.arange(len(ordered), dtype=float)
        ranks = (ranks - ranks.mean()) / ranks.std()
        mapping = dict(zip(ordered, ranks))
        raw = frame[name].astype(object)
        known = raw.isin([v for v in ordered if v in allowed]).to_numpy()
        na = (raw.eq(NONRESPONSE).fillna(False).to_numpy()
              if NONRESPONSE in allowed else np.zeros(len(frame), dtype=bool))
        rank = raw.map(mapping).fillna(0.0).to_numpy(dtype=float)
        rank[~known] = 0.0
        columns.extend((rank, na.astype(float), (~known & ~na).astype(float)))
    return np.column_stack(columns) if columns else np.empty((len(frame), 0), dtype=float)


def for_data(data):
    return (numeric_features(data.frame, data.schema)
            if getattr(data.config, "ordinal_given", False) else None)


def append_numeric(design, numeric, rows=None):
    if numeric is None:
        return design
    values = np.asarray(numeric, dtype=design.dtype)
    if values.ndim != 2 or not np.isfinite(values).all():
        raise ValueError("Numeric GIVEN features must be a finite matrix")
    if rows is not None:
        values = values[rows]
    if values.shape[0] != design.shape[0]:
        raise ValueError("Numeric GIVEN features must cover the same rows")
    return np.concatenate((design, values), axis=1)
