from dataclasses import dataclass
from time import perf_counter

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from threadpoolctl import threadpool_limits

from cascade import predict as cascade_predict
from latent import predict_latent
from ridge import predict_ridge
from ordinal import predict_ordinal
from joint_forest import predict_joint_forest
from reduced_rank import predict_reduced_rank
import wb_ordinal_given


FLOOR = 1e-9
WAVE_ZERO_MIN_ROWS = 1000


@dataclass(frozen=True)
class Config:
    r3: bool = False
    r4: bool = False
    r5: bool = False
    r6: bool = False
    r7: bool = False
    r8: bool = False
    seed: int = 13
    folds: int = 3
    m: int = 1
    alpha: float = 0.5
    k: float = 20.0
    weight_k: float = 200.0
    regularized_stack: bool = False
    kernel_width: float = 0.20
    latent_classes: tuple = (2, 4, 8)
    latent_max_iter: int = 60
    latent_tol: float = 1e-5
    ridge_strength: float = 20.0
    derive_round: bool = False
    branch_features: bool = False
    ordinal_given: bool = False
    floor: float = FLOOR
    metric_floor: float = 1e-3
    forest_trees: int = 24
    forest_depth: int = 7
    forest_min_leaf: int = 64
    blas_threads: int = 8
    factor_rank: int = 8
    factor_max_iter: int = 60
    c10_gate: bool = False
    enabled: tuple = ("C1", "C2", "C3", "C4", "C5", "C7", "C8", "C9", "C10")


@dataclass
class Candidate:
    name: str
    probabilities: dict

    def predict(self, respondent, item):
        value = self.probabilities.get(item)
        return None if value is None else value[respondent]


def normalize(p):
    p = np.asarray(p, dtype=float)
    total = p.sum(axis=-1, keepdims=True)
    return np.divide(p, total, out=np.full_like(p, 1.0 / p.shape[-1]), where=total > 0)


def output_distribution(p, floor):
    return normalize(np.maximum(normalize(p), floor))


def options_for(schema, item):
    record = schema["items"][item]
    return list(record["values"]) + ([schema.get("gated_value", "NA_GATED")]
                                      if record.get("gate") else [])


def complete_rows(frame, schema):
    targets = [n for n, r in schema["items"].items() if r["class"] == "PREDICT"]
    return np.flatnonzero(~frame[targets].isna().any(axis=1).to_numpy())


def hidden_rows(frame, schema):
    targets = [n for n, r in schema["items"].items() if r["class"] == "PREDICT"]
    if not targets:
        return np.empty(0, dtype=int)
    return np.flatnonzero(frame[targets].isna().all(axis=1).to_numpy())


def respondent_folds(rows, folds, seed):
    if len(rows) < 2:
        return []
    perm = np.random.default_rng(seed).permutation(rows)
    return [perm[i::min(folds, len(rows))] for i in range(min(folds, len(rows)))]


def mask_respondents(frame, schema, rows):
    masked = frame.copy(deep=True)
    targets = [n for n, r in schema["items"].items() if r["class"] == "PREDICT"]
    masked.iloc[rows, masked.columns.get_indexer(targets)] = None
    return masked


def mutual_information(x, y, nx, ny, corrected=False):
    valid = y >= 0
    if not valid.any():
        return 0.0
    joint = np.bincount(x[valid] * ny + y[valid], minlength=nx * ny).reshape(nx, ny)
    count = joint.sum()
    joint = joint / count
    expected = joint.sum(1)[:, None] * joint.sum(0)[None, :]
    on = joint > 0
    value = float(np.sum(joint[on] * np.log(joint[on] / expected[on])))
    if corrected:
        kx, ky = np.count_nonzero(joint.sum(1)), np.count_nonzero(joint.sum(0))
        value = max(0.0, value - (kx - 1) * (ky - 1) / (2.0 * count))
    return value


def shrink_counts(counts, prior, k):
    return (counts + k * prior) / (counts.sum(axis=-1, keepdims=True) + k)


def partition_keys(columns, n):
    if not columns:
        return np.zeros(n, dtype=np.int64), 1
    joint = np.zeros(n, dtype=np.int64)
    size = 1
    for column in columns:
        column = np.asarray(column, dtype=np.int64)
        shifted = column - column.min(initial=0)
        card = int(shifted.max(initial=0)) + 1
        size *= card
        if size > np.iinfo(np.int64).max:
            _, inverse = np.unique(np.column_stack(columns), axis=0, return_inverse=True)
            return inverse, int(inverse.max(initial=-1)) + 1
        joint = joint * card + shifted
    _, inverse = np.unique(joint, return_inverse=True)
    return inverse, int(inverse.max(initial=-1)) + 1


class Data:
    def __init__(self, frame, schema, config):
        self.frame, self.schema, self.config = frame, schema, config
        self.items = [n for n, r in schema["items"].items() if r["class"] in ("GIVEN", "PREDICT")]
        self.given = [n for n in self.items if schema["items"][n]["class"] == "GIVEN"]
        self.targets = [n for n in self.items if schema["items"][n]["class"] == "PREDICT"]
        self.options = {n: options_for(schema, n) for n in self.items}
        self.codes = {n: frame[n].map({v: i for i, v in enumerate(self.options[n])})
                      .fillna(-1).to_numpy(dtype=np.int64) for n in self.items}
        self.features = {n: np.where(self.codes[n] >= 0, self.codes[n], len(self.options[n]))
                         for n in self.given}
        self.cards = {n: len(self.options[n]) + 1 for n in self.given}
        self.round = next((n for n in self.given if n.lower() in ("wave", "round", "survey_round")
                           or schema["items"][n].get("question", "").lower().strip(". ")
                           in ("survey round", "survey wave")), None)
        self.round_source = self.round or "absent"
        if self.round is None and config.derive_round:
            families = ("s6_4", "s6_6", "s6_11", "s7a_7", "s7b_1")
            usable = [n for n in self.given if n.startswith(families)]
            if usable:
                signatures = [frame[n].eq("0").fillna(False).to_numpy(dtype=np.int64) for n in usable]
                key, card = partition_keys(signatures, len(frame))
                self.round = "__round_hypothesis"
                self.features[self.round], self.cards[self.round] = key, card
                self.round_source = "GIVEN-only zero pattern hypothesis"
            else:
                self.round_source = "hypothesis unavailable: no GIVEN family columns"
        self.extra = []
        if config.branch_features:
            sentinel = schema.get("gated_value", "NA_GATED")
            branch = []
            for n in self.given:
                key = "__gated_" + n
                self.features[key] = frame[n].eq(sentinel).fillna(False).to_numpy(dtype=np.int64)
                self.cards[key] = 2
                branch.append(self.features[key])
                self.extra.append(key)
            self.features["__gated_count"] = np.sum(branch, axis=0, dtype=np.int64) if branch else np.zeros(len(frame), dtype=np.int64)
            self.cards["__gated_count"] = len(self.given) + 1
            self.extra.append("__gated_count")
        if self.round and self.round not in self.given:
            self.extra.append(self.round)
        self.erpis = any(r.get("gate") and r["gate"]["parent"] in self.targets
                         for n, r in schema["items"].items() if n in self.targets)
        self.c5_applicable = any(n == "s3_11" or n.startswith("s3_11_") for n in schema["items"])
        self.feature_names = list(self.features)
        self.x = np.column_stack(list(self.features.values())) if self.features else np.empty((len(frame), 0), dtype=int)
        self.xcards = [self.cards[n] for n in self.feature_names]
        self.y = np.column_stack([self.codes[n] for n in self.targets]) if self.targets else np.empty((len(frame), 0), dtype=int)
        self.ycards = [len(self.options[n]) for n in self.targets]

    def marginal(self, name, train):
        y = self.codes[name][train]
        counts = np.bincount(y[y >= 0], minlength=len(self.options[name]))
        return (counts + self.config.alpha) / (counts.sum() + self.config.alpha * len(counts))

    def ranks(self, name, train):
        scores = {g: mutual_information(x[train], self.codes[name][train], self.cards[g], len(self.options[name]), self.config.r8)
                  for g, x in self.features.items()}
        ranked = sorted(scores, key=lambda g: -scores[g])
        return [g for g in ranked if scores[g] > 0], scores


def topological_targets(data):
    pending, order = list(data.targets), []
    while pending:
        ready = [n for n in pending if not data.schema["items"][n].get("gate")
                 or data.schema["items"][n]["gate"]["parent"] not in pending]
        if not ready:
            raise ValueError("Cyclic gate schema")
        order.extend(ready)
        pending = [n for n in pending if n not in ready]
    return order


def hierarchy(data, train, query, ranks):
    result = {}
    nq = len(query)
    for name in topological_targets(data):
        width = len(data.options[name])
        marginal = data.marginal(name, train)
        ranked = ranks[name][0]
        gate = data.schema["items"][name].get("gate")
        parent = gate["parent"] if data.erpis and gate and gate["parent"] in data.codes else None
        first = None if parent else next(iter(ranked), None)
        strata = []
        if first:
            strata.append(first)
        if data.round and data.round not in strata:
            strata.append(data.round)
        extra = [s for s in ranked if s not in strata and s != parent][:data.config.m]
        strata.extend(extra)
        if parent:
            kp = len(data.options[parent])
            parent_p = result.get(parent, np.tile(data.marginal(parent, train), (nq, 1))).copy()
            if parent in data.given:
                pc = data.codes[parent][query]
                seen = pc >= 0
                parent_p[seen] = np.eye(kp)[pc[seen]]
            tf = data.codes[parent][train]
            qf = np.tile(np.arange(kp), nq)
            fit_columns, query_columns = [tf], [qf]
            running = np.tile(marginal, (nq * kp, 1))
            if data.config.r3 and parent in data.targets:
                opening = np.array([v in gate["observed_if"] for v in data.options[parent]])
                observed = (tf >= 0) & (data.codes[name][train] >= 0)
                content = normalize(marginal[:-1])
                priors = np.tile(marginal, (kp, 1))
                for is_open in (False, True):
                    group = observed & np.isin(tf, np.flatnonzero(opening == is_open))
                    sent = (np.count_nonzero(group & (data.codes[name][train] == width - 1)) + 0.5) / (group.sum() + 1.0)
                    priors[opening == is_open, :-1] = (1.0 - sent) * content
                    priors[opening == is_open, -1] = sent
                running = np.tile(priors, (nq, 1))
            repeats = kp
        else:
            fit_columns, query_columns = [], []
            running = np.tile(marginal, (nq, 1))
            repeats = 1
        levels = ([None] if parent else []) + strata
        y = data.codes[name][train]
        for feature in levels:
            if feature is not None:
                fit_columns.append(data.features[feature][train])
                query_columns.append(np.repeat(data.features[feature][query], repeats))
            joined = [np.concatenate([a, b]) for a, b in zip(fit_columns, query_columns)]
            keys, size = partition_keys(joined, len(train) + len(running))
            known = y >= 0
            if parent:
                known &= tf >= 0
            counts = np.bincount(keys[:len(train)][known] * width + y[known], minlength=size * width).reshape(size, width)
            running = shrink_counts(counts[keys[len(train):]], running, data.config.k)
        if parent:
            running = np.einsum("np,npk->nk", parent_p, running.reshape(nq, repeats, width))
        result[name] = normalize(running)
    return result


def similarity(data, train, query, ranks, backbone):
    result = {}
    for name in data.targets:
        ranked, scores = ranks[name]
        selected = ranked[:data.config.m]
        gate = data.schema["items"][name].get("gate")
        if data.config.r8 and gate and gate["parent"] in data.given:
            parent = gate["parent"]
            if parent not in selected:
                selected = [parent] + selected
        selected += [g for g in [data.round] + data.extra if g and g not in selected and scores.get(g, 0) > 0]
        hidden_parent = (gate["parent"] if data.config.r8 and gate and gate["parent"] in data.targets else None)
        if (not selected and not hidden_parent) or not len(train):
            result[name] = backbone[name].copy()
            continue
        fit_columns = [data.features[g][train] for g in selected]
        query_columns = [data.features[g][query] for g in selected]
        weights = [max(scores[g], 1e-12) for g in selected]
        if hidden_parent:
            parent_y = data.codes[hidden_parent][train]
            fit_columns.append(parent_y)
            query_columns.append(np.full(len(query), -1, dtype=int))
            weights.append(max(mutual_information(parent_y, data.codes[name][train],
                len(data.options[hidden_parent]), len(data.options[name]), True), 1e-12))
        x = np.column_stack(fit_columns)
        q = np.column_stack(query_columns)
        profiles, group = np.unique(x, axis=0, return_inverse=True)
        if hidden_parent:
            queries, inverse = q, np.arange(len(query))
        else:
            queries, inverse = np.unique(q, axis=0, return_inverse=True)
        weights = np.array(weights)
        weights /= weights.sum()
        width = len(data.options[name])
        y = data.codes[name][train]
        valid = y >= 0
        counts = np.bincount(group[valid] * width + y[valid], minlength=len(profiles) * width).reshape(len(profiles), width)
        pooled = np.empty((len(queries), width))
        for start in range(0, len(queries), 256):
            distance = np.zeros((len(queries[start:start + 256]), len(profiles)))
            for j, w in enumerate(weights):
                if hidden_parent and j == len(weights) - 1:
                    pc = profiles[:, j]
                    posterior = backbone[hidden_parent][start:start + 256]
                    similarity_to_parent = np.where(pc[None, :] >= 0, posterior[:, np.maximum(pc, 0)], 0.0)
                    distance += w * (1.0 - similarity_to_parent)
                else:
                    distance += w * (queries[start:start + 256, j, None] != profiles[None, :, j])
            kernel = np.exp(-0.5 * (distance / data.config.kernel_width) ** 2)
            pooled[start:start + 256] = kernel @ counts
        result[name] = shrink_counts(pooled[inverse], backbone[name], data.config.k)
    return result


def cascade(data, train, query):
    if not data.c5_applicable:
        return {n: None for n in data.targets}
    selected = np.concatenate([train, query])
    frame = data.frame.iloc[selected].copy(deep=True).reset_index(drop=True)
    frame = mask_respondents(frame, data.schema, np.arange(len(train), len(selected)))
    records = {n: dict(r) for n, r in data.schema["items"].items()}
    for feature in data.extra:
        values = data.features[feature][selected]
        if np.unique(values).size <= 1:
            continue
        frame[feature] = values.astype(str)
        records[feature] = {"class": "GIVEN", "question": feature,
                            "values": [str(i) for i in range(data.cards[feature])], "gate": None}
    schema = dict(data.schema, items=records)
    vectors = cascade_predict(frame, schema)
    items = [n for n, r in records.items() if r["class"] in ("GIVEN", "PREDICT")]
    blank = frame[items].isna().to_numpy()
    result = {n: np.empty((len(query), len(data.options[n]))) for n in data.targets}
    for (row, col), p in zip(np.argwhere(blank), vectors):
        item = items[col]
        if row >= len(train) and item in result:
            result[item][row - len(train)] = p
    return result


def fit_candidates(frame, schema, train, query, config, classes=None,
                   checkpoint=None, budget=None, failed=None, reuse_bank=None):
    failed = set() if failed is None else failed
    started = perf_counter()
    data = Data(frame, schema, config)
    ranks = {n: data.ranks(n, train) for n in data.targets}
    times = {"C1_features": perf_counter() - started}
    diagnostics = {"round_source": data.round_source, "components": {}, "failures": {}}
    candidates = {}

    def check():
        try:
            if budget is not None:
                budget.checkpoint()
            if checkpoint is not None:
                checkpoint()
        except Exception as error:
            if type(error).__name__ == 'CandidateBudgetExceeded':
                error.partial_bank = dict(candidates)
                error.partial_times = dict(times)
                error.partial_details = diagnostics
            raise

    def add(family, builder):
        if family in failed:
            return
        check()
        t = perf_counter()
        try:
            if family == "C10":
                with threadpool_limits(limits=config.blas_threads, user_api="blas"):
                    additions, details = builder()
            else:
                additions, details = builder()
            for key, values in additions.items():
                for name, value in values.items():
                    if value is None:
                        continue
                    if value.shape != (len(query), len(data.options[name])) or not np.isfinite(value).all() or np.any(value < 0) or np.any(value.sum(axis=1) <= 0):
                        raise ValueError("Illegal probabilities from " + key)
            candidates.update({key: Candidate(key, value) for key, value in additions.items()})
            diagnostics["components"].update(details)
        except Exception as error:
            if type(error).__name__ == 'CandidateBudgetExceeded':
                error.partial_bank = dict(candidates)
                error.partial_times = dict(times)
                error.partial_details = diagnostics
                raise
            failed.add(family)
            diagnostics["failures"][family] = type(error).__name__ + ": " + str(error)
            for key in list(candidates):
                if key == family or key.startswith(family + "_"):
                    del candidates[key]
        times[family] = perf_counter() - t
        check()

    t = perf_counter()
    candidates["C1"] = (reuse_bank['C1'] if reuse_bank and 'C1' in reuse_bank else
        Candidate("C1", {n: np.tile(data.marginal(n, train), (len(query), 1)) for n in data.targets}))
    times["C1"] = perf_counter() - t
    if reuse_bank and 'C2' in reuse_bank:
        candidates['C2'] = reuse_bank['C2']
    else:
        add("C2", lambda: ({"C2": hierarchy(data, train, query, ranks)}, {}))
    backbone = candidates.get("C2", candidates["C1"]).probabilities
    if "C3" in config.enabled:
        add("C3", lambda: ({"C3": similarity(data, train, query, ranks, backbone)}, {}))
    if "C4" in config.enabled:
        def latent_family():
            varying = np.ptp(data.x[train], axis=0) > 0 if len(train) else np.zeros(data.x.shape[1], dtype=bool)
            values_by_key, details = {}, {}
            for count in classes or config.latent_classes:
                values, detail = predict_latent(data.x[:, varying], np.asarray(data.xcards)[varying].tolist(),
                    data.y, data.ycards, train, query, count, config.seed,
                    config.latent_max_iter, config.latent_tol, config.alpha, repair=config.r7)
                key = "C4_%d" % count
                values_by_key[key], details[key] = dict(zip(data.targets, values)), detail
            return values_by_key, details
        add("C4", latent_family)
    if "C5" in config.enabled:
        add("C5", lambda: ({"C5": cascade(data, train, query)}, {}))

    def learner(family, function, *args, **kwargs):
        values, detail = function(*args, **kwargs)
        probabilities = dict(zip(data.targets, values))
        if (family == "C9" and config.r6) or (family == "C10" and config.c10_gate):
            from gfic_legacy import gate_laws, compose_gate, Config as GateConfig
            for name, law in gate_laws(data, train, GateConfig()).items():
                probabilities[name] = compose_gate(probabilities[name][:, :-1], law, query)
            detail["given_gate_recomposition"] = True
        return {family: probabilities}, {family: detail}

    common = (data.x, data.xcards, data.y, data.ycards, train, query)
    numeric = wb_ordinal_given.for_data(data)
    if "C7" in config.enabled:
        add("C7", lambda: learner("C7", predict_ridge, *common,
            strength=config.ridge_strength, alpha=config.alpha, repair=config.r4,
            numeric_features=numeric))
    if "C8" in config.enabled:
        add("C8", lambda: learner("C8", predict_ordinal, schema, *common,
            strength=config.ridge_strength, alpha=config.alpha, repair=config.r4))
    if "C9" in config.enabled:
        add("C9", lambda: learner("C9", predict_joint_forest, *common,
            seed=config.seed, trees=config.forest_trees, max_depth=config.forest_depth,
            min_leaf=config.forest_min_leaf, alpha=config.k, repair=config.r6))
    if "C10" in config.enabled:
        add("C10", lambda: learner("C10", predict_reduced_rank, *common,
            rank=config.factor_rank, strength=config.ridge_strength, alpha=config.alpha,
            seed=config.seed, max_iter=config.factor_max_iter, repair=config.r5,
            numeric_features=numeric))
    diagnostics["failed_families"] = sorted(failed)
    return candidates, times, diagnostics


def collect_oof(frame, schema, config):
    complete = complete_rows(frame, schema)
    folds = respondent_folds(complete, config.folds, config.seed)
    positions = {int(row): i for i, row in enumerate(complete)}
    oof, fold_of, times, details = {}, np.full(len(complete), -1, dtype=int), {}, []
    targets = [n for n, r in schema["items"].items() if r["class"] == "PREDICT"]
    for fold, held in enumerate(folds):
        train = np.setdiff1d(complete, held)
        masked = mask_respondents(frame, schema, held)
        candidates, seconds, diag = fit_candidates(masked, schema, train, held, config)
        pos = np.array([positions[int(row)] for row in held])
        fold_of[pos] = fold
        for key, candidate in candidates.items():
            if key not in oof:
                oof[key] = Candidate(key, {n: None if candidate.probabilities[n] is None else
                    np.empty((len(complete), len(options_for(schema, n)))) for n in targets})
            for name in targets:
                if oof[key].probabilities[name] is not None:
                    oof[key].probabilities[name][pos] = candidate.probabilities[name]
        for key, seconds_used in seconds.items():
            times[key] = times.get(key, 0.0) + seconds_used
        details.append(diag)
    return oof, complete, fold_of, times, details


def true_probabilities(candidate, data, rows, config):
    values = []
    for name in data.targets:
        p = candidate.probabilities.get(name)
        if p is None:
            continue
        y = data.codes[name][rows]
        valid = y >= 0
        q = output_distribution(p[valid], config.floor)
        q = config.metric_floor + (1 - q.shape[1] * config.metric_floor) * q
        values.append(q[np.arange(valid.sum()), y[valid]])
    return np.concatenate(values) if values else np.empty(0)


def select_classes(oof, data, rows, config, selection=None):
    losses = {}
    for key, candidate in oof.items():
        if key.startswith("C4_"):
            sub = candidate if selection is None else Candidate(key, {n: p[selection] for n, p in candidate.probabilities.items()})
            actual = rows if selection is None else rows[selection]
            probs = true_probabilities(sub, data, actual, config)
            losses[key] = -float(np.log(np.maximum(probs, np.finfo(float).tiny)).mean()) if len(probs) else 0.0
    selected = min(losses, key=losses.get) if losses else None
    output = {key: value for key, value in oof.items() if not key.startswith("C4_")}
    if selected:
        output["C4"] = Candidate("C4", oof[selected].probabilities)
    return output, (int(selected.split("_")[1]) if selected else None), losses


def _safe_simplex_result(value, initial, objective, masks=()):
    candidate = np.asarray(value, dtype=float)
    if candidate.shape != initial.shape or not np.isfinite(candidate).all():
        return initial.copy()
    candidate = np.maximum(candidate, 0.0)
    mass = candidate.sum()
    if not np.isfinite(mass) or mass <= 0:
        return initial.copy()
    candidate /= mass
    if any(active.any() and candidate[active].sum() <= 0 for active in masks):
        return initial.copy()
    result = objective(candidate)[0]
    return candidate if np.isfinite(result) and result <= objective(initial)[0] + 1e-10 else initial.copy()


def simplex_fit(q, initial=None):
    count = q.shape[1]
    initial = np.full(count, 1.0 / count) if initial is None else normalize(initial)
    if not len(q) or count == 1:
        return initial

    def objective(w):
        p = np.maximum(np.einsum("ij,j->i", q, w), np.finfo(float).tiny)
        return -np.log(p).mean(), -np.mean(q / p[:, None], axis=0)

    fitted = minimize(objective, initial, jac=True, method="SLSQP", bounds=[(0, 1)] * count,
                      constraints={"type": "eq", "fun": lambda w: w.sum() - 1,
                                   "jac": lambda w: np.ones_like(w)},
                      options={"maxiter": 80, "ftol": 1e-9})
    return _safe_simplex_result(fitted.x, initial, objective)


def fit_stack(candidates, data, rows, config, selection=None):
    selection = np.arange(len(rows)) if selection is None else np.asarray(selection)
    names = [n for n in config.enabled if n in candidates and any(p is not None for p in candidates[n].probabilities.values())]
    q_by_item, masks = {}, {}
    for item in data.targets:
        active = np.array([candidates[n].probabilities.get(item) is not None for n in names])
        masks[item] = active
        y = data.codes[item][rows[selection]]
        valid = y >= 0
        cols = []
        for n in np.asarray(names)[active]:
            p = output_distribution(candidates[n].probabilities[item][selection][valid], config.floor)
            cols.append(config.metric_floor + (1 - p.shape[1] * config.metric_floor) * p[np.arange(valid.sum()), y[valid]])
        q_by_item[item] = np.column_stack(cols) if cols else np.empty((valid.sum(), 0))
    def objective(w):
        loss, gradient, total = 0.0, np.zeros(len(names)), 0
        for item, q in q_by_item.items():
            active = masks[item]
            mass = w[active].sum()
            if not len(q) or not active.any():
                continue
            mass = max(mass, np.finfo(float).tiny)
            num = np.maximum(np.einsum("ij,j->i", q, w[active]), np.finfo(float).tiny)
            loss -= np.log(num / mass).sum()
            gradient[active] += -(q / num[:, None]).sum(0) + len(q) / mass
            total += len(q)
        return loss / max(total, 1), gradient / max(total, 1)
    initial = np.full(len(names), 1 / len(names))
    if all(np.all(m) for m in masks.values()):
        instrument = simplex_fit(np.vstack(list(q_by_item.values())), initial)
    else:
        fit = minimize(objective, initial, jac=True, method="SLSQP", bounds=[(1e-10, 1)] * len(names),
                       constraints={"type": "eq", "fun": lambda w: w.sum() - 1}, options={"maxiter": 80, "ftol": 1e-9})
        instrument = _safe_simplex_result(fit.x, initial, objective, masks.values())
    weights, mixed = {}, {}
    for item, q in q_by_item.items():
        active = masks[item]
        prior = normalize(instrument[active])
        if config.regularized_stack:
            w = regularized_simplex_fit(q, prior, config.weight_k)
        else:
            fitted = simplex_fit(q, prior)
            w = (len(q) * fitted + config.weight_k * prior) / (len(q) + config.weight_k)
        weights[item] = np.zeros(len(names))
        weights[item][active] = w
        mixed[item] = sum(wi * candidates[n].probabilities[item] for wi, n in zip(w, np.asarray(names)[active]))
    return {"names": names, "instrument": instrument, "weights": weights, "mixed": mixed}


def regularized_simplex_fit(q, prior, strength):
    prior = normalize(np.maximum(np.asarray(prior, dtype=float), 1e-8))
    if len(prior) < 2 or not len(q):
        return prior
    q = q[np.ptp(q, axis=1) > 1e-14]
    if not len(q):
        return prior
    scale = len(q) + strength
    def objective(w):
        p = np.maximum(q @ w, np.finfo(float).tiny)
        safe = np.maximum(w, 1e-12)
        loss = -np.log(p).sum() - strength * np.dot(prior, np.log(safe))
        gradient = -(q / p[:, None]).sum(axis=0) - strength * prior / safe
        return loss / scale, gradient / scale
    fit = minimize(objective, prior, jac=True, method='SLSQP',
                   bounds=[(1e-12, 1.)] * len(prior),
                   constraints={'type':'eq', 'fun':lambda w:w.sum()-1,
                                'jac':lambda w:np.ones_like(w)},
                   options={'maxiter':100, 'ftol':1e-10})
    return _safe_simplex_result(fit.x, prior, objective)


def calibrate(p, marginal, temperature, marginal_weight):
    logp = np.log(np.maximum(p, np.finfo(float).tiny)) / temperature
    powered = np.exp(logp - logp.max(axis=1, keepdims=True))
    return (1 - marginal_weight) * normalize(powered) + marginal_weight * marginal


def crossfit_mixtures(oof, data, rows, fold_of, config):
    mixed = {n: np.empty((len(rows), len(data.options[n]))) for n in data.targets}
    details = {"folds": [], "component_seconds": {}}
    for fold in np.unique(fold_of):
        positions = np.flatnonzero(fold_of == fold)
        held = rows[positions]
        train = rows[fold_of != fold]
        if len(train) < 2:
            for item in data.targets:
                mixed[item][positions] = oof["C1"].probabilities[item][positions]
            details["folds"].append({"held_rows": held.tolist(), "training_rows": train.tolist(),
                                      "classes": None, "candidate_names": ["C1"],
                                      "instrument_weights": [1.0], "mean_item_weights": [1.0]})
            continue
        masked = mask_respondents(data.frame, data.schema, held)
        inner, inner_rows, _, seconds, inner_details = collect_oof(masked, data.schema, config)
        inner_data = Data(masked, data.schema, config)
        selected, classes, _ = select_classes(inner, inner_data, inner_rows, config)
        t = perf_counter()
        stack = fit_stack(selected, inner_data, inner_rows, config)
        seconds["C6_nested_weights"] = perf_counter() - t
        for item, weights in stack["weights"].items():
            probability = np.zeros((len(positions), len(data.options[item])))
            for weight, name in zip(weights, stack["names"]):
                key = "C4_%d" % classes if name == "C4" else name
                p = oof[key].probabilities.get(item)
                if p is not None:
                    probability += weight * p[positions]
            mixed[item][positions] = normalize(probability)
        details["folds"].append({"held_rows": held.tolist(), "training_rows": train.tolist(),
                                  "classes": classes, "candidate_names": stack["names"],
                                  "candidate_folds": inner_details,
                                  "instrument_weights": stack["instrument"].tolist(),
                                  "mean_item_weights": np.mean(list(stack["weights"].values()), axis=0).tolist()})
        for key, value in seconds.items():
            details["component_seconds"][key] = details["component_seconds"].get(key, 0.0) + value
    return {"mixed": mixed}, details


def fit_calibration(stack, marginals, data, rows, config, selection=None):
    selection = np.arange(len(rows)) if selection is None else np.asarray(selection)
    maxk = max(data.ycards)
    bases, priors, actual, widths = [], [], [], []
    for item in data.targets:
        y = data.codes[item][rows[selection]]
        valid = y >= 0
        k = len(data.options[item])
        b = np.full((valid.sum(), maxk), -np.inf)
        b[:, :k] = np.log(np.maximum(stack["mixed"][item][selection][valid], np.finfo(float).tiny))
        m = np.zeros_like(b)
        m[:, :k] = marginals.probabilities[item][selection][valid]
        bases.append(b); priors.append(m); actual.append(y[valid]); widths.append(np.full(valid.sum(), k))
    base, prior = np.concatenate(bases), np.concatenate(priors)
    y, width = np.concatenate(actual), np.concatenate(widths)
    if not len(y):
        return 1.0, 0.0
    ix = np.arange(len(y))
    mask = np.arange(maxk)[None, :] < width[:, None]
    finite_base = np.where(mask, base, 0.0)

    def objective(theta):
        temperature, blend = theta
        logits = base / temperature
        p = np.exp(logits - logits.max(axis=1, keepdims=True))
        p /= p.sum(1, keepdims=True)
        derivative_t = p * ((p * finite_base).sum(1, keepdims=True) - finite_base) / temperature**2
        derivative_b = prior - p
        raw = (1 - blend) * p + blend * prior
        active = mask & (raw > config.floor)
        p = np.where(mask, np.maximum(raw, config.floor), 0)
        total = p.sum(1)
        pt = p[ix, y] / total
        scored = config.metric_floor + (1 - width * config.metric_floor) * pt
        gradient = []
        for derivative in ((1 - blend) * derivative_t, derivative_b):
            derivative = derivative * active
            dpt = (derivative[ix, y] - pt * derivative.sum(1)) / total
            gradient.append(-np.mean((1 - width * config.metric_floor) * dpt / scored))
        return -np.log(np.maximum(scored, np.finfo(float).tiny)).mean(), np.asarray(gradient)
    fitted = minimize(objective, [1.0, 0.0], jac=True, method="L-BFGS-B", bounds=[(0.4, 3.0), (0.0, 1.0)],
                      options={"maxiter": 50, "ftol": 1e-10})
    return float(fitted.x[0]), float(fitted.x[1])


def apply_stack(candidates, stack, temperature, marginal_weight, config):
    probabilities = {}
    for item, weights in stack["weights"].items():
        parts = [(w, candidates[n].probabilities.get(item)) for w, n in zip(weights, stack["names"])]
        active = [(w, p) for w, p in parts if p is not None]
        total = sum(w for w, _ in active)
        p = sum(w * p for w, p in active) / total if total > 0 else candidates["C1"].probabilities[item]
        p = calibrate(p, candidates["C1"].probabilities[item], temperature, marginal_weight)
        probabilities[item] = output_distribution(p, config.floor)
    return Candidate("C6", probabilities)


def detect_wave_zero_items(frame, schema, complete):
    wave = schema["items"].get("wave", {})
    if wave.get("class") != "GIVEN" or not {"1", "2"}.issubset(wave.get("values") or []):
        return {}, {"status": "inapplicable: no GIVEN wave with levels 1 and 2", "items": {}}
    sentinel = schema.get("gated_value", "NA_GATED")
    train = frame.iloc[complete]
    wave1 = train["wave"].eq("1").fillna(False).to_numpy(dtype=bool)
    wave2 = train["wave"].eq("2").fillna(False).to_numpy(dtype=bool)
    n1, n2 = int(wave1.sum()), int(wave2.sum())
    detected, counts = {}, {}
    for name, record in schema["items"].items():
        if record["class"] != "PREDICT" or not record.get("gate") or "0" not in record["values"]:
            continue
        gated = train[name].eq(sentinel).fillna(False).to_numpy(dtype=bool)
        s1, s2 = int(gated[wave1].sum()), int(gated[wave2].sum())
        counts[name] = {"wave1_sentinels": s1, "wave2_sentinels": s2}
        if n1 >= WAVE_ZERO_MIN_ROWS and s1 == 0 and s2 > 0:
            detected[name] = record["values"].index("0")
    return detected, {"status": "checked", "wave1_complete": n1,
                      "wave2_complete": n2, "min_wave1_rows": WAVE_ZERO_MIN_ROWS,
                      "zero_event_upper95": float(-np.expm1(np.log(0.05) / n1)) if n1 else None,
                      "detected": list(detected), "items": counts}


def remap_wave_zero_vector(p, zero_index, floor):
    result = p.copy()
    retained = min(float(result[-1]), floor)
    if retained <= 0:
        raise ValueError("Wave remapping requires a strictly positive output floor")
    result[zero_index] += result[-1] - retained
    result[-1] = retained
    return result


def predict_with_diagnostics(frame, schema, config=None):
    config = config or Config()
    if config.folds < 2 or config.k <= 0 or config.alpha <= 0 or config.weight_k <= 0 or config.m < 0 or config.kernel_width <= 0:
        raise ValueError("Invalid smoothing/CV configuration")
    started = perf_counter()
    data = Data(frame, schema, config)
    complete = complete_rows(frame, schema)
    query = hidden_rows(frame, schema)
    if not len(query):
        return [], {"seconds": perf_counter() - started}
    times = {}
    if len(complete) >= 2 and data.targets:
        oof, rows, fold_of, times, details = collect_oof(frame, schema, config)
        selected, classes, losses = select_classes(oof, data, rows, config)
        t = perf_counter()
        stack = fit_stack(selected, data, rows, config)
        times["C6_weights"] = perf_counter() - t
        calibration_inputs, calibration_details = crossfit_mixtures(oof, data, rows, fold_of, config)
        for key, value in calibration_details["component_seconds"].items():
            times[key] = times.get(key, 0.0) + value
        t = perf_counter()
        temperature, marginal_weight = fit_calibration(calibration_inputs, selected["C1"], data, rows, config)
        times["C6_calibration"] = perf_counter() - t
        final, seconds, diag = fit_candidates(frame, schema, complete, query, config,
                                              (classes,) if classes else None)
        if classes:
            final["C4"] = final.pop("C4_%d" % classes)
        prediction = apply_stack(final, stack, temperature, marginal_weight, config)
        for key, value in seconds.items():
            times[key] = times.get(key, 0.0) + value
        diagnostics = {"component_seconds": times, "classes": classes, "class_oof_nll": losses,
                       "temperature": temperature, "marginal_weight": marginal_weight,
                       "candidate_names": stack["names"], "instrument_weights": stack["instrument"].tolist(),
                       "mean_item_weights": np.mean(list(stack["weights"].values()), axis=0).tolist(),
                       "folds": details, "calibration_folds": calibration_details["folds"], "final": diag}
    else:
        prediction = Candidate("C6", {n: np.tile(data.marginal(n, complete), (len(query), 1)) for n in data.targets})
        diagnostics = {"fallback": "fewer than two complete respondents", "component_seconds": times}
    remap_started = perf_counter()
    remapped_items, remap_details = detect_wave_zero_items(frame, schema, complete)
    wave1_query = (frame.iloc[query]["wave"].eq("1").fillna(False).to_numpy(dtype=bool)
                   if remapped_items else np.zeros(len(query), dtype=bool))
    diagnostics["wave_remap"] = remap_details
    times["wave_remap_detection"] = perf_counter() - remap_started
    output = []
    for position in range(len(query)):
        for item in data.targets:
            p = prediction.predict(position, item)
            if "fallback" in diagnostics:
                p = output_distribution(p, config.floor)
            if wave1_query[position] and item in remapped_items:
                p = remap_wave_zero_vector(p, remapped_items[item], config.floor)
            output.append(p.tolist())
    diagnostics["seconds"] = perf_counter() - started
    return output, diagnostics


def predict(frame, schema):
    return predict_with_diagnostics(frame, schema)[0]
